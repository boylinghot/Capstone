#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "mc_std.h"
struct mc_FuqoOljSO54Djybg4fBmJO{const McLinearAlgebraFactory*(*
mc_VSihvhbjOsGy_y1Uqa1AZz)(void);McLinearAlgebraFactory*(*
mc_F4grZl2EHgdXgeI603_D9L)(int32_T mc_k0zHKt3B8EloaeisOobs3u);void(*
mc_FGqwVJ3giI8ud1jd9V4K_S)(McLinearAlgebraFactory*);};typedef struct
mc_FuqoOljSO54Djybg4fBmJO mc_kujLnKrsi70WjiJCtL3IxH;void
mc_ViFmI1xZ6SdQaeTJVXz19Z(int32_T mc_k0zHKt3B8EloaeisOobs3u);int32_T
mc_kRetltSP6Qh6Y9XQzv_x_8(void);void mc__MAjXX_vhuh1dHYi6q7Amp(int32_T
mc_VgFAG8_Oq9hbWHFJfymeVG);int32_T mc__Wk_7lB9fU83cmvLR3l2xZ(void);const
McLinearAlgebraFactory*mc_FBL_jhslsk4djyn0JyCJ3N(void);McLinearAlgebraFactory*
mc__W10OddyipWjbqjEsC0erF(int32_T);void mc_kgsI8828R1_IXe7jhlNlIU(
McLinearAlgebraFactory*);void mc_V_qij_8xtq4Naa_PCPpc04(
mc_kujLnKrsi70WjiJCtL3IxH*mc__XfQXtB6cfd9fyc_v3eEup);static int32_T
mc_VPSZUvx1TCOPWX0eQsiLXP= -1;static int32_T mc_V66jR0_4b8hegmsO7WT82c=0;
static mc_kujLnKrsi70WjiJCtL3IxH*mc_Vv_yKEGelRKZhe_OAR_ryT=NULL;void
mc_ViFmI1xZ6SdQaeTJVXz19Z(int32_T mc_k0zHKt3B8EloaeisOobs3u){
mc_VPSZUvx1TCOPWX0eQsiLXP=mc_k0zHKt3B8EloaeisOobs3u;}int32_T
mc_kRetltSP6Qh6Y9XQzv_x_8(void){return mc_VPSZUvx1TCOPWX0eQsiLXP;}void
mc__MAjXX_vhuh1dHYi6q7Amp(int32_T mc_VgFAG8_Oq9hbWHFJfymeVG){
mc_V66jR0_4b8hegmsO7WT82c=mc_VgFAG8_Oq9hbWHFJfymeVG;}int32_T
mc__Wk_7lB9fU83cmvLR3l2xZ(void){return mc_V66jR0_4b8hegmsO7WT82c;}const
McLinearAlgebraFactory*mc_FBL_jhslsk4djyn0JyCJ3N(void){if(
mc_Vv_yKEGelRKZhe_OAR_ryT==NULL){return NULL;}return mc_Vv_yKEGelRKZhe_OAR_ryT
->mc_VSihvhbjOsGy_y1Uqa1AZz();}McLinearAlgebraFactory*
mc__W10OddyipWjbqjEsC0erF(int32_T mc_k0zHKt3B8EloaeisOobs3u){if(
mc_Vv_yKEGelRKZhe_OAR_ryT==NULL){return NULL;}return mc_Vv_yKEGelRKZhe_OAR_ryT
->mc_F4grZl2EHgdXgeI603_D9L(mc_k0zHKt3B8EloaeisOobs3u);}void
mc_kgsI8828R1_IXe7jhlNlIU(McLinearAlgebraFactory*mc_FX_ivTD1E1K3Z16XUq1VHF){if
(mc_Vv_yKEGelRKZhe_OAR_ryT==NULL){return;}mc_Vv_yKEGelRKZhe_OAR_ryT->
mc_FGqwVJ3giI8ud1jd9V4K_S(mc_FX_ivTD1E1K3Z16XUq1VHF);}void
mc_V_qij_8xtq4Naa_PCPpc04(mc_kujLnKrsi70WjiJCtL3IxH*mc__XfQXtB6cfd9fyc_v3eEup)
{mc_Vv_yKEGelRKZhe_OAR_ryT=mc__XfQXtB6cfd9fyc_v3eEup;}
