#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
void mc_Fuhi5y7GCg0reqAEm1r_l_(boolean_T mc__BdKVTewIl8TaXwgBW0hvv);boolean_T
mc_FfedxnfpDwWSdTfkUMENH5(void);void mc_FaKpinNC4flb_PZSFixhA6(real_T
mc_FfDTppU8N_tOWuLK37x_08);real_T mc__7HD9QHW_xpwVeoSbWwoAV(void);void
mc_krIZsjo_XapWbu6GcCii4V(boolean_T mc__BdKVTewIl8TaXwgBW0hvv);boolean_T
mc__aX0A0HqLJCPcDgnJ68EOD(void);static boolean_T mc_VRpKvXcVHHSGdiv8MDZfm2=
true;static real_T mc_kW3S7ZH6_8CsfuSAKjcpMT=1e-6;static boolean_T
mc_kpSa7JwkmxGUZLp3BjP0aS=false;void mc_Fuhi5y7GCg0reqAEm1r_l_(boolean_T
mc__BdKVTewIl8TaXwgBW0hvv){mc_VRpKvXcVHHSGdiv8MDZfm2=mc__BdKVTewIl8TaXwgBW0hvv
;}boolean_T mc_FfedxnfpDwWSdTfkUMENH5(void){return mc_VRpKvXcVHHSGdiv8MDZfm2;}
void mc_FaKpinNC4flb_PZSFixhA6(real_T mc_FfDTppU8N_tOWuLK37x_08){
mc_kW3S7ZH6_8CsfuSAKjcpMT=mc_FfDTppU8N_tOWuLK37x_08;}real_T
mc__7HD9QHW_xpwVeoSbWwoAV(void){return mc_kW3S7ZH6_8CsfuSAKjcpMT;}void
mc_krIZsjo_XapWbu6GcCii4V(boolean_T mc__BdKVTewIl8TaXwgBW0hvv){
mc_kpSa7JwkmxGUZLp3BjP0aS=mc__BdKVTewIl8TaXwgBW0hvv;}boolean_T
mc__aX0A0HqLJCPcDgnJ68EOD(void){return mc_kpSa7JwkmxGUZLp3BjP0aS;}
