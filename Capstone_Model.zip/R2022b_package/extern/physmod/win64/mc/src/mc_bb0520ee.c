#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "pm_std.h"
#include "pm_std.h"
typedef enum{mc_FfS9gFGHqKt_fDwFfcldkw= -1,mc_FFaaXY_gkbSTcyLBvtfrzS,
mc_VUd8H_Dz0yp8cmQqTd7DxF,mc_kmVKy2ciwP4fcTEzXFmnvU,mc_VW_0L0rb93GgXq8_OmdwHv,
mc_kHoWGgwi3OdzaXvPvG1YY7,mc___D_4trEmdK8jyKCH6E_ac,mc_Fei8BCRUgBdwhDvvD5FrSo}
mc_kQtOKCqS08dIbumyDnHNDL;typedef struct mc_kv3fXx6PfXt7cekeoT00mk
mc_kgKqfPHHGatO_9OUxR4PRK;struct mc_kv3fXx6PfXt7cekeoT00mk{void*mPrivateData;
void(*mc_FapEct1OXaSugDZ6N_u_kA)(mc_kgKqfPHHGatO_9OUxR4PRK*,const char*
mc_FgZTwZqzhmd8haAibGoheR,const char*mc_k_4pzDDn_u0SjLvR9SBrIH);void(*
mc_FVdv01I3SEC4hD41rxmnRM)(mc_kgKqfPHHGatO_9OUxR4PRK*,const char*
mc_FgZTwZqzhmd8haAibGoheR,const char*mc_k_4pzDDn_u0SjLvR9SBrIH,real_T
mc__d1alWYexptL_X5HTFhbNK);void(*mc_kPHJTxMUjl8Oi1EQSHes2Q)(
mc_kgKqfPHHGatO_9OUxR4PRK*,const char*mc_FgZTwZqzhmd8haAibGoheR,const char*
mc_k_4pzDDn_u0SjLvR9SBrIH,const PmRealVector*mc__d1alWYexptL_X5HTFhbNK);void(*
mc__WEKdqi2uo0m_Dm8w8T_ZO)(mc_kgKqfPHHGatO_9OUxR4PRK*,const char*
mc_FgZTwZqzhmd8haAibGoheR,const char*mc_k_4pzDDn_u0SjLvR9SBrIH,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc__d1alWYexptL_X5HTFhbNK);};typedef struct mc__nZqLQp3m1lFaHyLAzyG2a
mc__39VLhR7TBCGYH016BQq8W;typedef struct mc__UzXDLpnAvdw_eUt0mYuul
mc_FJ2e3LJXmLlbhebizOW1SJ;typedef struct mc__sr5lnPbYjO_Wyo_mmPUmd
mc_Fw_IO5LchthA_LoeiSceRf;struct mc__sr5lnPbYjO_Wyo_mmPUmd{
mc_kgKqfPHHGatO_9OUxR4PRK*mc_kge3zWSlSoSRhTYHfGl24K;void(*
mc__6Do0w_54Hh7hDw5A7kAcK)(const mc__39VLhR7TBCGYH016BQq8W*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,const
char*mc_FgZTwZqzhmd8haAibGoheR);};struct mc__nZqLQp3m1lFaHyLAzyG2a{
mc_FJ2e3LJXmLlbhebizOW1SJ*mPrivateData;const PmSparsityPattern*
mc_VbQ99XU_TKpEgX06wWPmmb;mc_Fw_IO5LchthA_LoeiSceRf mc_VZj1rpSBB0tKh5vOG9vb5j;
void(*mc_VF0z4xtGYCxzcHJNRB8l2n)(const mc__39VLhR7TBCGYH016BQq8W*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,
PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*mc_kchvhvYJSIl4dyKnk7tfEC)(const
mc__39VLhR7TBCGYH016BQq8W*mc_kpyeXH2RWcWG_DVSgKEG_O,const PmRealVector*
mc__XfQXtB6cfd9fyc_v3eEup,PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*
mc_VLMY1ozRY0Kkj5P0kyXMgl)(const mc__39VLhR7TBCGYH016BQq8W*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,
PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
mc__39VLhR7TBCGYH016BQq8W*mc_kpyeXH2RWcWG_DVSgKEG_O);};typedef struct
mc_VoVW1IGPg_WaWmrtPlXVfD mc_kxnFIpkyuc0YdXbZO41ABc;typedef struct
mc_FpSYgeBscUCg_qWX4io4Kb mc_FSKepYWjsK8mbHLmdHWO58;typedef struct
mc_F7TCRYOl9IpujDKe3vErcI mc_F3czdn9EwuxfaaYWgN0vfZ;struct
mc_F7TCRYOl9IpujDKe3vErcI{int32_T mc_ksngc9l6D5KFVXNgzwkok8[5];};
PMF_DEPLOY_STATIC mc_F3czdn9EwuxfaaYWgN0vfZ mc_FL6WWuhINbWMW5KJKs2y9t(void){
int32_T mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_F3czdn9EwuxfaaYWgN0vfZ
mc__1Zf2IciMRCub1vvbEr1C4;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<5;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__1Zf2IciMRCub1vvbEr1C4 .mc_ksngc9l6D5KFVXNgzwkok8[mc_kwrB3ZoKf7OufTHWaHJV7a
]= -1;}return mc__1Zf2IciMRCub1vvbEr1C4;}struct mc_VoVW1IGPg_WaWmrtPlXVfD{
mc_FSKepYWjsK8mbHLmdHWO58*mPrivateData;mc_F3czdn9EwuxfaaYWgN0vfZ(*
mc__vHH72jqKt44cXWzB3_tSu)(const mc_kxnFIpkyuc0YdXbZO41ABc*
mc_kHt1ybY5z_OofadxN4AZsO);mc_kQtOKCqS08dIbumyDnHNDL(*mSolve)(const
mc_kxnFIpkyuc0YdXbZO41ABc*mc_kHt1ybY5z_OofadxN4AZsO,PmRealVector*
mc_VFDNUF6_N_t4Wu5qkxdJqD);void(*mc_FF_Aq2b8Cx_iduzooh_sWO)(const
mc_kxnFIpkyuc0YdXbZO41ABc*mc_kHt1ybY5z_OofadxN4AZsO,real_T
mc_kTckK8teUpOlhm8Ippu8XP);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
mc_kxnFIpkyuc0YdXbZO41ABc*mc_kHt1ybY5z_OofadxN4AZsO);};typedef struct
mc_kD0xfpE0MgxkYDG6tnWbJN mc_kKrwrwNLgB_NYDY0UUZRVA;typedef struct
mc_k577Fzud3mpCe91P_z0Qf_ mc_FuB6ZnvWHlGVe5AYB_qh1v;struct
mc_kD0xfpE0MgxkYDG6tnWbJN{mc_FuB6ZnvWHlGVe5AYB_qh1v*mPrivateData;
mc_kxnFIpkyuc0YdXbZO41ABc*(*mc_k_hVWBJWCUlCdPNZka5iZF)(const
mc_kKrwrwNLgB_NYDY0UUZRVA*mc__ZzBQ9ei49KTge3YSfX3g7,const
mc__39VLhR7TBCGYH016BQq8W*mc_kpyeXH2RWcWG_DVSgKEG_O);void(*
mc_VYGWBho6N1K_eyHOMGjDiW)(mc_kKrwrwNLgB_NYDY0UUZRVA*mc__ZzBQ9ei49KTge3YSfX3g7
);};typedef struct mc_FjeK_ZSfy_COYuwPPWwrm_ mc__3nzW_mY1qOqgXk2FmdyDG;typedef
struct mc__WUe8IvZOGldjumXd_GpEC mc_kTnNPenyhxlla9Uw7ULRfJ;typedef struct
mc_FOtb37LSX8d5_5lHkmfBZj mc_FfUgsrrKyC4CjixXpmLryh;struct
mc_FOtb37LSX8d5_5lHkmfBZj{mc_kgKqfPHHGatO_9OUxR4PRK*mc_kge3zWSlSoSRhTYHfGl24K;
void(*mc__6Do0w_54Hh7hDw5A7kAcK)(const mc__3nzW_mY1qOqgXk2FmdyDG*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*mc_FHw707OTzcOEeaB2IM_AJQ,const
PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,const char*mc_FgZTwZqzhmd8haAibGoheR);}
;struct mc_FjeK_ZSfy_COYuwPPWwrm_{mc_kTnNPenyhxlla9Uw7ULRfJ*mPrivateData;const
PmSparsityPattern*mc_VbQ99XU_TKpEgX06wWPmmb;size_t mNumModes;
mc_FfUgsrrKyC4CjixXpmLryh mc_VZj1rpSBB0tKh5vOG9vb5j;void(*
mc_VF0z4xtGYCxzcHJNRB8l2n)(const mc__3nzW_mY1qOqgXk2FmdyDG*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*mc_FHw707OTzcOEeaB2IM_AJQ,const
PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF)
;void(*mc_kchvhvYJSIl4dyKnk7tfEC)(const mc__3nzW_mY1qOqgXk2FmdyDG*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*mc_FHw707OTzcOEeaB2IM_AJQ,const
PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF)
;void(*mc_VLMY1ozRY0Kkj5P0kyXMgl)(const mc__3nzW_mY1qOqgXk2FmdyDG*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*mc_FHw707OTzcOEeaB2IM_AJQ,const
PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF)
;void(*mc_VT_CRoRmbpWajqcrcvcctF)(const mc__3nzW_mY1qOqgXk2FmdyDG*
mc_kpyeXH2RWcWG_DVSgKEG_O,const PmIntVector*mc_FHw707OTzcOEeaB2IM_AJQ,const
PmRealVector*mc__XfQXtB6cfd9fyc_v3eEup,PmIntVector*mc_V2mBNcV1EqCifyH9UdCbkF);
void(*mc_VYGWBho6N1K_eyHOMGjDiW)(mc__3nzW_mY1qOqgXk2FmdyDG*
mc_kpyeXH2RWcWG_DVSgKEG_O);};typedef struct mc_kWpl_dOgP5SEdi8_h6_Q0f
mc_FeVMxCfnPEW_Ya5WdW0ZiP;typedef struct mc_VzTwbfayokK_ZT6nhi1fuh
mc_kbq0rwTu6XGSZqa8cMRgbH;struct mc_kWpl_dOgP5SEdi8_h6_Q0f{
mc_kbq0rwTu6XGSZqa8cMRgbH*mPrivateData;mc_kQtOKCqS08dIbumyDnHNDL(*mSolve)(
const mc_FeVMxCfnPEW_Ya5WdW0ZiP*,PmIntVector*,PmRealVector*);
mc_F3czdn9EwuxfaaYWgN0vfZ(*mc__vHH72jqKt44cXWzB3_tSu)(const
mc_FeVMxCfnPEW_Ya5WdW0ZiP*mc_kHt1ybY5z_OofadxN4AZsO);void(*
mc_FF_Aq2b8Cx_iduzooh_sWO)(const mc_FeVMxCfnPEW_Ya5WdW0ZiP*
mc_kHt1ybY5z_OofadxN4AZsO,real_T mc_kTckK8teUpOlhm8Ippu8XP);void(*
mc_VYGWBho6N1K_eyHOMGjDiW)(mc_FeVMxCfnPEW_Ya5WdW0ZiP*mc_kHt1ybY5z_OofadxN4AZsO
);};typedef struct mc__6rvEkBoZV0Khyk1wEL30q mc_VLJsdw7KrQK_jqGzFmjnuT;typedef
struct mc_VsuhjkXAxQOnYHPheaQV6t mc_kAOZIOHKDP8Zh9U9Ca0DKK;struct
mc__6rvEkBoZV0Khyk1wEL30q{mc_kAOZIOHKDP8Zh9U9Ca0DKK*mPrivateData;
mc_FeVMxCfnPEW_Ya5WdW0ZiP*(*mc_k_hVWBJWCUlCdPNZka5iZF)(const
mc_VLJsdw7KrQK_jqGzFmjnuT*mc__ZzBQ9ei49KTge3YSfX3g7,const
mc__3nzW_mY1qOqgXk2FmdyDG*mc_kpyeXH2RWcWG_DVSgKEG_O);void(*
mc_VYGWBho6N1K_eyHOMGjDiW)(mc_VLJsdw7KrQK_jqGzFmjnuT*mc__ZzBQ9ei49KTge3YSfX3g7
);};size_t mc_VG1y_LrErwtMc9AoQz7Nqj(real_T mc_kg4CyRgbu6OdeewZOel7Qx,real_T
mc_kGgE55Nh9o0jfioSr_OONY,real_T mc_VVSC9LtbrC_kb15awLhs5p,size_t
mc_kFY5eMmSKnGdeHaIB_KZfR);
#include "math.h"
#include "pm_std.h"
size_t mc_VG1y_LrErwtMc9AoQz7Nqj(real_T mc_kg4CyRgbu6OdeewZOel7Qx,real_T
mc_kGgE55Nh9o0jfioSr_OONY,real_T mc_VVSC9LtbrC_kb15awLhs5p,size_t
mc_kFY5eMmSKnGdeHaIB_KZfR){(void)0;;(void)0;;(void)0;;(void)0;;(void)0;;{
real_T mc_kUQyL7NLR_hwXe8GsrlAdR=log(mc_kg4CyRgbu6OdeewZOel7Qx/
mc_kGgE55Nh9o0jfioSr_OONY);real_T mc__iHTdXoKTN_SaqS4cIRgK5=log(
mc_VVSC9LtbrC_kb15awLhs5p/mc_kGgE55Nh9o0jfioSr_OONY);real_T
mc_VYECQNj31_8jcmIurRArPD=mc_kUQyL7NLR_hwXe8GsrlAdR/mc__iHTdXoKTN_SaqS4cIRgK5;
size_t mc_kNMOEfjdDTOsVaDU42AXP0=(size_t)floor(mc_VYECQNj31_8jcmIurRArPD*(
real_T)mc_kFY5eMmSKnGdeHaIB_KZfR);if(mc_kNMOEfjdDTOsVaDU42AXP0>=
mc_kFY5eMmSKnGdeHaIB_KZfR){mc_kNMOEfjdDTOsVaDU42AXP0=mc_kFY5eMmSKnGdeHaIB_KZfR
-1;}(void)0;;(void)0;;(void)0;;return mc_kNMOEfjdDTOsVaDU42AXP0;}}
