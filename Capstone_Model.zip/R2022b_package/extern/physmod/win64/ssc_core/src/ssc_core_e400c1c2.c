#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
struct ssc_core_kesYKdRukKtCYLfoQ0YRJ5{struct{char const*
ssc_core_V_I9ZlTcE4CZb1Tw7wtZGX;char const*ssc_core__qMaoP8OVEGrgmx3ZP0Mj9;
char const*ssc_core_kMDLd9TMEWpxa14nB7xyQz;}ssc_core_FIBEYF8fIO4o_isvvmL_1_;
struct{struct{struct{char const*ssc_core_kjdqJsJTibClVTmfkrIlFw;char const*
ssc_core__qEXoys3NqhTc5aGZjoM0i;}ssc_core_kvZlvqC1JqdoYahhfIqkPq;struct{char
const*ssc_core_kjdqJsJTibClVTmfkrIlFw;char const*
ssc_core__qEXoys3NqhTc5aGZjoM0i;}ssc_core__CmZebP7mNptWDMef1TTIl;}
ssc_core_V01A11djsUSPhydgdGoEM8;struct{struct{char const*
ssc_core__EXYd0BpsApngXjCLU66Qq;char const*ssc_core_kaKiE6Wj2W0xjHCgFmOiEO;}
ssc_core_F0zPq17YGsWWY9f__3XLFE;struct{char const*
ssc_core__EXYd0BpsApngXjCLU66Qq;char const*ssc_core_kaKiE6Wj2W0xjHCgFmOiEO;
char const*ssc_core_V_r1xwjDx7lwguJ2YCpUai;}ssc_core__YmatZ07z0_k_ulppGYT3M;}
ssc_core_kCihPvTAZxpx_H5ihyr_kC;struct{char const*
ssc_core_kpMuDXM8W__FWaXECbGWgq;char const*ssc_core_kZL4P0QovRSWiqHRt1WIC6;}
ssc_core_VWYj_r5wXZ0gbi3aGkkirz;}ssc_core_VNb3dQocUud1ieYKQWZKSY;struct{struct
{char const*ssc_core_kTdqak9AqCGKcHj5IXmfZe;char const*
ssc_core__ZW8YII_QJ4wiHEnAMUOgB;char const*ssc_core__MNSKfpi3jteauByrrb2q7;}
ssc_core_kdx8eT3TLLtTjLxaVSammf;}ssc_core_Vb8i6ka6Ps0zj9AYvH4Qsj;struct{char
const*A;char const*mc_Vqiy96WqvuhCaXm5e_vvT0;char const*
ssc_core_FStFcQlyAJ_dVy4kGZXBPQ;char const*ssc_core_kyfq6L_eQbdYcPuOovpRDW;
char const*ssc_core_V8XMtcd13M8FjLV0KvZZWM;}ssc_core__l_QKzst7mxEcqpORUCYnt;};
extern struct ssc_core_kesYKdRukKtCYLfoQ0YRJ5 ssc_core_VrvQtlpclEKjVTpcoDIr6q;
struct ssc_core_kesYKdRukKtCYLfoQ0YRJ5 ssc_core_VrvQtlpclEKjVTpcoDIr6q={{
"... (Truncated error message at maximum length of buffer.)\n",
"Unexpected internal error: diagnostic error message requested but tree is empty."
,"%s",},{{{"Nonlinear projector failed to converge, residual norm too large.",
"Nonlinear projector is singular.",},{
"Linear projector failed due to the large residual norm.",
"Linear projector is singular.",},},{{"Constraints are inconsistent.",
"States are inconsistent.",},{"Constraints are inconsistent.",
"States are inconsistent.","Orthogonal projection is singular.",},},{
"Dynamic states are not consistent.",
"Failed to satisfy dynamic state constraints.",},},{{"Equation location is:",
"line %s","(no line number info)",},},{"Alice","Bob","Chris eats %s","Dan",
"Ernie",},};
