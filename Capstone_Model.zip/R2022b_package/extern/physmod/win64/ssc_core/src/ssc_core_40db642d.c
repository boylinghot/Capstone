#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
typedef enum ssc_core__4VOsIDToP0seTqpZ3OzBF{ssc_core_V6MH6x1to0xiZi0r6HsmD3= -
1,ssc_core_VDWQ52Z_V_4ce51ah_UGdx,ssc_core_koP_545U7Zp5Ymq02vu8dY,
ssc_core__2lwYHDzLZOn_X5J_fTSrd}ssc_core__4VOsIDToP0seTqpZ3OzBF;
ssc_core__4VOsIDToP0seTqpZ3OzBF ssc_core_FTzoitpYys8Aca2krGVZIS(void);void
ssc_core_VNQfrZTwQlSWia9xYHLPOQ(ssc_core__4VOsIDToP0seTqpZ3OzBF
ssc_core_VCMJww_KdPWKZDGZRw9nff);
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);static ssc_core__4VOsIDToP0seTqpZ3OzBF
ssc_core__1Jo0bV6AG8PZ1wy6_7ip6=ssc_core_koP_545U7Zp5Ymq02vu8dY;
ssc_core__4VOsIDToP0seTqpZ3OzBF ssc_core_FTzoitpYys8Aca2krGVZIS(void){return
ssc_core__1Jo0bV6AG8PZ1wy6_7ip6;}void ssc_core_VNQfrZTwQlSWia9xYHLPOQ(
ssc_core__4VOsIDToP0seTqpZ3OzBF ssc_core_VCMJww_KdPWKZDGZRw9nff){
ssc_core__1Jo0bV6AG8PZ1wy6_7ip6=ssc_core_VCMJww_KdPWKZDGZRw9nff;}
