#include "pm_std.h"
#include "pm_std.h"
#include "ne_std.h"
#include "ne_std.h"
typedef struct ssc_core__gGmO67Uzy_Yg1j4Tgxf21 ssc_core_FDsIo_8VzL4t_qzfDJ75HO
;struct ssc_core__gGmO67Uzy_Yg1j4Tgxf21{boolean_T
ssc_core_Vesiv0_gXg0M_XD5Q_eXiA;boolean_T ssc_core_kYRPIC8P4o8CYXme9CRbxR;
real_T ssc_core_kSsQH5I8Tk_lW9d8fx9Lty;};ssc_core_FDsIo_8VzL4t_qzfDJ75HO const
*ssc_core__Tt3am6uVLt_jPLjwFr_3t(void);void ssc_core_F_oGKTpAIFCoeiocJNRCTp(
ssc_core_FDsIo_8VzL4t_qzfDJ75HO const*ssc_core_kv7GnpbgsfSGjTKLxq5SvA);
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);static ssc_core_FDsIo_8VzL4t_qzfDJ75HO*
ssc_core__6HF7LrgXhS_ji8cLknH9T(void){static ssc_core_FDsIo_8VzL4t_qzfDJ75HO
ssc_core_kv7GnpbgsfSGjTKLxq5SvA={false,false,1.0e-10};return&
ssc_core_kv7GnpbgsfSGjTKLxq5SvA;}ssc_core_FDsIo_8VzL4t_qzfDJ75HO const*
ssc_core__Tt3am6uVLt_jPLjwFr_3t(void){return ssc_core__6HF7LrgXhS_ji8cLknH9T()
;}void ssc_core_F_oGKTpAIFCoeiocJNRCTp(ssc_core_FDsIo_8VzL4t_qzfDJ75HO const*
ssc_core_kv7GnpbgsfSGjTKLxq5SvA){*ssc_core__6HF7LrgXhS_ji8cLknH9T()= *
ssc_core_kv7GnpbgsfSGjTKLxq5SvA;}
