#include "pm_std.h"
#include "lang_std.h"
#include "external_std.h"
#include "string.h"
#include "external_std.h"
#include "lang_std.h"
void slu_3d_nearest_nearest_process(real_T*inputPtsAndVal,const real_T*x1s,
const real_T*x2s,const real_T*x3s,const real_T*fs,const size_t*n){
scatteredprocess_3d(inputPtsAndVal,x1s,x2s,x3s,fs,*n);}void
slu_3d_nearest_nearest_process_custom_function_(void*out,const void*in){const
real_T*x1s=(const real_T*)((const void*const*)in)[0];const real_T*x2s=(const
real_T*)((const void*const*)in)[1];const real_T*x3s=(const real_T*)((const void
*const*)in)[2];const real_T*fs=(const real_T*)((const void*const*)in)[3];const
size_t*n=(const size_t*)((const void*const*)in)[4];real_T*inputPtsAndVal=(
real_T*)out;slu_3d_nearest_nearest_process(inputPtsAndVal,x1s,x2s,x3s,fs,n);}
void slu_3d_nearest_linear_process(real_T*inputPtsAndVal,const real_T*x1s,
const real_T*x2s,const real_T*x3s,const real_T*fs,const size_t*n){
scatteredprocess_3d(inputPtsAndVal,x1s,x2s,x3s,fs,*n);}void
slu_3d_nearest_linear_process_custom_function_(void*out,const void*in){const
real_T*x1s=(const real_T*)((const void*const*)in)[0];const real_T*x2s=(const
real_T*)((const void*const*)in)[1];const real_T*x3s=(const real_T*)((const void
*const*)in)[2];const real_T*fs=(const real_T*)((const void*const*)in)[3];const
size_t*n=(const size_t*)((const void*const*)in)[4];real_T*inputPtsAndVal=(
real_T*)out;slu_3d_nearest_linear_process(inputPtsAndVal,x1s,x2s,x3s,fs,n);}
void slu_3d_nearest_nearest_value(real_T*fi,const real_T*inputPtsAndVal,const
real_T*x1query,const real_T*x2query,const real_T*x3query,const size_t*numPts,
const size_t*numels){if(coplanarcheck_3d(inputPtsAndVal,*numPts)){return;}
scatteredlookup_3d(fi,inputPtsAndVal,x1query,x2query,x3query,*numPts,*numels,
false,false);}void slu_3d_nearest_nearest_value_custom_function_(void*out,
const void*in){const real_T*inputPtsAndVal=(const void*)((const void*const*)in
)[0];const real_T*x1=(const real_T*)((const void*const*)in)[1];const real_T*x2
=(const real_T*)((const void*const*)in)[2];const real_T*x3=(const real_T*)((
const void*const*)in)[3];const size_t*numPts=(const size_t*)((const void*const
*)in)[4];const size_t*numels=(const size_t*)((const void*const*)in)[5];real_T*
fi=(real_T*)out;slu_3d_nearest_nearest_value(fi,inputPtsAndVal,x1,x2,x3,numPts
,numels);}void slu_3d_nearest_linear_value(real_T*fi,const real_T*
inputPtsAndVal,const real_T*x1query,const real_T*x2query,const real_T*x3query,
const size_t*numPts,const size_t*numels){if(coplanarcheck_3d(inputPtsAndVal,*
numPts)){return;}scatteredlookup_3d(fi,inputPtsAndVal,x1query,x2query,x3query,
*numPts,*numels,false,true);}void slu_3d_nearest_linear_value_custom_function_
(void*out,const void*in){const real_T*inputPtsAndVal=(const void*)((const void
*const*)in)[0];const real_T*x1=(const real_T*)((const void*const*)in)[1];const
real_T*x2=(const real_T*)((const void*const*)in)[2];const real_T*x3=(const
real_T*)((const void*const*)in)[3];const size_t*numPts=(const size_t*)((const
void*const*)in)[4];const size_t*numels=(const size_t*)((const void*const*)in)[
5];real_T*fi=(real_T*)out;slu_3d_nearest_linear_value(fi,inputPtsAndVal,x1,x2,
x3,numPts,numels);}void slu_3d_nearest_nearest_derivatives(real_T*gi,const
real_T*inputPtsAndVal,const real_T*x1query,const real_T*x2query,const real_T*
x3query,const size_t*numPts,const size_t*numels){if(coplanarcheck_3d(
inputPtsAndVal,*numPts)){return;}scatteredderivatives_3d(gi,inputPtsAndVal,
x1query,x2query,x3query,*numPts,*numels,false,false);}void
slu_3d_nearest_nearest_derivatives_custom_function_(void*out,const void*in){
const real_T*inputPtsAndVal=(const real_T*)((const void*const*)in)[0];const
real_T*x1=(const real_T*)((const void*const*)in)[1];const real_T*x2=(const
real_T*)((const void*const*)in)[2];const real_T*x3=(const real_T*)((const void
*const*)in)[3];const size_t*numPts=(const size_t*)((const void*const*)in)[4];
const size_t*numels=(const size_t*)((const void*const*)in)[5];real_T*gi=(
real_T*)out;slu_3d_nearest_nearest_derivatives(gi,inputPtsAndVal,x1,x2,x3,
numPts,numels);}void slu_3d_nearest_linear_derivatives(real_T*gi,const real_T*
inputPtsAndVal,const real_T*x1query,const real_T*x2query,const real_T*x3query,
const size_t*numPts,const size_t*numels){if(coplanarcheck_3d(inputPtsAndVal,*
numPts)){return;}scatteredderivatives_3d(gi,inputPtsAndVal,x1query,x2query,
x3query,*numPts,*numels,false,true);}void
slu_3d_nearest_linear_derivatives_custom_function_(void*out,const void*in){
const real_T*inputPtsAndVal=(const real_T*)((const void*const*)in)[0];const
real_T*x1=(const real_T*)((const void*const*)in)[1];const real_T*x2=(const
real_T*)((const void*const*)in)[2];const real_T*x3=(const real_T*)((const void
*const*)in)[3];const size_t*numPts=(const size_t*)((const void*const*)in)[4];
const size_t*numels=(const size_t*)((const void*const*)in)[5];real_T*gi=(
real_T*)out;slu_3d_nearest_linear_derivatives(gi,inputPtsAndVal,x1,x2,x3,
numPts,numels);}
