#include "stddef.h"
size_t ex_VF6BzpGacs_E_9CXFHed_I(const size_t*ex_F2l4p_g4sn02huHNflQjMH,const
size_t ex_F3nVSXkoDK8VeeL5OmY0_B);void ex_kw_oFrpzPH_7eyJRzldHYQ(size_t*
ex_F2l4p_g4sn02huHNflQjMH,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B);void
ex_FdOINfzBl14LhHoPJjZvQg(const size_t*ex_kxydxYiH7Klu_5VxWpaRqo,const size_t
ex_F9XXYvbW1X_RXP6D2uUU48,size_t*ex_FxajFA_1TahGZXVH9j9Gmx,size_t*
ex_VP6UMDxcGrpRcThEcmqI0C,size_t*ex_kaClFa7GFotAhac1oMBMZn);size_t
ex_VF6BzpGacs_E_9CXFHed_I(const size_t*ex_F2l4p_g4sn02huHNflQjMH,const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B){size_t ex_FEa9HpQub3K9X1Fkj0Fvl_=0;size_t
ex_Vqiy96WqvuhCaXm5e_vvT0=1;for(ex_FEa9HpQub3K9X1Fkj0Fvl_=0;
ex_FEa9HpQub3K9X1Fkj0Fvl_<ex_F3nVSXkoDK8VeeL5OmY0_B;++
ex_FEa9HpQub3K9X1Fkj0Fvl_){ex_Vqiy96WqvuhCaXm5e_vvT0*=
ex_F2l4p_g4sn02huHNflQjMH[ex_FEa9HpQub3K9X1Fkj0Fvl_];}return
ex_Vqiy96WqvuhCaXm5e_vvT0;}void ex_kw_oFrpzPH_7eyJRzldHYQ(size_t*
ex_F2l4p_g4sn02huHNflQjMH,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B){size_t
pm__lqjegyKuwStj56WZLiC_e,t,ex_FEa9HpQub3K9X1Fkj0Fvl_;
pm__lqjegyKuwStj56WZLiC_e=1;for(ex_FEa9HpQub3K9X1Fkj0Fvl_=0;
ex_FEa9HpQub3K9X1Fkj0Fvl_<ex_F3nVSXkoDK8VeeL5OmY0_B;++
ex_FEa9HpQub3K9X1Fkj0Fvl_){t=ex_F2l4p_g4sn02huHNflQjMH[
ex_FEa9HpQub3K9X1Fkj0Fvl_];ex_F2l4p_g4sn02huHNflQjMH[ex_FEa9HpQub3K9X1Fkj0Fvl_
]=pm__lqjegyKuwStj56WZLiC_e;pm__lqjegyKuwStj56WZLiC_e*=t;}}void
ex_FdOINfzBl14LhHoPJjZvQg(const size_t*ex_kxydxYiH7Klu_5VxWpaRqo,const size_t
ex_F9XXYvbW1X_RXP6D2uUU48,size_t*ex_FxajFA_1TahGZXVH9j9Gmx,size_t*
ex_VP6UMDxcGrpRcThEcmqI0C,size_t*ex_kaClFa7GFotAhac1oMBMZn){*
ex_FxajFA_1TahGZXVH9j9Gmx=ex_VF6BzpGacs_E_9CXFHed_I(ex_kxydxYiH7Klu_5VxWpaRqo,
ex_F9XXYvbW1X_RXP6D2uUU48);*ex_kaClFa7GFotAhac1oMBMZn=
ex_kxydxYiH7Klu_5VxWpaRqo[ex_F9XXYvbW1X_RXP6D2uUU48];*
ex_VP6UMDxcGrpRcThEcmqI0C=(*ex_FxajFA_1TahGZXVH9j9Gmx)*(*
ex_kaClFa7GFotAhac1oMBMZn);}
