#include "pm_std.h"
#include "lang_std.h"
real_T ex_kpX___S1Lgx3hu0ti95uMw(const real_T*a,const size_t n);real_T
ex_VCMYZqH7FzWLWPHooBByoI(const real_T x);real_T*ex_VQMmQUcKA3_3ei3Owj7WVV(
const real_T*x);size_t*ex__ge8CPdYTqKVfmxfN0MdXT(const size_t*x);void
ex_ktEh0_dPE7WMZaXpgviZfL(real_T*fx1,real_T*ex__rg5CXJeg_Cndu5WDoxbMl,real_T*
ex_V5xxz05F7a_ihqj30K8FAv,real_T*ex_FNXAh_ftg_KpWeXlYDyRqE,const real_T*x1,
const real_T*f,const size_t n1,const size_t n2,const size_t n3,const size_t n4
,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH
,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT
,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45
,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn
,const size_t ex__dZ6arJEU5pmV9XKy8etwi,const size_t ex_VvovjV_Yc_G4fP1XodrLft
,const size_t ex_VhUgI4c0k9GOgm8dFTThdK,const size_t ex_Fsdzbs_wz00cfyfchwr6K7
,const real_T ex_V4NyKkWjXNKyiujQkyTHSS);void ex_VKUiWhgLteGl_1sCHRJXum(real_T
*ex_k8zBiCVRtSWw_L3ohL9ZU6,real_T*ex__q3Je3USIpxhYaV_bmlNgE,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF);void ex_F7_9Sgo0sqlceT8kkrDtm9(real_T*
ex_kESK0x0mPXxyfXNDYQuNSo,real_T*ex__idLDQm5dX_uePEg9ek_dK,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t ex__Et5EUn_AfCGcaoPYM3rE7,const size_t
ex_VRc9H9oEh84hXu9Yu4okxd,const size_t ex__vFO6imE0nOcdTAyK5nWZf,const size_t
ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t ex_k64KfxW_YeCBd1Jcztnal5,const size_t
ex_FpCuD8p2g1ldYupGLDualI,const size_t ex_F4NwsNKf_S_ubm278AmjEt,const size_t
ex_VzS__hA47OtneLeQmJKhJU,const size_t ex_VseJVSrhmHl_fHMdqZQUoK,const size_t
ex__zov1f51H_xVZDV3hSAwLo,const size_t ex__UCiJ_ovpi8viepU66XSz1,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS,const real_T ex__QgqlEW2f18scLxPhDEnMF,const real_T
ex__yrlSbVOXjWXaTMEdN9cIu);void ex_Futd5IPo6_Sea16WtbGVmf(real_T*
ex__nq35K78gNGYiPqAi6FlY1,real_T*ex_k7clpQTkJip2cDihM27xMo,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const real_T*
ex__4uaYPi3B7txZPrRD2z8ek,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const size_t ex_VzS__hA47OtneLeQmJKhJU,const size_t
ex_VseJVSrhmHl_fHMdqZQUoK,const size_t ex__zov1f51H_xVZDV3hSAwLo,const size_t
ex__UCiJ_ovpi8viepU66XSz1,const size_t ex_FDTDXUQhgm_eYmdJ8sNRVZ,const size_t
ex_VlNl_tKLFzxvYHI0dZ9wzf,const size_t ex_kiGZSX33fPpmaucBO5il15,const size_t
ex__1tnMVPyaKpZeawGCX2ExG,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF,const real_T ex__yrlSbVOXjWXaTMEdN9cIu,const real_T
ex_F1sFV5GwlJdShuwH_gb9cU);size_t ex_F0HBEJ7qD9OkfDK6FdP9lf(real_T*basis,const
size_t derivativeOrder,const real_T*x,const size_t n,const real_T t,const
size_t ex_F_tm5fod4xxuguhS49BSQm);
#include "pm_std.h"
size_t ex_FSBp3lkv5gpCXL2yT9vLNh(const real_T*x,const size_t n,const real_T t)
;void ex_kGRJvwU4WMthWL53sjRCpO(real_T*ex_F2l4p_g4sn02huHNflQjMH,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT);void
ex_FtfBZE2kLGxyWamCvlRfeQ(real_T*x,real_T*f,const size_t n);void
ex_F4LajttG6uGtbXBJgUNQpW(real_T*x1,real_T*x2,real_T*f,const size_t n1,const
size_t n2);void ex_kIBgcKPC9nhchTKovcabSa(real_T*x1,real_T*x2,real_T*x3,real_T
*f,const size_t n1,const size_t n2,const size_t n3);void
ex_F_6wSEEsvm_1cTAuvwDt9B(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*f,
const size_t n1,const size_t n2,const size_t n3,const size_t n4);
#include "stddef.h"
void ex_kdH1Hb3ZR9_6cqIDW1RDok(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const
size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double**ex_VToqGBrino_cYuTsjsb5G7,const
double*ex_VsAv95vpmFp3i1E54_unM9,double*work1,size_t*work2,double*
ex_koSOkfGA3wCTgD7UMHzVC6);void ex_Vt43VeczGdCdVuEpZQh81F(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t
ex__Qhq8A0DwpCxayd3Wx4meP,double*ex__g9rIuQqKUWtZastp1XFl9,size_t*
ex_ked9tdolvUCd_PP3XHAAJ5,double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t
ex__NJXN1LXJ3dhZPDo3_p2LH,const double**ex_keuqc0JkC8SQZLp7wSGmG6,size_t**
ex_Vic4f_t1_8lMdPxTHOuua8,double*ex__zQbdTEDftlFdLWYhMGZcH);void
ex_VUv5qERYa5OL_DZXviEVuZ(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const double*ex__DeeKqxVkgxqhHgsvRavsg
,const size_t*ex_Vic4f_t1_8lMdPxTHOuua8,double*ex_kKG_5OBKXuhncyckTip21X);void
ex__I__tR3HVGtUdmAFtUcU_G(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,const double**ex_VToqGBrino_cYuTsjsb5G7,const size_t
ex_F_tm5fod4xxuguhS49BSQm,double*ex_koSOkfGA3wCTgD7UMHzVC6,double**
ex_kKG_5OBKXuhncyckTip21X,double*work1,size_t*work2,const size_t
ex__NJXN1LXJ3dhZPDo3_p2LH,const double**ex_keuqc0JkC8SQZLp7wSGmG6,size_t**
ex_Vic4f_t1_8lMdPxTHOuua8,double*ex__zQbdTEDftlFdLWYhMGZcH);void
ex_k3a7efHitoCaVqpYN7YToy(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const double*ex__DeeKqxVkgxqhHgsvRavsg
,size_t*ex_Vic4f_t1_8lMdPxTHOuua8);void ex_kEWp_Qwr9TpuV5h0iCW4f_(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const double*ex_VsAv95vpmFp3i1E54_unM9,double*work1
,size_t*work2,double*ex_koSOkfGA3wCTgD7UMHzVC6);void ex_Vs9jGA8_KnhLXD1GzoOLPW
(const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const double*x,const double*v,double*
ex__UNT5rIVeICNXTfUhGCl8W,double*ex_koSOkfGA3wCTgD7UMHzVC6);void
ex__KeFoQApKT8cgHlyO01BeY(const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const double*
x,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const
double*ex__DeeKqxVkgxqhHgsvRavsg,const size_t*ex_Vic4f_t1_8lMdPxTHOuua8,double
*ex_F1rQUll_EnhbfeQZPiHn_s);double ex_V7K1AhcbGYxBXLLX4NJH5f(const double a);
size_t ex_VP1AIhBqhr8UjPFzg_S70e(const double*x,const size_t n,const double
ex__DeeKqxVkgxqhHgsvRavsg);size_t ex__h_X9bmrQK0Rg9mXMtm6iz(const double*x,
const size_t ex_V5LBNJCbhICNbmMG_hLaZ6);size_t ex___xN3n8gXlhcdqFMCs70RT(const
double**ex_VToqGBrino_cYuTsjsb5G7,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const
size_t ex_F3nVSXkoDK8VeeL5OmY0_B);static void ex_k_2QXK6EeApGc5b2kk69De(const
real_T*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const size_t
ex_F_tm5fod4xxuguhS49BSQm,const size_t ex_kVmXCLOWIsl8g9qIcJoi92,const real_T
ex__DeeKqxVkgxqhHgsvRavsg,const size_t*ex_Vic4f_t1_8lMdPxTHOuua8,real_T*
ex_kKG_5OBKXuhncyckTip21X);real_T*ex_VQMmQUcKA3_3ei3Owj7WVV(const real_T*x){
union ex_V6Aph6cTe6h5e9bv641cKL{real_T*v;const real_T*
ex_V94OHC32_a85j1a8nI0gLx;}ex__4ya5UYw8IpEjXRgENiB8s;ex__4ya5UYw8IpEjXRgENiB8s
.ex_V94OHC32_a85j1a8nI0gLx=x;return ex__4ya5UYw8IpEjXRgENiB8s.v;}size_t*
ex__ge8CPdYTqKVfmxfN0MdXT(const size_t*x){union ex_FTjsS23X3LCCdLB1ATH2g7{
size_t*v;const size_t*ex_V94OHC32_a85j1a8nI0gLx;}ex_koVEIOVQ7YKpgLI1DDze9g;
ex_koVEIOVQ7YKpgLI1DDze9g.ex_V94OHC32_a85j1a8nI0gLx=x;return
ex_koVEIOVQ7YKpgLI1DDze9g.v;}size_t ex_F0HBEJ7qD9OkfDK6FdP9lf(real_T*basis,
const size_t derivativeOrder,const real_T*x,const size_t n,const real_T t,
const size_t ex_F_tm5fod4xxuguhS49BSQm){const size_t ex__NJXN1LXJ3dhZPDo3_p2LH
=1;size_t bin;ex_k3a7efHitoCaVqpYN7YToy(x,n,ex__NJXN1LXJ3dhZPDo3_p2LH,&t,&bin)
;if(derivativeOrder==0){ex_VUv5qERYa5OL_DZXviEVuZ(x,n,
ex_F_tm5fod4xxuguhS49BSQm+1,1,ex__NJXN1LXJ3dhZPDo3_p2LH,&t,&bin,basis);}else if
(derivativeOrder==1){ex_VUv5qERYa5OL_DZXviEVuZ(x,n,ex_F_tm5fod4xxuguhS49BSQm+1
,0,ex__NJXN1LXJ3dhZPDo3_p2LH,&t,&bin,basis);}else{ex_k_2QXK6EeApGc5b2kk69De(x,
n,ex_F_tm5fod4xxuguhS49BSQm+1,derivativeOrder,t,&bin,basis);}return bin;}
static void ex_k_2QXK6EeApGc5b2kk69De(const real_T*x,const size_t
ex_V5LBNJCbhICNbmMG_hLaZ6,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t
ex_kVmXCLOWIsl8g9qIcJoi92,const real_T ex__DeeKqxVkgxqhHgsvRavsg,const size_t*
ex_Vic4f_t1_8lMdPxTHOuua8,real_T*ex_kKG_5OBKXuhncyckTip21X){real_T
ex_V6t5zV_jpC0KdeBXmkcSMH,ex_FoIVqaGJ_Dpacunbx3i0aa,ex_FbsQgTbTj_WyWmwpJMp5ds,
ex_FQferGZUKft3_i5GvYy4Oy;real_T*H1= &ex_kKG_5OBKXuhncyckTip21X[0];real_T*H2= &
ex_kKG_5OBKXuhncyckTip21X[1];real_T*H3= &ex_kKG_5OBKXuhncyckTip21X[2];real_T*
H4= &ex_kKG_5OBKXuhncyckTip21X[3];size_t b=ex_Vic4f_t1_8lMdPxTHOuua8?*
ex_Vic4f_t1_8lMdPxTHOuua8:ex_VP1AIhBqhr8UjPFzg_S70e(x,
ex_V5LBNJCbhICNbmMG_hLaZ6,ex__DeeKqxVkgxqhHgsvRavsg);if(
ex_V5LBNJCbhICNbmMG_hLaZ6<3&&ex_F_tm5fod4xxuguhS49BSQm!=1){*H1=0.0;*H2=0.0;*H3
=0.0;*H4=0.0;}else{if(ex_F_tm5fod4xxuguhS49BSQm>0&&(ex__DeeKqxVkgxqhHgsvRavsg<
x[0]||ex__DeeKqxVkgxqhHgsvRavsg>x[ex_V5LBNJCbhICNbmMG_hLaZ6-1])){*H1=0.0;*H2=
0.0;*H3=0.0;*H4=0.0;}else{ex_V6t5zV_jpC0KdeBXmkcSMH=x[b+1]-x[b];
ex_FoIVqaGJ_Dpacunbx3i0aa=ex_V6t5zV_jpC0KdeBXmkcSMH*ex_V6t5zV_jpC0KdeBXmkcSMH;
ex_FbsQgTbTj_WyWmwpJMp5ds=ex_FoIVqaGJ_Dpacunbx3i0aa*ex_V6t5zV_jpC0KdeBXmkcSMH;
ex_FQferGZUKft3_i5GvYy4Oy=(ex__DeeKqxVkgxqhHgsvRavsg-x[b])/
ex_V6t5zV_jpC0KdeBXmkcSMH;if(ex_kVmXCLOWIsl8g9qIcJoi92==2){*H1=(12*
ex_FQferGZUKft3_i5GvYy4Oy-6)/ex_FoIVqaGJ_Dpacunbx3i0aa;*H2=(6*
ex_FQferGZUKft3_i5GvYy4Oy-4)/ex_V6t5zV_jpC0KdeBXmkcSMH;*H3= -*H1;*H4=(6*
ex_FQferGZUKft3_i5GvYy4Oy-2)/ex_V6t5zV_jpC0KdeBXmkcSMH;}else if(
ex_kVmXCLOWIsl8g9qIcJoi92==3){*H1=12/ex_FbsQgTbTj_WyWmwpJMp5ds;*H2=6/
ex_FoIVqaGJ_Dpacunbx3i0aa;*H3= -12/ex_FbsQgTbTj_WyWmwpJMp5ds;*H4=6/
ex_FoIVqaGJ_Dpacunbx3i0aa;}else{*H1=0.0;*H2=0.0;*H3=0.0;*H4=0.0;}}}}
