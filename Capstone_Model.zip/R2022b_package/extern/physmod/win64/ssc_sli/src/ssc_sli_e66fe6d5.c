#include "pm_std.h"
#include "mc_std.h"
const McLinearAlgebraFactory*ssc_sli_V3BDY5RWCQ8U_D_58cWpVo(void);
#include "string.h"
#include "pm_std.h"
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);int_T pm_kkW9oQAVI7Wt_9Rzuat5bx(
PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,size_t pm_keOJjiAyBTtFhyWf033kni,
size_t pm_kJxontPsxndNYXwDXdE1iy,size_t pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);PmSparsityPattern*pm_create_sparsity_pattern(size_t
pm_keOJjiAyBTtFhyWf033kni,size_t pm_kJxontPsxndNYXwDXdE1iy,size_t
pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kTFq3qlgTulWiT6pafkmmT(PmSparsityPattern*pm__56dBn4vKXWjZ1nclFRYZB,const
PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);boolean_T
pm__ZRI70SuGwhmamUtcsoyxS(const PmSparsityPattern*pm__56dBn4vKXWjZ1nclFRYZB,
const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);PmSparsityPattern*
pm_FQMLyYzCQ5CtgHjze1nNJP(const PmSparsityPattern*pm__HVqeFmd5gKdguw04VZTsk,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_FvcKvutPfxG9Xe1kjs7gg0(
PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);void pm_VYooJBURCwKrVu6RXzQZ_5(PmSparsityPattern*
pm__6H5I5OnY3KoY5YVL6mLgG,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm__YwdRBXissh3bPWPl30Fpe(size_t pm_FW8nEXbTFjdJhTIKepsgFT,
size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm_FFniD_kRQg_JWTYc5cmjGs(size_t pm_FW8nEXbTFjdJhTIKepsgFT,
size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm_FhqtSrxlPotrcypQHJ9Dcq(size_t pm__lqjegyKuwStj56WZLiC_e,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*
pm__TNI3M36rThlaTetY4tWiB(size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_Vv4EJYeJDW0yZXiH42yCA_(const PmIntVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmIntVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0)
;void mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void mc_k2E2oWXDqshMeuCQWrbaKT
(const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);void
mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void
mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa);PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const
PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);
#include "pm_std.h"
#include "mc_std.h"
PmfMessageId mc_kfurBusHpmK3ii_yoisMKW(PmSparsityPattern**
mc_VLr_Ia18P_8icXM9WFOfYI,PmRealVector**mc_FXE5BOU2zapujDAvVByFCm,const
PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z);typedef struct
mc_FR4LZYN36HhAbXQciJKg4b mc_kbNZS6WABdpGXqIUWG8uHD;typedef struct
mc_F4xoGyxlc8C2i1wN43AI_h mc_VvIMaZZGi8CxWLrLDuE1VI;struct
mc_F4xoGyxlc8C2i1wN43AI_h{mc_kbNZS6WABdpGXqIUWG8uHD*mPrivateData;
McLinearAlgebraStatus(*mFactor)(mc_VvIMaZZGi8CxWLrLDuE1VI*,const real_T*);
PmfMessageId(*mSolve)(mc_VvIMaZZGi8CxWLrLDuE1VI*mc__GvuTmhLl7xoeDFnehgZw6,
PmSparsityPattern**mc_kHHEpbrdfIWJVHI2ZlxK22,PmRealVector**
mc_k3a0Qu5k3mdvXmV5mJLkVI,PmSparsityPattern*mc_VLr_Ia18P_8icXM9WFOfYI,
PmRealVector*mc_FXE5BOU2zapujDAvVByFCm);size_t(*mMemusage)(const
mc_VvIMaZZGi8CxWLrLDuE1VI*);void(*mDestructor)(mc_VvIMaZZGi8CxWLrLDuE1VI*);};
McLinearAlgebraStatus mc_FhCkJRmjeCKncXSqcrUlnc(mc_VvIMaZZGi8CxWLrLDuE1VI**
mc__xkURRHAa0_mdT34ydcjaI,const PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ);
struct McLinearAlgebraDataTag{PmSparsityPattern*ssc_sli_V5IQq4r_lx_4au004QC5wp
;PmRealVector*ssc_sli_FP_7eg41oRS0Y1xUxzoWKi;PmSparsityPattern*
mc_VbQ99XU_TKpEgX06wWPmmb;};static McLinearAlgebraData*
ssc_sli_FkXi4Wy4pEONduGvNlkClR(PmAllocator*pm__8zlSpb2Hixod149p2zadR,const
PmSparsityPattern*ssc_sli__nMMeWOrYSh_aXgWvg8TWf){McLinearAlgebraData*
mc__d1alWYexptL_X5HTFhbNK=(McLinearAlgebraData*)((pm__8zlSpb2Hixod149p2zadR)->
mCallocFcn((pm__8zlSpb2Hixod149p2zadR),(sizeof(McLinearAlgebraData)),(1)));
mc__d1alWYexptL_X5HTFhbNK->ssc_sli_V5IQq4r_lx_4au004QC5wp=
pm_FQMLyYzCQ5CtgHjze1nNJP(ssc_sli__nMMeWOrYSh_aXgWvg8TWf,
pm__8zlSpb2Hixod149p2zadR);mc__d1alWYexptL_X5HTFhbNK->
mc_VbQ99XU_TKpEgX06wWPmmb=NULL;mc__d1alWYexptL_X5HTFhbNK->
ssc_sli_FP_7eg41oRS0Y1xUxzoWKi=NULL;return mc__d1alWYexptL_X5HTFhbNK;}static
void ssc_sli__qxC7jVn5UWjXuaZ_766A_(McLinearAlgebraData*
mc__d1alWYexptL_X5HTFhbNK){PmAllocator*a=pm_default_allocator();if(
mc__d1alWYexptL_X5HTFhbNK->mc_VbQ99XU_TKpEgX06wWPmmb==NULL&&
mc__d1alWYexptL_X5HTFhbNK->ssc_sli_FP_7eg41oRS0Y1xUxzoWKi==NULL){return;}(void
)0;;pm_VYooJBURCwKrVu6RXzQZ_5(mc__d1alWYexptL_X5HTFhbNK->
mc_VbQ99XU_TKpEgX06wWPmmb,a);pm_destroy_real_vector(mc__d1alWYexptL_X5HTFhbNK
->ssc_sli_FP_7eg41oRS0Y1xUxzoWKi,a);mc__d1alWYexptL_X5HTFhbNK->
mc_VbQ99XU_TKpEgX06wWPmmb=NULL;mc__d1alWYexptL_X5HTFhbNK->
ssc_sli_FP_7eg41oRS0Y1xUxzoWKi=NULL;}static McLinearAlgebraStatus
ssc_sli_kX_j3xjJJSWZYy8EWtNRxA(McLinearAlgebra*la,const real_T*
mc_kcMuz7xytzhifPfhbjJNYL){PmAllocator*a=pm_default_allocator();
McLinearAlgebraData*mc__d1alWYexptL_X5HTFhbNK=la->mPrivateData;
PmSparsityPattern*ssc_sli__lvtKVZR4zCv_D_Nbrh4eH=NULL;PmRealVector*
ssc_sli_V6FhGIVTzpShcDJLWyanvy=NULL;PmRealVector ssc_sli_FWhng0zRmbKmaDUHM4cjDt
;PmfMessageId id;ssc_sli__qxC7jVn5UWjXuaZ_766A_(mc__d1alWYexptL_X5HTFhbNK);
ssc_sli_FWhng0zRmbKmaDUHM4cjDt.mN=((size_t)(mc__d1alWYexptL_X5HTFhbNK->
ssc_sli_V5IQq4r_lx_4au004QC5wp)->mJc[(mc__d1alWYexptL_X5HTFhbNK->
ssc_sli_V5IQq4r_lx_4au004QC5wp)->mNumCol]);memcpy(&(
ssc_sli_FWhng0zRmbKmaDUHM4cjDt.mX),&mc_kcMuz7xytzhifPfhbjJNYL,sizeof(real_T*))
;id=mc_kfurBusHpmK3ii_yoisMKW(&ssc_sli__lvtKVZR4zCv_D_Nbrh4eH,&
ssc_sli_V6FhGIVTzpShcDJLWyanvy,mc__d1alWYexptL_X5HTFhbNK->
ssc_sli_V5IQq4r_lx_4au004QC5wp,&ssc_sli_FWhng0zRmbKmaDUHM4cjDt,a);if(id!=NULL)
{return MC_LA_ERROR;}mc__d1alWYexptL_X5HTFhbNK->ssc_sli_FP_7eg41oRS0Y1xUxzoWKi
=ssc_sli_V6FhGIVTzpShcDJLWyanvy;mc__d1alWYexptL_X5HTFhbNK->
mc_VbQ99XU_TKpEgX06wWPmmb=ssc_sli__lvtKVZR4zCv_D_Nbrh4eH;return MC_LA_OK;}
static McLinearAlgebraStatus ssc_sli_knf_j_qYjgWtj1JZqj1vxE(McLinearAlgebra*la
,const real_T*mc_kcMuz7xytzhifPfhbjJNYL,real_T*mc_FzyLWRgau0pMYq2XSI3ETL,const
real_T*mc_Fe6copTTRcKEayCm87ABO_){McLinearAlgebraData*
mc__d1alWYexptL_X5HTFhbNK=la->mPrivateData;size_t
ssc_sli__jwySfHyx1SXgXJeVWoIzb=mc__d1alWYexptL_X5HTFhbNK->
mc_VbQ99XU_TKpEgX06wWPmmb->mNumCol;size_t ssc_sli_FdNKyaRLqeWhg5tGqF_VYT=
mc__d1alWYexptL_X5HTFhbNK->mc_VbQ99XU_TKpEgX06wWPmmb->mNumRow;size_t
mc_kyp6uAyJE40UVuAQNEYzS1=0;int32_T*ssc_sli_kXeDcvuOSpSqamcA4a5jc_=
mc__d1alWYexptL_X5HTFhbNK->mc_VbQ99XU_TKpEgX06wWPmmb->mJc;int32_T*
ssc_sli_VEXzFHKjFN87iiOtLrddNz=mc__d1alWYexptL_X5HTFhbNK->
mc_VbQ99XU_TKpEgX06wWPmmb->mIr;int32_T ssc_sli_kjn0E4w0eVx6eL0BQDhSHC=0;real_T
ssc_sli_ki7hrZo4pcp4XHLfu5jXC2=0.0;real_T*A=mc__d1alWYexptL_X5HTFhbNK->
ssc_sli_FP_7eg41oRS0Y1xUxzoWKi->mX;for(mc_kyp6uAyJE40UVuAQNEYzS1=0;
mc_kyp6uAyJE40UVuAQNEYzS1<ssc_sli__jwySfHyx1SXgXJeVWoIzb;
mc_kyp6uAyJE40UVuAQNEYzS1++){mc_FzyLWRgau0pMYq2XSI3ETL[
mc_kyp6uAyJE40UVuAQNEYzS1]=0.0;}for(mc_kyp6uAyJE40UVuAQNEYzS1=0;
mc_kyp6uAyJE40UVuAQNEYzS1<ssc_sli__jwySfHyx1SXgXJeVWoIzb;
mc_kyp6uAyJE40UVuAQNEYzS1++){ssc_sli_ki7hrZo4pcp4XHLfu5jXC2=
mc_Fe6copTTRcKEayCm87ABO_[mc_kyp6uAyJE40UVuAQNEYzS1];for(
ssc_sli_kjn0E4w0eVx6eL0BQDhSHC=ssc_sli_kXeDcvuOSpSqamcA4a5jc_[
mc_kyp6uAyJE40UVuAQNEYzS1];ssc_sli_kjn0E4w0eVx6eL0BQDhSHC<
ssc_sli_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1+1];
ssc_sli_kjn0E4w0eVx6eL0BQDhSHC++){mc_FzyLWRgau0pMYq2XSI3ETL[
ssc_sli_VEXzFHKjFN87iiOtLrddNz[ssc_sli_kjn0E4w0eVx6eL0BQDhSHC]]+=
ssc_sli_ki7hrZo4pcp4XHLfu5jXC2*A[ssc_sli_kjn0E4w0eVx6eL0BQDhSHC];}}return
MC_LA_OK;}static real_T ssc_sli_F6XF_l1jP0l5aDWz1lORNm(const McLinearAlgebra*
la){(void)0;return 0.0;}static size_t ssc_sli_kj8l2pUJvydO_iFeja8XPy(const
PmSparsityPattern*pm__lqjegyKuwStj56WZLiC_e){return sizeof(*
pm__lqjegyKuwStj56WZLiC_e)+(pm__lqjegyKuwStj56WZLiC_e->mNumCol+1)*sizeof(
int32_T)+((size_t)(pm__lqjegyKuwStj56WZLiC_e)->mJc[(pm__lqjegyKuwStj56WZLiC_e)
->mNumCol])*sizeof(int32_T)+((size_t)(pm__lqjegyKuwStj56WZLiC_e)->mJc[(
pm__lqjegyKuwStj56WZLiC_e)->mNumCol])*sizeof(real_T);}static size_t
ssc_sli_kPuoq1AJGiC3eTfkQZ4_ow(const McLinearAlgebra*la){const
McLinearAlgebraData*mc__d1alWYexptL_X5HTFhbNK=la->mPrivateData;return sizeof(*
la)+sizeof(*mc__d1alWYexptL_X5HTFhbNK)+ssc_sli_kj8l2pUJvydO_iFeja8XPy(
mc__d1alWYexptL_X5HTFhbNK->ssc_sli_V5IQq4r_lx_4au004QC5wp)+(
mc__d1alWYexptL_X5HTFhbNK->ssc_sli_FP_7eg41oRS0Y1xUxzoWKi==NULL?0:(sizeof(*
mc__d1alWYexptL_X5HTFhbNK->ssc_sli_FP_7eg41oRS0Y1xUxzoWKi)+
mc__d1alWYexptL_X5HTFhbNK->ssc_sli_FP_7eg41oRS0Y1xUxzoWKi->mN*sizeof(real_T)))
+(mc__d1alWYexptL_X5HTFhbNK->mc_VbQ99XU_TKpEgX06wWPmmb==NULL?0:
ssc_sli_kj8l2pUJvydO_iFeja8XPy(mc__d1alWYexptL_X5HTFhbNK->
mc_VbQ99XU_TKpEgX06wWPmmb));}static void ssc_sli_FreBgtsuW2WgZiZgMHLo8w(
McLinearAlgebra*la){McLinearAlgebraData*mc__d1alWYexptL_X5HTFhbNK=la->
mPrivateData;PmAllocator*a=pm_default_allocator();
ssc_sli__qxC7jVn5UWjXuaZ_766A_(mc__d1alWYexptL_X5HTFhbNK);
pm_VYooJBURCwKrVu6RXzQZ_5(mc__d1alWYexptL_X5HTFhbNK->
ssc_sli_V5IQq4r_lx_4au004QC5wp,a);{void*ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(
mc__d1alWYexptL_X5HTFhbNK);if(ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->mFreeFcn
(a,ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};{void*ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(la
);if(ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->mFreeFcn(a,
ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};}static McLinearAlgebraStatus
ssc_sli_FqOMnhUEhcdqg1mnKgE_CS(const McLinearAlgebraFactory*
ssc_core__RtkHrrPEelBbDRCt5cBnV,McLinearAlgebra**
ssc_sli_kUiN9yDkl4dshyxp7WLjGd,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,size_t ssc_sli_VLfhtrJkZcWwhmTdEnSnSd){PmAllocator*
mc_FOGg0ZWot2WdYenO8zaD4Z=pm_default_allocator();McLinearAlgebra*la=(
McLinearAlgebra*)((mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((
mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(McLinearAlgebra)),(1)));la->mPrivateData=
ssc_sli_FkXi4Wy4pEONduGvNlkClR(mc_FOGg0ZWot2WdYenO8zaD4Z,
mc__srK5LmyWw42ZyPnbOWDWJ);la->mFactor= &ssc_sli_kX_j3xjJJSWZYy8EWtNRxA;la->
mSolve= &ssc_sli_knf_j_qYjgWtj1JZqj1vxE;la->mCondest= &
ssc_sli_F6XF_l1jP0l5aDWz1lORNm;la->mMemusage= &ssc_sli_kPuoq1AJGiC3eTfkQZ4_ow;
la->mDestructor= &ssc_sli_FreBgtsuW2WgZiZgMHLo8w;(void)
ssc_sli_VLfhtrJkZcWwhmTdEnSnSd;*ssc_sli_kUiN9yDkl4dshyxp7WLjGd=la;return
MC_LA_OK;}static McLinearAlgebraStatus ssc_sli_V2aRnyRjTYpMja2SJVy3tY(const
McLinearAlgebraFactory*ssc_core__RtkHrrPEelBbDRCt5cBnV,McLinearAlgebra**
ssc_sli_kUiN9yDkl4dshyxp7WLjGd,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ){return ssc_sli_FqOMnhUEhcdqg1mnKgE_CS(
ssc_core__RtkHrrPEelBbDRCt5cBnV,ssc_sli_kUiN9yDkl4dshyxp7WLjGd,
mc__srK5LmyWw42ZyPnbOWDWJ,mc__srK5LmyWw42ZyPnbOWDWJ->mNumCol);}const
McLinearAlgebraFactory*ssc_sli_V3BDY5RWCQ8U_D_58cWpVo(void){static
McLinearAlgebraFactory ssc_core__RtkHrrPEelBbDRCt5cBnV;
ssc_core__RtkHrrPEelBbDRCt5cBnV.mCreateLinearAlgebra= &
ssc_sli_V2aRnyRjTYpMja2SJVy3tY;ssc_core__RtkHrrPEelBbDRCt5cBnV.
mCreateLinearAlgebraComplete= &ssc_sli_FqOMnhUEhcdqg1mnKgE_CS;return&
ssc_core__RtkHrrPEelBbDRCt5cBnV;}
