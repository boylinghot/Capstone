#include "pm_std.h"
typedef struct ssc_sli__28p6olsru4xiqIfaE_RiC ssc_sli_FOrb4PPFSoK_hi2nVy3VBL;
typedef struct ssc_sli_kmFrp4sb0N0jaHdZVa1oKg ssc_sli__1xlryuXE3GZ_qfD65s3e5;
typedef struct ssc_sli_koZC_AD7LZ_IbiNyUwDqKf ssc_sli__4Qrk7zTCKGH_uT5yMtxFb;
typedef struct ssc_sli_Vp_by_y9ZNCLj5UqUuMeN1 ssc_sli__WiVbFarDU8XjH5EZWvHjo;
typedef struct ssc_sli__fCGVkCiKp_dc1cd5JD9bX{ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli_kIL_KFfePoCnfDe2C0CMSf;ssc_sli__1xlryuXE3GZ_qfD65s3e5*
ssc_sli_FQfFLTtYnStTbLV0vWkI1_;}ssc_sli_VNPPRKAwuP_2XLe3P7oDCX;typedef
ssc_sli_VNPPRKAwuP_2XLe3P7oDCX*(*ssc_sli__pfarM7qn_8vjP34PNJkPd)(const
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C,const
ssc_sli__1xlryuXE3GZ_qfD65s3e5*mc_kg4CyRgbu6OdeewZOel7Qx);typedef void(*
ssc_sli__2vkuizNtrKEjXQ_YgrN9I)(ssc_sli_VNPPRKAwuP_2XLe3P7oDCX*
ssc_sli_Ffuwa74dpf8ojLAepxw4J_);typedef boolean_T(*
ssc_sli_FPpqCGo7dG_CWPMYgpfMOT)(const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli_FfCY8UvszqllbmuW9guHFu,const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli__TqmG8jjnJKebDk2jZqjpu);typedef size_t(*ssc_sli_V20Dbnt95u_9VyLdMIxACc
)(const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C);struct
ssc_sli_Vp_by_y9ZNCLj5UqUuMeN1{ssc_sli__4Qrk7zTCKGH_uT5yMtxFb*
mc_VFNhKLCqbHpDYXjdjCOMmT;ssc_sli__pfarM7qn_8vjP34PNJkPd
ssc_sli__Qbg7_Jc06dChP6H_SqxN_;ssc_sli__2vkuizNtrKEjXQ_YgrN9I
ssc_sli_kDLakVdSbzCXdafXCC2h_j;ssc_sli_FPpqCGo7dG_CWPMYgpfMOT
ssc_sli_FQXGokx20f_4e1k_4jm6ws;ssc_sli_V20Dbnt95u_9VyLdMIxACc
ssc_sli_Fu4SrSNqTRGCiP8nz8RVGG;boolean_T(*ssc_sli__boAB0ih3e_1_1DklwbvAq)(
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_Vw6n82vFxcCU_q7gFoxaEB,const
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C,const
ssc_sli__1xlryuXE3GZ_qfD65s3e5*pm_kpzAtHMD4_WnheH0UiioSE);
ssc_sli__1xlryuXE3GZ_qfD65s3e5*(*ssc_sli_VXZ69cXJ5kC5c5S6UWjHzW)(const
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_Vw6n82vFxcCU_q7gFoxaEB,const
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C);void(*
ssc_core_VpMG2_8Z4c4aa9vd7AfjAl)(const ssc_sli__WiVbFarDU8XjH5EZWvHjo*
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_Vw6n82vFxcCU_q7gFoxaEB);};
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_VOXvLJcAVzdJjXMSM21cTM(size_t
ssc_sli_VEAd_yTYI2CecPuelr4g1q,size_t ssc_sli_FmSLM8NZxEGvcuj32Mvuj9,
ssc_sli__pfarM7qn_8vjP34PNJkPd ssc_sli_Fdywd4Ip2AK1b1kX9wRU6U,
ssc_sli__2vkuizNtrKEjXQ_YgrN9I ssc_sli_V7j0EcPDlHxSfXY9qu4eLP,
ssc_sli_FPpqCGo7dG_CWPMYgpfMOT ssc_sli__YKS6NEYIuh3eu5bFM1pdK,
ssc_sli_V20Dbnt95u_9VyLdMIxACc ssc_sli_VfV5vpftf8tYYDFWaGmw1A);
#include "math.h"
#include "pm_std.h"
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);
#include "pm_std.h"
struct ssc_sli_koZC_AD7LZ_IbiNyUwDqKf{size_t*ssc_sli_VRwrchOPmx_aaPlk6rQ511;
size_t ssc_sli_kT5bEQWHIzWd_mQA41X3IU;ssc_sli_VNPPRKAwuP_2XLe3P7oDCX**
ssc_sli__Nfc7SOHiJtEiHX_JSKSIP;size_t ssc_sli__FWV6ZeLA5dzd5vCjao8U6;size_t
mIndex;size_t ssc_sli_kLdIcDTuYaG7ZTpGcD7vSc,ssc_sli__lwbXEL_tcWxZaUoKyYIjy;
boolean_T ssc_sli__c0hfNEciPtShiA7w88poR;};static boolean_T
ssc_sli_FB_PBKzlFctmha0I88aVdP(ssc_sli__WiVbFarDU8XjH5EZWvHjo*
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB,const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli_kvBdBwVdJztaXPLz5_6q7C,const ssc_sli__1xlryuXE3GZ_qfD65s3e5*
mc_kg4CyRgbu6OdeewZOel7Qx){ssc_sli__4Qrk7zTCKGH_uT5yMtxFb*d=
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->mc_VFNhKLCqbHpDYXjdjCOMmT;size_t
ssc_sli__Tq1I4Sq29OZcT3ZIY6sh4,ssc_sli_FwN4M6fnkPWOamExJt9XLO;size_t
ssc_sli_VqkVSASAbe_qWyAF52V1nt;boolean_T ssc_sli_Fo_lutBLmDx1cy8pj853oL=false;
(void)0;;d->ssc_sli_kLdIcDTuYaG7ZTpGcD7vSc++;ssc_sli__Tq1I4Sq29OZcT3ZIY6sh4=
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->ssc_sli_Fu4SrSNqTRGCiP8nz8RVGG(
ssc_sli_kvBdBwVdJztaXPLz5_6q7C)%d->ssc_sli_kT5bEQWHIzWd_mQA41X3IU;
ssc_sli_VqkVSASAbe_qWyAF52V1nt=d->ssc_sli_VRwrchOPmx_aaPlk6rQ511[
ssc_sli__Tq1I4Sq29OZcT3ZIY6sh4];(void)0;;if(ssc_sli_VqkVSASAbe_qWyAF52V1nt==((
size_t)(-1))){ssc_sli_FwN4M6fnkPWOamExJt9XLO=d->mIndex;d->
ssc_sli_VRwrchOPmx_aaPlk6rQ511[ssc_sli__Tq1I4Sq29OZcT3ZIY6sh4]=
ssc_sli_FwN4M6fnkPWOamExJt9XLO;d->mIndex=(d->mIndex+1)%d->
ssc_sli__FWV6ZeLA5dzd5vCjao8U6;}else{(void)0;;ssc_sli_FwN4M6fnkPWOamExJt9XLO=
ssc_sli_VqkVSASAbe_qWyAF52V1nt;}if(d->ssc_sli__Nfc7SOHiJtEiHX_JSKSIP[
ssc_sli_FwN4M6fnkPWOamExJt9XLO]!=NULL){ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->
ssc_sli_kDLakVdSbzCXdafXCC2h_j(d->ssc_sli__Nfc7SOHiJtEiHX_JSKSIP[
ssc_sli_FwN4M6fnkPWOamExJt9XLO]);ssc_sli_Fo_lutBLmDx1cy8pj853oL=true;}d->
ssc_sli__Nfc7SOHiJtEiHX_JSKSIP[ssc_sli_FwN4M6fnkPWOamExJt9XLO]=
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->ssc_sli__Qbg7_Jc06dChP6H_SqxN_(
ssc_sli_kvBdBwVdJztaXPLz5_6q7C,mc_kg4CyRgbu6OdeewZOel7Qx);return
ssc_sli_Fo_lutBLmDx1cy8pj853oL;}static ssc_sli__1xlryuXE3GZ_qfD65s3e5*
ssc_sli_Fh74IwzEdNWV_yG9uPwtGF(const ssc_sli__WiVbFarDU8XjH5EZWvHjo*
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB,const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli_kvBdBwVdJztaXPLz5_6q7C){ssc_sli__4Qrk7zTCKGH_uT5yMtxFb*d=
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->mc_VFNhKLCqbHpDYXjdjCOMmT;size_t
ssc_sli__Tq1I4Sq29OZcT3ZIY6sh4;size_t ssc_sli_VqkVSASAbe_qWyAF52V1nt;d->
ssc_sli__lwbXEL_tcWxZaUoKyYIjy++;if(d->ssc_sli_kT5bEQWHIzWd_mQA41X3IU==1){if(d
->ssc_sli_VRwrchOPmx_aaPlk6rQ511[0]!=((size_t)(-1))){(void)0;;return d->
ssc_sli__Nfc7SOHiJtEiHX_JSKSIP[0]->ssc_sli_FQfFLTtYnStTbLV0vWkI1_;}else{return
NULL;}}ssc_sli__Tq1I4Sq29OZcT3ZIY6sh4=ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->
ssc_sli_Fu4SrSNqTRGCiP8nz8RVGG(ssc_sli_kvBdBwVdJztaXPLz5_6q7C)%d->
ssc_sli_kT5bEQWHIzWd_mQA41X3IU;ssc_sli_VqkVSASAbe_qWyAF52V1nt=d->
ssc_sli_VRwrchOPmx_aaPlk6rQ511[ssc_sli__Tq1I4Sq29OZcT3ZIY6sh4];if(
ssc_sli_VqkVSASAbe_qWyAF52V1nt!=((size_t)(-1))){(void)0;;(void)0;;if(
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->ssc_sli_FQXGokx20f_4e1k_4jm6ws(
ssc_sli_kvBdBwVdJztaXPLz5_6q7C,d->ssc_sli__Nfc7SOHiJtEiHX_JSKSIP[
ssc_sli_VqkVSASAbe_qWyAF52V1nt]->ssc_sli_kIL_KFfePoCnfDe2C0CMSf)){return d->
ssc_sli__Nfc7SOHiJtEiHX_JSKSIP[ssc_sli_VqkVSASAbe_qWyAF52V1nt]->
ssc_sli_FQfFLTtYnStTbLV0vWkI1_;}}return NULL;}static void
ssc_sli__6z9hrvjXuhHWiBoscNthU(const ssc_sli__WiVbFarDU8XjH5EZWvHjo*
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB){ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->
mc_VFNhKLCqbHpDYXjdjCOMmT->ssc_sli__c0hfNEciPtShiA7w88poR=true;}static void
ssc_sli_FhhLXcCtI5pfjiOVX8S89G(ssc_sli__WiVbFarDU8XjH5EZWvHjo*
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB){PmAllocator*a=pm_default_allocator();
ssc_sli__4Qrk7zTCKGH_uT5yMtxFb*d=ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->
mc_VFNhKLCqbHpDYXjdjCOMmT;size_t mc_kwrB3ZoKf7OufTHWaHJV7a;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<d->
ssc_sli__FWV6ZeLA5dzd5vCjao8U6;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(d->
ssc_sli__Nfc7SOHiJtEiHX_JSKSIP[mc_kwrB3ZoKf7OufTHWaHJV7a]!=NULL){
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->ssc_sli_kDLakVdSbzCXdafXCC2h_j(d->
ssc_sli__Nfc7SOHiJtEiHX_JSKSIP[mc_kwrB3ZoKf7OufTHWaHJV7a]);}}{void*
ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(d->ssc_sli__Nfc7SOHiJtEiHX_JSKSIP);if(
ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->mFreeFcn(a,
ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};{void*ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(d->
ssc_sli_VRwrchOPmx_aaPlk6rQ511);if(ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->
mFreeFcn(a,ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};{void*
ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(d);if(ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->
mFreeFcn(a,ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};{void*
ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(ssc_sli_Vw6n82vFxcCU_q7gFoxaEB);if(
ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->mFreeFcn(a,
ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};}ssc_sli__WiVbFarDU8XjH5EZWvHjo*
ssc_sli_VOXvLJcAVzdJjXMSM21cTM(size_t ssc_sli_VEAd_yTYI2CecPuelr4g1q,size_t
ssc_sli_FmSLM8NZxEGvcuj32Mvuj9,ssc_sli__pfarM7qn_8vjP34PNJkPd
ssc_sli_Fdywd4Ip2AK1b1kX9wRU6U,ssc_sli__2vkuizNtrKEjXQ_YgrN9I
ssc_sli_V7j0EcPDlHxSfXY9qu4eLP,ssc_sli_FPpqCGo7dG_CWPMYgpfMOT
ssc_sli__YKS6NEYIuh3eu5bFM1pdK,ssc_sli_V20Dbnt95u_9VyLdMIxACc
ssc_sli_VfV5vpftf8tYYDFWaGmw1A){PmAllocator*a=pm_default_allocator();
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_Vw6n82vFxcCU_q7gFoxaEB=(
ssc_sli__WiVbFarDU8XjH5EZWvHjo*)((a)->mCallocFcn((a),(sizeof(
ssc_sli__WiVbFarDU8XjH5EZWvHjo)),(1)));ssc_sli__4Qrk7zTCKGH_uT5yMtxFb*d=(
ssc_sli__4Qrk7zTCKGH_uT5yMtxFb*)((a)->mCallocFcn((a),(sizeof(
ssc_sli__4Qrk7zTCKGH_uT5yMtxFb)),(1)));size_t mc_kwrB3ZoKf7OufTHWaHJV7a;(void)
0;;d->ssc_sli_kT5bEQWHIzWd_mQA41X3IU=ssc_sli_VEAd_yTYI2CecPuelr4g1q;d->
ssc_sli__FWV6ZeLA5dzd5vCjao8U6=ssc_sli_FmSLM8NZxEGvcuj32Mvuj9;d->
ssc_sli_VRwrchOPmx_aaPlk6rQ511=(size_t*)((a)->mCallocFcn((a),(sizeof(size_t)),
(d->ssc_sli_kT5bEQWHIzWd_mQA41X3IU)));d->ssc_sli__Nfc7SOHiJtEiHX_JSKSIP=(
ssc_sli_VNPPRKAwuP_2XLe3P7oDCX**)((a)->mCallocFcn((a),(sizeof(
ssc_sli_VNPPRKAwuP_2XLe3P7oDCX*)),(d->ssc_sli__FWV6ZeLA5dzd5vCjao8U6)));for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<d->
ssc_sli_kT5bEQWHIzWd_mQA41X3IU;mc_kwrB3ZoKf7OufTHWaHJV7a++){d->
ssc_sli_VRwrchOPmx_aaPlk6rQ511[mc_kwrB3ZoKf7OufTHWaHJV7a]=((size_t)(-1));}for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<d->
ssc_sli__FWV6ZeLA5dzd5vCjao8U6;mc_kwrB3ZoKf7OufTHWaHJV7a++){d->
ssc_sli__Nfc7SOHiJtEiHX_JSKSIP[mc_kwrB3ZoKf7OufTHWaHJV7a]=NULL;}d->mIndex=0;d
->ssc_sli_kLdIcDTuYaG7ZTpGcD7vSc=0;d->ssc_sli__lwbXEL_tcWxZaUoKyYIjy=0;d->
ssc_sli__c0hfNEciPtShiA7w88poR=false;ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->
mc_VFNhKLCqbHpDYXjdjCOMmT=d;ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->
ssc_sli__Qbg7_Jc06dChP6H_SqxN_=ssc_sli_Fdywd4Ip2AK1b1kX9wRU6U;
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->ssc_sli_kDLakVdSbzCXdafXCC2h_j=
ssc_sli_V7j0EcPDlHxSfXY9qu4eLP;ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->
ssc_sli_FQXGokx20f_4e1k_4jm6ws=ssc_sli__YKS6NEYIuh3eu5bFM1pdK;
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->ssc_sli_Fu4SrSNqTRGCiP8nz8RVGG=
ssc_sli_VfV5vpftf8tYYDFWaGmw1A;ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->
ssc_sli__boAB0ih3e_1_1DklwbvAq=ssc_sli_FB_PBKzlFctmha0I88aVdP;
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->ssc_sli_VXZ69cXJ5kC5c5S6UWjHzW=
ssc_sli_Fh74IwzEdNWV_yG9uPwtGF;ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->
ssc_core_VpMG2_8Z4c4aa9vd7AfjAl=ssc_sli__6z9hrvjXuhHWiBoscNthU;
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB->mc_VYGWBho6N1K_eyHOMGjDiW=
ssc_sli_FhhLXcCtI5pfjiOVX8S89G;return ssc_sli_Vw6n82vFxcCU_q7gFoxaEB;}
