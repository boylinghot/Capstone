#include "pm_std.h"
#include "mc_std.h"
const McLinearAlgebraFactory*ssc_sli_Vo6yP2kZL8_UYHq0yxrj9D(size_t
ssc_sli__jwySfHyx1SXgXJeVWoIzb);
#include "mc_std.h"
const McLinearAlgebraFactory*mc_get_csparse_linear_algebra(void);
#include "mc_std.h"
#include "mc_std.h"
const McLinearAlgebraFactory*ssc_sli_V3BDY5RWCQ8U_D_58cWpVo(void);const
McLinearAlgebraFactory*ssc_sli_Vo6yP2kZL8_UYHq0yxrj9D(size_t
ssc_sli__jwySfHyx1SXgXJeVWoIzb){return ssc_sli__jwySfHyx1SXgXJeVWoIzb<7?
ssc_sli_V3BDY5RWCQ8U_D_58cWpVo():mc_get_csparse_linear_algebra();}
