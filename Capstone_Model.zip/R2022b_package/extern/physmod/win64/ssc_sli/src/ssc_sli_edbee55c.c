#include "pm_std.h"
void ssc_sli_ka2NE6yWjJxNVD_ZDZ_zhO(boolean_T mc__BdKVTewIl8TaXwgBW0hvv);
boolean_T ssc_sli_FvG_Xfp30uC6YidhCiaBel(void);static boolean_T
ssc_sli__by0oGDfpwGbhLq_ZpeRy2=false;void ssc_sli_ka2NE6yWjJxNVD_ZDZ_zhO(
boolean_T mc__BdKVTewIl8TaXwgBW0hvv){ssc_sli__by0oGDfpwGbhLq_ZpeRy2=
mc__BdKVTewIl8TaXwgBW0hvv;}boolean_T ssc_sli_FvG_Xfp30uC6YidhCiaBel(void){
return ssc_sli__by0oGDfpwGbhLq_ZpeRy2;}
