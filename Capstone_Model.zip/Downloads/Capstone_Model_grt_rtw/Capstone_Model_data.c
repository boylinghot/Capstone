/*
 * Capstone_Model_data.c
 *
 * Code generation for model "Capstone_Model".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri Mar 24 10:46:16 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "Capstone_Model.h"

/* Block parameters (default storage) */
P_Capstone_Model_T Capstone_Model_P = {
  /* Mask Parameter: Ramp_InitialOutput
   * Referenced by: '<S1>/Constant1'
   */
  0.0,

  /* Mask Parameter: Ramp_slope
   * Referenced by: '<S1>/Step'
   */
  1.0,

  /* Mask Parameter: Ramp_start
   * Referenced by:
   *   '<S1>/Constant'
   *   '<S1>/Step'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Constant'
   */
  0.0,

  /* Expression: 0.0
   * Referenced by: '<Root>/Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S1>/Step'
   */
  0.0,

  /* Expression: 2
   * Referenced by: '<Root>/Saturation'
   */
  2.0,

  /* Expression: 0
   * Referenced by: '<Root>/Saturation'
   */
  0.0
};
