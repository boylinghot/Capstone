/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_lock_r.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_lock_r(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t1, NeDsMethodOutput *t2)
{
  PmBoolVector out;
  real_T U_idx_0;
  int32_T CI_idx_0;
  int32_T CI_idx_1;
  int32_T CI_idx_2;
  int32_T CI_idx_3;
  boolean_T indicator0;
  boolean_T indicator1;
  U_idx_0 = t1->mU.mX[0];
  CI_idx_0 = t1->mCI.mX[0];
  CI_idx_1 = t1->mCI.mX[1];
  CI_idx_2 = t1->mCI.mX[2];
  CI_idx_3 = t1->mCI.mX[3];
  out = t2->mLOCK_R;
  if ((CI_idx_1 == 0) && (-U_idx_0 >= 0.5)) {
    indicator0 = true;
  } else {
    indicator0 = ((CI_idx_0 == 0) && (-U_idx_0 < 0.5));
  }

  if ((CI_idx_3 == 0) && (-U_idx_0 >= 0.5)) {
    indicator1 = true;
  } else {
    indicator1 = ((CI_idx_2 == 0) && (-U_idx_0 < 0.5));
  }

  out.mX[0] = indicator0;
  out.mX[1] = indicator0;
  out.mX[2] = indicator0;
  out.mX[3] = indicator0;
  out.mX[4] = indicator1;
  out.mX[5] = indicator1;
  out.mX[6] = indicator1;
  out.mX[7] = indicator1;
  (void)sys;
  (void)t2;
  return 0;
}
