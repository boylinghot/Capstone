/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_dtf.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_dtf(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t21, NeDsMethodOutput *t22)
{
  PmRealVector out;
  real_T D_idx_0;
  real_T D_idx_1;
  real_T D_idx_2;
  real_T D_idx_3;
  real_T D_idx_4;
  real_T D_idx_5;
  real_T D_idx_6;
  real_T D_idx_7;
  real_T T_idx_0;
  real_T X_idx_2;
  real_T X_idx_5;
  real_T intrm_sf_mf_1;
  real_T t1;
  real_T t11;
  real_T t12;
  real_T t14;
  real_T t15;
  real_T t16;
  real_T t18;
  real_T t19;
  real_T t20;
  real_T t8;
  int32_T M_idx_2;
  int32_T M_idx_5;
  M_idx_2 = t21->mM.mX[2];
  M_idx_5 = t21->mM.mX[5];
  T_idx_0 = t21->mT.mX[0];
  X_idx_2 = t21->mX.mX[2];
  X_idx_5 = t21->mX.mX[5];
  D_idx_0 = t21->mD.mX[0];
  D_idx_1 = t21->mD.mX[1];
  D_idx_2 = t21->mD.mX[2];
  D_idx_3 = t21->mD.mX[3];
  D_idx_4 = t21->mD.mX[4];
  D_idx_5 = t21->mD.mX[5];
  D_idx_6 = t21->mD.mX[6];
  D_idx_7 = t21->mD.mX[7];
  out = t22->mDTF;
  t18 = T_idx_0 - D_idx_2;
  t15 = (t18 - D_idx_0 * 0.33333333333333331) * (t18 - D_idx_0 *
    0.33333333333333331) * D_idx_3 * 0.5 + D_idx_1;
  t16 = (D_idx_0 * D_idx_3 * D_idx_0 * 0.055555555555555552 + (t18 - D_idx_0 *
          0.66666666666666663) * D_idx_3 * D_idx_0 * 0.33333333333333331) +
    D_idx_1;
  if (t18 <= D_idx_0 * 0.33333333333333331) {
    D_idx_2 = D_idx_1;
  } else {
    D_idx_2 = t18 <= D_idx_0 * 0.66666666666666663 ? t15 : t16;
  }

  t14 = D_idx_2 > 0.01 ? 0.01 : D_idx_2;
  t14 = t14 > 0.0 ? t14 : 0.0;
  t20 = T_idx_0 - D_idx_6;
  t19 = (t20 - D_idx_4 * 0.33333333333333331) * (t20 - D_idx_4 *
    0.33333333333333331) * D_idx_7 * 0.5 + D_idx_5;
  D_idx_6 = (D_idx_4 * D_idx_7 * D_idx_4 * 0.055555555555555552 + (t20 - D_idx_4
              * 0.66666666666666663) * D_idx_7 * D_idx_4 * 0.33333333333333331)
    + D_idx_5;
  if (t20 <= D_idx_4 * 0.33333333333333331) {
    t1 = D_idx_5;
  } else {
    t1 = t20 <= D_idx_4 * 0.66666666666666663 ? t19 : D_idx_6;
  }

  t8 = t1 > 0.01 ? 0.01 : t1;
  t8 = t8 > 0.0 ? t8 : 0.0;
  t1 = -X_idx_5 + X_idx_2;
  intrm_sf_mf_1 = 1.0 - t14 / 0.01;
  t14 = 1.0 - t8 / 0.01;
  t8 = ((X_idx_2 + X_idx_5) + 2.0265) / 2.0 * 0.0010000000000000009;
  X_idx_5 = (X_idx_2 + 2.0265) / 2.0 * 0.0010000000000000009;
  if (M_idx_5 != 0) {
    t11 = 0.0;
  } else {
    t11 = pmf_acos(fabs(t14));
  }

  if (M_idx_2 != 0) {
    t12 = 0.0;
  } else {
    t12 = pmf_acos(fabs(intrm_sf_mf_1));
  }

  if (t18 <= D_idx_0 * 0.33333333333333331) {
    D_idx_2 = D_idx_1;
  } else {
    D_idx_2 = t18 <= D_idx_0 * 0.66666666666666663 ? t15 : t16;
  }

  if ((D_idx_2 > 0.01 ? 0.01 : D_idx_2) <= 0.0) {
    T_idx_0 = 0.0;
  } else {
    if (t18 <= D_idx_0 * 0.33333333333333331) {
    } else {
      D_idx_1 = t18 <= D_idx_0 * 0.66666666666666663 ? t15 : t16;
    }

    if (D_idx_1 >= 0.01) {
      T_idx_0 = 0.0;
    } else if (t18 <= D_idx_0 * 0.33333333333333331) {
      T_idx_0 = 0.0;
    } else {
      T_idx_0 = t18 <= D_idx_0 * 0.66666666666666663 ? ((t18 - D_idx_0 *
        0.33333333333333331) + (t18 - D_idx_0 * 0.33333333333333331)) * D_idx_3 *
        0.5 : D_idx_0 * D_idx_3 * 0.33333333333333331;
    }
  }

  if (t20 <= D_idx_4 * 0.33333333333333331) {
    D_idx_2 = D_idx_5;
  } else {
    D_idx_2 = t20 <= D_idx_4 * 0.66666666666666663 ? t19 : D_idx_6;
  }

  if ((D_idx_2 > 0.01 ? 0.01 : D_idx_2) <= 0.0) {
    D_idx_2 = 0.0;
  } else {
    if (t20 <= D_idx_4 * 0.33333333333333331) {
    } else {
      D_idx_5 = t20 <= D_idx_4 * 0.66666666666666663 ? t19 : D_idx_6;
    }

    if (D_idx_5 >= 0.01) {
      D_idx_2 = 0.0;
    } else if (t20 <= D_idx_4 * 0.33333333333333331) {
      D_idx_2 = 0.0;
    } else {
      D_idx_2 = t20 <= D_idx_4 * 0.66666666666666663 ? ((t20 - D_idx_4 *
        0.33333333333333331) + (t20 - D_idx_4 * 0.33333333333333331)) * D_idx_7 *
        0.5 : D_idx_4 * D_idx_7 * 0.33333333333333331;
    }
  }

  if (M_idx_5 != 0) {
    t15 = 0.0;
  } else {
    t20 = pmf_sqrt(1.0 - fabs(t14) * fabs(t14));
    if (t14 != t14) {
      t19 = t14;
    } else if (t14 > 0.0) {
      t19 = 1.0;
    } else {
      t19 = t14 < 0.0 ? -1.0 : 0.0;
    }

    t15 = -(1.0 / (t20 == 0.0 ? 1.0E-16 : t20)) * t19 * -(D_idx_2 / 0.01);
  }

  if (M_idx_5 != 0) {
    t18 = 0.0;
  } else {
    t20 = cos(t11 * 2.0) * t15 * 2.0;
    t18 = (t15 / 2.0 - t20 / 4.0) * 0.0001;
  }

  if (M_idx_2 != 0) {
    t15 = 0.0;
  } else {
    t14 = pmf_sqrt(1.0 - fabs(intrm_sf_mf_1) * fabs(intrm_sf_mf_1));
    if (intrm_sf_mf_1 != intrm_sf_mf_1) {
      t20 = intrm_sf_mf_1;
    } else if (intrm_sf_mf_1 > 0.0) {
      t20 = 1.0;
    } else {
      t20 = intrm_sf_mf_1 < 0.0 ? -1.0 : 0.0;
    }

    t15 = -(1.0 / (t14 == 0.0 ? 1.0E-16 : t14)) * t20 * -(T_idx_0 / 0.01);
  }

  if (M_idx_2 != 0) {
    t16 = 0.0;
  } else {
    t14 = cos(t12 * 2.0) * t15 * 2.0;
    t16 = (t15 / 2.0 - t14 / 4.0) * 0.0001;
  }

  t15 = -X_idx_2 * t16 * 0.031529631254723287;
  t16 = pmf_sqrt(pmf_sqrt(-X_idx_2 * -X_idx_2 + X_idx_5 * X_idx_5));
  X_idx_5 = t1 * t18 * 0.031529631254723287;
  t18 = pmf_sqrt(pmf_sqrt(t1 * t1 + t8 * t8));
  out.mX[0] = -(t15 / (t16 == 0.0 ? 1.0E-16 : t16) * 3.1622776601683795E+8);
  out.mX[1] = -(X_idx_5 / (t18 == 0.0 ? 1.0E-16 : t18) * 3.1622776601683795E+8);
  (void)sys;
  (void)t22;
  return 0;
}
