/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_mode.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_mode(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t11, NeDsMethodOutput *t12)
{
  PmIntVector out;
  real_T D_idx_0;
  real_T D_idx_1;
  real_T D_idx_2;
  real_T D_idx_3;
  real_T D_idx_4;
  real_T D_idx_5;
  real_T D_idx_6;
  real_T D_idx_7;
  real_T T_idx_0;
  real_T U_idx_0;
  real_T X_idx_1;
  real_T X_idx_4;
  real_T intrm_sf_mf_6;
  real_T t4;
  real_T t6;
  real_T t7;
  boolean_T t2;
  boolean_T t3;
  T_idx_0 = t11->mT.mX[0];
  U_idx_0 = t11->mU.mX[0];
  X_idx_1 = t11->mX.mX[1];
  X_idx_4 = t11->mX.mX[4];
  D_idx_0 = t11->mD.mX[0];
  D_idx_1 = t11->mD.mX[1];
  D_idx_2 = t11->mD.mX[2];
  D_idx_3 = t11->mD.mX[3];
  D_idx_4 = t11->mD.mX[4];
  D_idx_5 = t11->mD.mX[5];
  D_idx_6 = t11->mD.mX[6];
  D_idx_7 = t11->mD.mX[7];
  out = t12->mMODE;
  intrm_sf_mf_6 = T_idx_0 - D_idx_2;
  t6 = (intrm_sf_mf_6 - D_idx_0 * 0.33333333333333331) * (intrm_sf_mf_6 -
    D_idx_0 * 0.33333333333333331) * D_idx_3 * 0.5 + D_idx_1;
  t7 = (D_idx_0 * D_idx_3 * D_idx_0 * 0.055555555555555552 + (intrm_sf_mf_6 -
         D_idx_0 * 0.66666666666666663) * D_idx_3 * D_idx_0 *
        0.33333333333333331) + D_idx_1;
  if (intrm_sf_mf_6 <= D_idx_0 * 0.33333333333333331) {
    D_idx_2 = D_idx_1;
  } else {
    D_idx_2 = intrm_sf_mf_6 <= D_idx_0 * 0.66666666666666663 ? t6 : t7;
  }

  t4 = D_idx_2 > 0.01 ? 0.01 : D_idx_2;
  t4 = t4 > 0.0 ? t4 : 0.0;
  T_idx_0 -= D_idx_6;
  D_idx_6 = (T_idx_0 - D_idx_4 * 0.33333333333333331) * (T_idx_0 - D_idx_4 *
    0.33333333333333331) * D_idx_7 * 0.5 + D_idx_5;
  D_idx_3 = (D_idx_4 * D_idx_7 * D_idx_4 * 0.055555555555555552 + (T_idx_0 -
              D_idx_4 * 0.66666666666666663) * D_idx_7 * D_idx_4 *
             0.33333333333333331) + D_idx_5;
  if (T_idx_0 <= D_idx_4 * 0.33333333333333331) {
    D_idx_2 = D_idx_5;
  } else {
    D_idx_2 = T_idx_0 <= D_idx_4 * 0.66666666666666663 ? D_idx_6 : D_idx_3;
  }

  D_idx_2 = D_idx_2 > 0.01 ? 0.01 : D_idx_2;
  D_idx_2 = D_idx_2 > 0.0 ? D_idx_2 : 0.0;
  if (t4 <= 0.0) {
    t2 = true;
  } else {
    t2 = (t4 > 0.02);
  }

  if (D_idx_2 <= 0.0) {
    t3 = true;
  } else {
    t3 = (D_idx_2 > 0.02);
  }

  if (intrm_sf_mf_6 <= D_idx_0 * 0.33333333333333331) {
    t4 = D_idx_1;
  } else {
    t4 = intrm_sf_mf_6 <= D_idx_0 * 0.66666666666666663 ? t6 : t7;
  }

  if (intrm_sf_mf_6 <= D_idx_0 * 0.33333333333333331) {
    D_idx_2 = D_idx_1;
  } else {
    D_idx_2 = intrm_sf_mf_6 <= D_idx_0 * 0.66666666666666663 ? t6 : t7;
  }

  if (T_idx_0 <= D_idx_4 * 0.33333333333333331) {
    t6 = D_idx_5;
  } else {
    t6 = T_idx_0 <= D_idx_4 * 0.66666666666666663 ? D_idx_6 : D_idx_3;
  }

  if (T_idx_0 <= D_idx_4 * 0.33333333333333331) {
    t7 = D_idx_5;
  } else {
    t7 = T_idx_0 <= D_idx_4 * 0.66666666666666663 ? D_idx_6 : D_idx_3;
  }

  out.mX[0] = (int32_T)(-U_idx_0 < 0.5);
  out.mX[1] = (int32_T)(-U_idx_0 >= 0.5);
  out.mX[2] = (int32_T)t2;
  out.mX[3] = (int32_T)((X_idx_1 > 0.1) && (X_idx_4 * 0.002 > 0.0));
  out.mX[4] = (int32_T)((X_idx_1 < 0.0) && (X_idx_4 * 0.002 < 0.0));
  out.mX[5] = (int32_T)t3;
  out.mX[6] = (int32_T)((t4 > 0.01 ? 0.01 : t4) <= 0.0);
  out.mX[7] = (int32_T)(D_idx_2 >= 0.01);
  out.mX[8] = (int32_T)(intrm_sf_mf_6 <= D_idx_0 * 0.33333333333333331);
  out.mX[9] = (int32_T)(intrm_sf_mf_6 <= D_idx_0 * 0.66666666666666663);
  out.mX[10] = (int32_T)((t6 > 0.01 ? 0.01 : t6) <= 0.0);
  out.mX[11] = (int32_T)(t7 >= 0.01);
  out.mX[12] = (int32_T)(T_idx_0 <= D_idx_4 * 0.33333333333333331);
  out.mX[13] = (int32_T)(T_idx_0 <= D_idx_4 * 0.66666666666666663);
  (void)sys;
  (void)t12;
  return 0;
}
