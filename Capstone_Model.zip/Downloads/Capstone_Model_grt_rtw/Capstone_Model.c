/*
 * Capstone_Model.c
 *
 * Code generation for model "Capstone_Model".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri Mar 24 10:46:16 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "Capstone_Model.h"
#include "rtwtypes.h"
#include <stddef.h>
#include "Capstone_Model_private.h"
#include <string.h>
#include "rt_nonfinite.h"

/* Block signals (default storage) */
B_Capstone_Model_T Capstone_Model_B;

/* Continuous states */
X_Capstone_Model_T Capstone_Model_X;

/* Block states (default storage) */
DW_Capstone_Model_T Capstone_Model_DW;

/* Mass Matrices */
MassMatrix_Capstone_Model_T Capstone_Model_MassMatrix;

/* Real-time model */
static RT_MODEL_Capstone_Model_T Capstone_Model_M_;
RT_MODEL_Capstone_Model_T *const Capstone_Model_M = &Capstone_Model_M_;

/* ForcingFunction for root system: '<Root>' */
void Capstone_Model_forcingfunction(void)
{
  NeslSimulationData *simulationData;
  NeslSimulator *simulator;
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  XDot_Capstone_Model_T *_rtXdot;
  real_T tmp_0[4];
  real_T time;
  int32_T tmp_2;
  int_T tmp_1[2];
  boolean_T tmp;
  _rtXdot = ((XDot_Capstone_Model_T *) Capstone_Model_M->derivs);

  /* ForcingFunction for SimscapeExecutionBlock: '<S5>/STATE_1' */
  simulationData = (NeslSimulationData *)Capstone_Model_DW.STATE_1_SimData;
  time = Capstone_Model_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 6;
  simulationData->mData->mContStates.mX =
    &Capstone_Model_X.Capstone_ModelFluid_Reservoirvo[0];
  simulationData->mData->mDiscStates.mN = 16;
  simulationData->mData->mDiscStates.mX = &Capstone_Model_DW.STATE_1_Discrete[0];
  simulationData->mData->mModeVector.mN = 14;
  simulationData->mData->mModeVector.mX = &Capstone_Model_DW.STATE_1_Modes[0];
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep(Capstone_Model_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(&Capstone_Model_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
    (&Capstone_Model_M->solverInfo);
  tmp_1[0] = 0;
  tmp_0[0] = Capstone_Model_B.INPUT_1_1_1[0];
  tmp_0[1] = Capstone_Model_B.INPUT_1_1_1[1];
  tmp_0[2] = Capstone_Model_B.INPUT_1_1_1[2];
  tmp_0[3] = Capstone_Model_B.INPUT_1_1_1[3];
  tmp_1[1] = 4;
  simulationData->mData->mInputValues.mN = 4;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 2;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  simulationData->mData->mDx.mN = 6;
  simulationData->mData->mDx.mX = &_rtXdot->Capstone_ModelFluid_Reservoirvo[0];
  simulator = (NeslSimulator *)Capstone_Model_DW.STATE_1_Simulator;
  diagnosticManager = (NeuDiagnosticManager *)Capstone_Model_DW.STATE_1_DiagMgr;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method(simulator, NESL_SIM_FORCINGFUNCTION,
    simulationData, diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(Capstone_Model_M));
    if (tmp) {
      char *msg;
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(Capstone_Model_M, msg);
    }
  }

  /* End of ForcingFunction for SimscapeExecutionBlock: '<S5>/STATE_1' */
}

/* MassMatrix for root system: '<Root>' */
void Capstone_Model_massmatrix(void)
{
  NeslSimulationData *simulationData;
  NeslSimulator *simulator;
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  real_T tmp_0[4];
  real_T time;
  real_T *tmp_2;
  real_T *tmp_3;
  int32_T tmp_4;
  int_T tmp_1[2];
  boolean_T tmp;

  /* MassMatrix for SimscapeExecutionBlock: '<S5>/STATE_1' */
  simulationData = (NeslSimulationData *)Capstone_Model_DW.STATE_1_SimData;
  time = Capstone_Model_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 6;
  simulationData->mData->mContStates.mX =
    &Capstone_Model_X.Capstone_ModelFluid_Reservoirvo[0];
  simulationData->mData->mDiscStates.mN = 16;
  simulationData->mData->mDiscStates.mX = &Capstone_Model_DW.STATE_1_Discrete[0];
  simulationData->mData->mModeVector.mN = 14;
  simulationData->mData->mModeVector.mX = &Capstone_Model_DW.STATE_1_Modes[0];
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep(Capstone_Model_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(&Capstone_Model_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
    (&Capstone_Model_M->solverInfo);
  tmp_1[0] = 0;
  tmp_0[0] = Capstone_Model_B.INPUT_1_1_1[0];
  tmp_0[1] = Capstone_Model_B.INPUT_1_1_1[1];
  tmp_0[2] = Capstone_Model_B.INPUT_1_1_1[2];
  tmp_0[3] = Capstone_Model_B.INPUT_1_1_1[3];
  tmp_1[1] = 4;
  simulationData->mData->mInputValues.mN = 4;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 2;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  tmp_2 = Capstone_Model_M->massMatrixPr;
  tmp_3 = double_pointer_shift(tmp_2, Capstone_Model_DW.STATE_1_MASS_MATRIX_PR);
  simulationData->mData->mMassMatrixPr.mN = 2;
  simulationData->mData->mMassMatrixPr.mX = tmp_3;
  simulator = (NeslSimulator *)Capstone_Model_DW.STATE_1_Simulator;
  diagnosticManager = (NeuDiagnosticManager *)Capstone_Model_DW.STATE_1_DiagMgr;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_4 = ne_simulator_method(simulator, NESL_SIM_MASSMATRIX, simulationData,
    diagnosticManager);
  if (tmp_4 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(Capstone_Model_M));
    if (tmp) {
      char *msg;
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(Capstone_Model_M, msg);
    }
  }

  /* End of MassMatrix for SimscapeExecutionBlock: '<S5>/STATE_1' */
}

void local_evaluateMassMatrix(RTWSolverInfo *si, real_T *Mdest )
{
  /* Refresh global mass matrix */
  Capstone_Model_massmatrix();

  /* Copy the mass matrix from system to the destination, if needed. */
  if (Mdest != rtsiGetSolverMassMatrixPr(si)) {
    real_T *Msrc = rtsiGetSolverMassMatrixPr(si);
    int_T nzmax = rtsiGetSolverMassMatrixNzMax(si);
    (void) memcpy(Mdest, Msrc,
                  (uint_T)nzmax*sizeof(real_T));
  }
}

/* Simplified version of numjac.cpp, for use with RTW. */
void local_numjac( RTWSolverInfo *si, real_T *y, const real_T *Fty, real_T *fac,
                  real_T *dFdy )
{
  /* constants */
  real_T THRESH = 1e-6;
  real_T EPS = 2.2e-16;                /* utGetEps(); */
  real_T BL = pow(EPS, 0.75);
  real_T BU = pow(EPS, 0.25);
  real_T FACMIN = pow(EPS, 0.78);
  real_T FACMAX = 0.1;
  int_T nx = 6;
  real_T *x = rtsiGetContStates(si);
  real_T del;
  real_T difmax;
  real_T FdelRowmax;
  real_T temp;
  real_T Fdiff;
  real_T maybe;
  real_T xscale;
  real_T fscale;
  real_T *p;
  int_T rowmax;
  int_T i,j;
  if (x != y)
    (void) memcpy(x, y,
                  (uint_T)nx*sizeof(real_T));
  rtsiSetSolverComputingJacobian(si,true);
  for (p = dFdy, j = 0; j < nx; j++, p += nx) {
    /* Select an increment del for a difference approximation to
       column j of dFdy.  The vector fac accounts for experience
       gained in previous calls to numjac. */
    xscale = fabs(x[j]);
    if (xscale < THRESH)
      xscale = THRESH;
    temp = (x[j] + fac[j]*xscale);
    del = temp - y[j];
    while (del == 0.0) {
      if (fac[j] < FACMAX) {
        fac[j] *= 100.0;
        if (fac[j] > FACMAX)
          fac[j] = FACMAX;
        temp = (x[j] + fac[j]*xscale);
        del = temp - x[j];
      } else {
        del = THRESH;                  /* thresh is nonzero */
        break;
      }
    }

    /* Keep del pointing into region. */
    if (Fty[j] >= 0.0)
      del = fabs(del);
    else
      del = -fabs(del);

    /* Form a difference approximation to column j of dFdy. */
    temp = x[j];
    x[j] += del;
    Capstone_Model_step();
    rtsiSetdX(si,p);
    Capstone_Model_forcingfunction();
    x[j] = temp;
    difmax = 0.0;
    rowmax = 0;
    FdelRowmax = p[0];
    temp = 1.0 / del;
    for (i = 0; i < nx; i++) {
      Fdiff = p[i] - Fty[i];
      maybe = fabs(Fdiff);
      if (maybe > difmax) {
        difmax = maybe;
        rowmax = i;
        FdelRowmax = p[i];
      }

      p[i] = temp * Fdiff;
    }

    /* Adjust fac for next call to numjac. */
    if (((FdelRowmax != 0.0) && (Fty[rowmax] != 0.0)) || (difmax == 0.0)) {
      fscale = fabs(FdelRowmax);
      if (fscale < fabs(Fty[rowmax]))
        fscale = fabs(Fty[rowmax]);
      if (difmax <= BL*fscale) {
        /* The difference is small, so increase the increment. */
        fac[j] *= 10.0;
        if (fac[j] > FACMAX)
          fac[j] = FACMAX;
      } else if (difmax > BU*fscale) {
        /* The difference is large, so reduce the increment. */
        fac[j] *= 0.1;
        if (fac[j] < FACMIN)
          fac[j] = FACMIN;
      }
    }
  }

  rtsiSetSolverComputingJacobian(si,false);
}                                      /* end local_numjac */

/*
 * This function updates continuous states using the ODE14X fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static int_T rt_ODE14x_N[4] = { 12, 8, 6, 4 };

  time_T t0 = rtsiGetT(si);
  time_T t1 = t0;
  time_T h = rtsiGetStepSize(si);
  real_T *x1 = rtsiGetContStates(si);
  int_T order = rtsiGetSolverExtrapolationOrder(si);
  int_T numIter = rtsiGetSolverNumberNewtonIterations(si);
  ODE14X_IntgData *id = (ODE14X_IntgData *)rtsiGetSolverData(si);
  real_T *x0 = id->x0;
  real_T *f0 = id->f0;
  real_T *x1start = id->x1start;
  real_T *f1 = id->f1;
  real_T *Delta = id->Delta;
  real_T *E = id->E;
  real_T *fac = id->fac;
  real_T *dfdx = id->DFDX;
  real_T *W = id->W;
  int_T *pivots = id->pivots;
  real_T *xtmp = id->xtmp;
  real_T *ztmp = id->ztmp;
  int_T *Mpattern_ir = rtsiGetSolverMassMatrixIr(si);
  int_T *Mpattern_jc = rtsiGetSolverMassMatrixJc(si);
  real_T *M = id->M;
  int_T col,row,rowidx;
  int_T *N = &(rt_ODE14x_N[0]);
  int_T i,j,k,iter;
  int_T nx = 6;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(x0, x1,
                (uint_T)nx*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  if (id->isFirstStep) {
    local_evaluateMassMatrix(si,M );
    id->isFirstStep = false;
  }

  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  Capstone_Model_forcingfunction();
  local_numjac(si,x0,f0,fac,dfdx );
  for (j = 0; j < order; j++) {
    real_T *p;
    real_T hN = h/N[j];

    /* Get the iteration matrix and solution at t0 */

    /* [L,U] = lu(M - hN*J) */
    (void) memcpy(W, dfdx,
                  (uint_T)nx*nx*sizeof(real_T));
    for (p = W, i = 0; i < nx*nx; i++, p++) {
      *p *= (-hN);
    }

    for (col = 0, p = W; col < nx; col++, p += nx) {
      for (rowidx = Mpattern_jc[col]; rowidx < Mpattern_jc[col+1]; rowidx++) {
        real_T m_row_col = M[rowidx];
        row = Mpattern_ir[rowidx];
        p[row] += m_row_col;
      }
    }

    rt_lu_real(W, nx,
               pivots);

    /* First Newton's iteration at t0. */
    /* rhs = hN*f0 */
    for (i = 0; i < nx; i++) {
      Delta[i] = hN*f0[i];
    }

    /* Delta = (U \ (L \ rhs)) */
    rt_ForwardSubstitutionRR_Dbl(W, Delta,
      f1, nx,
      1, pivots,
      1);
    rt_BackwardSubstitutionRR_Dbl(W+nx*nx-1, f1+nx-1,
      Delta, nx,
      1, 0);

    /* ytmp = y0 + Delta
       ztmp = (ytmp-y0)/h
     */
    (void) memcpy(x1, x0,
                  (uint_T)nx*sizeof(real_T));
    for (i = 0; i < nx; i++) {
      x1[i] += Delta[i];
      ztmp[i] = Delta[i]/hN;
    }

    /* Additional Newton's iterations, if desired.
       for iter = 2:NewtIter
       rhs = hN*feval(odefun,tn,ytmp,extraArgs{:}) - M*(ytmp - yn);
       if statedepM   % only for state dep. Mdel ~= 0
       Mdel = M - feval(massfun,tn,ytmp);
       rhs = rhs + Mdel*ztmp*h;
       end
       Delta = ( U \ ( L \ rhs ) );
       ytmp = ytmp + Delta;
       ztmp = (ytmp - yn)/h
       end
     */
    rtsiSetT(si, t0);
    rtsiSetdX(si, f1);
    for (iter = 1; iter < numIter; iter++) {
      Capstone_Model_step();
      Capstone_Model_forcingfunction();
      for (i = 0; i < nx; i++) {
        Delta[i] = hN*f1[i];
        xtmp[i] = x1[i] - x0[i];
      }

      /* rhs = hN*f(tn,ytmp) - M*(ytmp-yn) */
      for (col = 0; col < nx; col++) {
        for (rowidx = Mpattern_jc[col]; rowidx < Mpattern_jc[col+1]; rowidx++) {
          real_T m_row_col = M[rowidx];
          row = Mpattern_ir[rowidx];
          Delta[row] -= m_row_col*xtmp[col];
        }
      }

      rt_ForwardSubstitutionRR_Dbl(W, Delta,
        f1, nx,
        1, pivots,
        1);
      rt_BackwardSubstitutionRR_Dbl(W+nx*nx-1, f1+nx-1,
        Delta, nx,
        1, 0);

      /* ytmp = ytmp + delta
         ztmp = (ytmp - yn)/h
       */
      for (i = 0; i < nx; i++) {
        x1[i] += Delta[i];
        ztmp[i] = (x1[i] - x0[i])/hN;
      }
    }

    /* Steps from t0+hN to t1 -- subintegration of N(j) steps for extrapolation
       ttmp = t0;
       for i = 2:N(j)
       ttmp = ttmp + hN
       ytmp0 = ytmp;
       for iter = 1:NewtIter
       rhs = (ytmp0 - ytmp) + hN*feval(odefun,ttmp,ytmp,extraArgs{:});
       Delta = ( U \ ( L \ rhs ) );
       ytmp = ytmp + Delta;
       end
       end
     */
    for (k = 1; k < N[j]; k++) {
      t1 = t0 + k*hN;
      (void) memcpy(x1start, x1,
                    (uint_T)nx*sizeof(real_T));
      rtsiSetT(si, t1);
      rtsiSetdX(si, f1);
      for (iter = 0; iter < numIter; iter++) {
        Capstone_Model_step();
        Capstone_Model_forcingfunction();
        if (iter == 0) {
          for (i = 0; i < nx; i++) {
            Delta[i] = hN*f1[i];
          }
        } else {
          for (i = 0; i < nx; i++) {
            Delta[i] = hN*f1[i];
            xtmp[i] = (x1[i]-x1start[i]);
          }

          /* rhs = hN*f(tn,ytmp) - M*(ytmp-yn) */
          for (col = 0; col < nx; col++) {
            for (rowidx = Mpattern_jc[col]; rowidx < Mpattern_jc[col+1]; rowidx
                 ++) {
              real_T m_row_col = M[rowidx];
              row = Mpattern_ir[rowidx];
              Delta[row] -= m_row_col*xtmp[col];
            }
          }
        }

        rt_ForwardSubstitutionRR_Dbl(W, Delta,
          f1, nx,
          1, pivots,
          1);
        rt_BackwardSubstitutionRR_Dbl(W+nx*nx-1, f1+nx-1,
          Delta, nx,
          1, 0);

        /* ytmp = ytmp + Delta
           ztmp = (ytmp - ytmp0)/h
         */
        for (i = 0; i < nx; i++) {
          x1[i] += Delta[i];
          ztmp[i] = (x1[i] - x1start[i])/hN;
        }
      }
    }

    /* Extrapolate to order j
       E(:,j) = ytmp
       for k = j:-1:2
       coef = N(k-1)/(N(j) - N(k-1))
       E(:,k-1) = E(:,k) + coef*( E(:,k) - E(:,k-1) )
       end
     */
    (void) memcpy(&(E[nx*j]), x1,
                  (uint_T)nx*sizeof(real_T));
    for (k = j; k > 0; k--) {
      real_T coef = (real_T)(N[k-1]) / (N[j]-N[k-1]);
      for (i = 0; i < nx; i++) {
        x1[i] = E[nx*k+i] + coef*(E[nx*k+i] - E[nx*(k-1)+i]);
      }

      (void) memcpy(&(E[nx*(k-1)]), x1,
                    (uint_T)nx*sizeof(real_T));
    }
  }

  /* x1 = E(:,1); */
  (void) memcpy(x1, E,
                (uint_T)nx*sizeof(real_T));

  /* t1 = t0 + h; */
  rtsiSetT(si,rtsiGetSolverStopTime(si));
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void Capstone_Model_step(void)
{
  if (rtmIsMajorTimeStep(Capstone_Model_M)) {
    /* set solver stop time */
    if (!(Capstone_Model_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&Capstone_Model_M->solverInfo,
                            ((Capstone_Model_M->Timing.clockTickH0 + 1) *
        Capstone_Model_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&Capstone_Model_M->solverInfo,
                            ((Capstone_Model_M->Timing.clockTick0 + 1) *
        Capstone_Model_M->Timing.stepSize0 +
        Capstone_Model_M->Timing.clockTickH0 *
        Capstone_Model_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(Capstone_Model_M)) {
    Capstone_Model_M->Timing.t[0] = rtsiGetT(&Capstone_Model_M->solverInfo);
  }

  {
    NeslSimulationData *simulationData;
    NeslSimulator *simulator;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    real_T tmp_0[4];
    real_T currentTime;
    real_T time;
    real_T time_0;
    real_T u1;
    real_T u2;
    int32_T tmp_2;
    int_T tmp_1[2];
    boolean_T tmp;
    if (rtmIsMajorTimeStep(Capstone_Model_M)) {
      /* Delay: '<Root>/Delay' */
      Capstone_Model_B.Delay = Capstone_Model_DW.Delay_DSTATE[0];
    }

    /* Step: '<S1>/Step' */
    currentTime = Capstone_Model_M->Timing.t[0];
    if (currentTime < Capstone_Model_P.Ramp_start) {
      /* Step: '<S1>/Step' */
      Capstone_Model_B.Step = Capstone_Model_P.Step_Y0;
    } else {
      /* Step: '<S1>/Step' */
      Capstone_Model_B.Step = Capstone_Model_P.Ramp_slope;
    }

    /* End of Step: '<S1>/Step' */

    /* Clock: '<S1>/Clock' */
    Capstone_Model_B.Clock = Capstone_Model_M->Timing.t[0];

    /* Sum: '<S1>/Sum' incorporates:
     *  Constant: '<S1>/Constant'
     */
    Capstone_Model_B.Sum = Capstone_Model_B.Clock - Capstone_Model_P.Ramp_start;

    /* Product: '<S1>/Product' */
    Capstone_Model_B.Product = Capstone_Model_B.Step * Capstone_Model_B.Sum;

    /* Sum: '<S1>/Output' incorporates:
     *  Constant: '<S1>/Constant1'
     */
    Capstone_Model_B.Output = Capstone_Model_B.Product +
      Capstone_Model_P.Ramp_InitialOutput;

    /* Saturate: '<Root>/Saturation' */
    currentTime = Capstone_Model_B.Output;
    u1 = Capstone_Model_P.Saturation_LowerSat;
    u2 = Capstone_Model_P.Saturation_UpperSat;
    if (currentTime > u2) {
      /* Saturate: '<Root>/Saturation' */
      Capstone_Model_B.Saturation = u2;
    } else if (currentTime < u1) {
      /* Saturate: '<Root>/Saturation' */
      Capstone_Model_B.Saturation = u1;
    } else {
      /* Saturate: '<Root>/Saturation' */
      Capstone_Model_B.Saturation = currentTime;
    }

    /* End of Saturate: '<Root>/Saturation' */

    /* Product: '<Root>/Product' */
    Capstone_Model_B.Product_e = Capstone_Model_B.Delay *
      Capstone_Model_B.Saturation;

    /* SimscapeInputBlock: '<S5>/INPUT_1_1_1' */
    Capstone_Model_B.INPUT_1_1_1[0] = Capstone_Model_B.Product_e;
    Capstone_Model_B.INPUT_1_1_1[1] = 0.0;
    Capstone_Model_B.INPUT_1_1_1[2] = 0.0;
    Capstone_Model_B.INPUT_1_1_1[3] = 0.0;

    /* SimscapeExecutionBlock: '<S5>/STATE_1' */
    simulationData = (NeslSimulationData *)Capstone_Model_DW.STATE_1_SimData;
    time = Capstone_Model_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 6;
    simulationData->mData->mContStates.mX =
      &Capstone_Model_X.Capstone_ModelFluid_Reservoirvo[0];
    simulationData->mData->mDiscStates.mN = 16;
    simulationData->mData->mDiscStates.mX = &Capstone_Model_DW.STATE_1_Discrete
      [0];
    simulationData->mData->mModeVector.mN = 14;
    simulationData->mData->mModeVector.mX = &Capstone_Model_DW.STATE_1_Modes[0];
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (Capstone_Model_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp = rtsiIsSolverComputingJacobian(&Capstone_Model_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
      (&Capstone_Model_M->solverInfo);
    tmp_1[0] = 0;
    tmp_0[0] = Capstone_Model_B.INPUT_1_1_1[0];
    tmp_0[1] = Capstone_Model_B.INPUT_1_1_1[1];
    tmp_0[2] = Capstone_Model_B.INPUT_1_1_1[2];
    tmp_0[3] = Capstone_Model_B.INPUT_1_1_1[3];
    tmp_1[1] = 4;
    simulationData->mData->mInputValues.mN = 4;
    simulationData->mData->mInputValues.mX = &tmp_0[0];
    simulationData->mData->mInputOffsets.mN = 2;
    simulationData->mData->mInputOffsets.mX = &tmp_1[0];
    simulationData->mData->mOutputs.mN = 28;
    simulationData->mData->mOutputs.mX = &Capstone_Model_B.STATE_1[0];
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = NULL;
    simulationData->mData->mCstateHasChanged = false;
    time_0 = Capstone_Model_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_0;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = NULL;
    simulationData->mData->mIsFundamentalSampleHit = false;
    simulator = (NeslSimulator *)Capstone_Model_DW.STATE_1_Simulator;
    diagnosticManager = (NeuDiagnosticManager *)
      Capstone_Model_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_2 = ne_simulator_method(simulator, NESL_SIM_OUTPUTS, simulationData,
      diagnosticManager);
    if (tmp_2 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(Capstone_Model_M));
      if (tmp) {
        char *msg;
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(Capstone_Model_M, msg);
      }
    }

    /* End of SimscapeExecutionBlock: '<S5>/STATE_1' */
  }

  if (rtmIsMajorTimeStep(Capstone_Model_M)) {
    /* Matfile logging */
    rt_UpdateTXYLogVars(Capstone_Model_M->rtwLogInfo,
                        (Capstone_Model_M->Timing.t));
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(Capstone_Model_M)) {
    NeslSimulationData *simulationData;
    NeslSimulator *simulator;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    real_T tmp_0[4];
    real_T time;
    int_T tmp_1[2];
    int_T idxDelay;
    boolean_T tmp;
    if (rtmIsMajorTimeStep(Capstone_Model_M)) {
      /* Update for Delay: '<Root>/Delay' incorporates:
       *  Constant: '<Root>/Constant'
       */
      Capstone_Model_DW.Delay_DSTATE[0] = Capstone_Model_DW.Delay_DSTATE[1];
      Capstone_Model_DW.Delay_DSTATE[1] = Capstone_Model_DW.Delay_DSTATE[2];
      Capstone_Model_DW.Delay_DSTATE[2] = Capstone_Model_DW.Delay_DSTATE[3];
      Capstone_Model_DW.Delay_DSTATE[3] = Capstone_Model_DW.Delay_DSTATE[4];
      Capstone_Model_DW.Delay_DSTATE[4] = Capstone_Model_P.Constant_Value;
    }

    /* Update for SimscapeExecutionBlock: '<S5>/STATE_1' */
    simulationData = (NeslSimulationData *)Capstone_Model_DW.STATE_1_SimData;
    time = Capstone_Model_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 6;
    simulationData->mData->mContStates.mX =
      &Capstone_Model_X.Capstone_ModelFluid_Reservoirvo[0];
    simulationData->mData->mDiscStates.mN = 16;
    simulationData->mData->mDiscStates.mX = &Capstone_Model_DW.STATE_1_Discrete
      [0];
    simulationData->mData->mModeVector.mN = 14;
    simulationData->mData->mModeVector.mX = &Capstone_Model_DW.STATE_1_Modes[0];
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep
      (Capstone_Model_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    tmp = rtsiIsSolverComputingJacobian(&Capstone_Model_M->solverInfo);
    simulationData->mData->mIsComputingJacobian = tmp;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
      (&Capstone_Model_M->solverInfo);
    tmp_1[0] = 0;
    tmp_0[0] = Capstone_Model_B.INPUT_1_1_1[0];
    tmp_0[1] = Capstone_Model_B.INPUT_1_1_1[1];
    tmp_0[2] = Capstone_Model_B.INPUT_1_1_1[2];
    tmp_0[3] = Capstone_Model_B.INPUT_1_1_1[3];
    tmp_1[1] = 4;
    simulationData->mData->mInputValues.mN = 4;
    simulationData->mData->mInputValues.mX = &tmp_0[0];
    simulationData->mData->mInputOffsets.mN = 2;
    simulationData->mData->mInputOffsets.mX = &tmp_1[0];
    simulator = (NeslSimulator *)Capstone_Model_DW.STATE_1_Simulator;
    diagnosticManager = (NeuDiagnosticManager *)
      Capstone_Model_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    idxDelay = ne_simulator_method(simulator, NESL_SIM_UPDATE, simulationData,
      diagnosticManager);
    if (idxDelay != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(Capstone_Model_M));
      if (tmp) {
        char *msg;
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(Capstone_Model_M, msg);
      }
    }

    /* End of Update for SimscapeExecutionBlock: '<S5>/STATE_1' */
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(Capstone_Model_M)) {
    /* signal main to stop simulation */
    {                                  /* Sample time: [0.0s, 0.0s] */
      if ((rtmGetTFinal(Capstone_Model_M)!=-1) &&
          !((rtmGetTFinal(Capstone_Model_M)-
             (((Capstone_Model_M->Timing.clockTick1+
                Capstone_Model_M->Timing.clockTickH1* 4294967296.0)) * 0.2)) >
            (((Capstone_Model_M->Timing.clockTick1+
               Capstone_Model_M->Timing.clockTickH1* 4294967296.0)) * 0.2) *
            (DBL_EPSILON))) {
        rtmSetErrorStatus(Capstone_Model_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&Capstone_Model_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++Capstone_Model_M->Timing.clockTick0)) {
      ++Capstone_Model_M->Timing.clockTickH0;
    }

    Capstone_Model_M->Timing.t[0] = rtsiGetSolverStopTime
      (&Capstone_Model_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.2s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.2, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      Capstone_Model_M->Timing.clockTick1++;
      if (!Capstone_Model_M->Timing.clockTick1) {
        Capstone_Model_M->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void Capstone_Model_derivatives(void)
{
  NeslSimulationData *simulationData;
  NeslSimulator *simulator;
  NeuDiagnosticManager *diagnosticManager;
  NeuDiagnosticTree *diagnosticTree;
  XDot_Capstone_Model_T *_rtXdot;
  real_T tmp_0[4];
  real_T time;
  int32_T tmp_2;
  int_T tmp_1[2];
  boolean_T tmp;
  _rtXdot = ((XDot_Capstone_Model_T *) Capstone_Model_M->derivs);

  /* Derivatives for SimscapeExecutionBlock: '<S5>/STATE_1' */
  simulationData = (NeslSimulationData *)Capstone_Model_DW.STATE_1_SimData;
  time = Capstone_Model_M->Timing.t[0];
  simulationData->mData->mTime.mN = 1;
  simulationData->mData->mTime.mX = &time;
  simulationData->mData->mContStates.mN = 6;
  simulationData->mData->mContStates.mX =
    &Capstone_Model_X.Capstone_ModelFluid_Reservoirvo[0];
  simulationData->mData->mDiscStates.mN = 16;
  simulationData->mData->mDiscStates.mX = &Capstone_Model_DW.STATE_1_Discrete[0];
  simulationData->mData->mModeVector.mN = 14;
  simulationData->mData->mModeVector.mX = &Capstone_Model_DW.STATE_1_Modes[0];
  tmp = false;
  simulationData->mData->mFoundZcEvents = tmp;
  simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep(Capstone_Model_M);
  tmp = false;
  simulationData->mData->mIsSolverAssertCheck = tmp;
  simulationData->mData->mIsSolverCheckingCIC = false;
  tmp = rtsiIsSolverComputingJacobian(&Capstone_Model_M->solverInfo);
  simulationData->mData->mIsComputingJacobian = tmp;
  simulationData->mData->mIsEvaluatingF0 = false;
  simulationData->mData->mIsSolverRequestingReset = false;
  simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
    (&Capstone_Model_M->solverInfo);
  tmp_1[0] = 0;
  tmp_0[0] = Capstone_Model_B.INPUT_1_1_1[0];
  tmp_0[1] = Capstone_Model_B.INPUT_1_1_1[1];
  tmp_0[2] = Capstone_Model_B.INPUT_1_1_1[2];
  tmp_0[3] = Capstone_Model_B.INPUT_1_1_1[3];
  tmp_1[1] = 4;
  simulationData->mData->mInputValues.mN = 4;
  simulationData->mData->mInputValues.mX = &tmp_0[0];
  simulationData->mData->mInputOffsets.mN = 2;
  simulationData->mData->mInputOffsets.mX = &tmp_1[0];
  simulationData->mData->mDx.mN = 6;
  simulationData->mData->mDx.mX = &_rtXdot->Capstone_ModelFluid_Reservoirvo[0];
  simulator = (NeslSimulator *)Capstone_Model_DW.STATE_1_Simulator;
  diagnosticManager = (NeuDiagnosticManager *)Capstone_Model_DW.STATE_1_DiagMgr;
  diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
  tmp_2 = ne_simulator_method(simulator, NESL_SIM_DERIVATIVES, simulationData,
    diagnosticManager);
  if (tmp_2 != 0) {
    tmp = error_buffer_is_empty(rtmGetErrorStatus(Capstone_Model_M));
    if (tmp) {
      char *msg;
      msg = rtw_diagnostics_msg(diagnosticTree);
      rtmSetErrorStatus(Capstone_Model_M, msg);
    }
  }

  /* End of Derivatives for SimscapeExecutionBlock: '<S5>/STATE_1' */
}

/* Model initialize function */
void Capstone_Model_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Capstone_Model_M, 0,
                sizeof(RT_MODEL_Capstone_Model_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Capstone_Model_M->solverInfo,
                          &Capstone_Model_M->Timing.simTimeStep);
    rtsiSetTPtr(&Capstone_Model_M->solverInfo, &rtmGetTPtr(Capstone_Model_M));
    rtsiSetStepSizePtr(&Capstone_Model_M->solverInfo,
                       &Capstone_Model_M->Timing.stepSize0);
    rtsiSetdXPtr(&Capstone_Model_M->solverInfo, &Capstone_Model_M->derivs);
    rtsiSetContStatesPtr(&Capstone_Model_M->solverInfo, (real_T **)
                         &Capstone_Model_M->contStates);
    rtsiSetNumContStatesPtr(&Capstone_Model_M->solverInfo,
      &Capstone_Model_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&Capstone_Model_M->solverInfo,
      &Capstone_Model_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&Capstone_Model_M->solverInfo,
      &Capstone_Model_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&Capstone_Model_M->solverInfo,
      &Capstone_Model_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&Capstone_Model_M->solverInfo, (&rtmGetErrorStatus
      (Capstone_Model_M)));
    rtsiSetSolverMassMatrixIr(&Capstone_Model_M->solverInfo,
      Capstone_Model_MassMatrix.ir);
    rtsiSetSolverMassMatrixJc(&Capstone_Model_M->solverInfo,
      Capstone_Model_MassMatrix.jc);
    rtsiSetSolverMassMatrixPr(&Capstone_Model_M->solverInfo,
      Capstone_Model_MassMatrix.pr);
    rtsiSetRTModelPtr(&Capstone_Model_M->solverInfo, Capstone_Model_M);
  }

  rtsiSetSimTimeStep(&Capstone_Model_M->solverInfo, MAJOR_TIME_STEP);
  Capstone_Model_M->intgData.x0 = Capstone_Model_M->odeX0;
  Capstone_Model_M->intgData.f0 = Capstone_Model_M->odeF0;
  Capstone_Model_M->intgData.x1start = Capstone_Model_M->odeX1START;
  Capstone_Model_M->intgData.f1 = Capstone_Model_M->odeF1;
  Capstone_Model_M->intgData.Delta = Capstone_Model_M->odeDELTA;
  Capstone_Model_M->intgData.E = Capstone_Model_M->odeE;
  Capstone_Model_M->intgData.fac = Capstone_Model_M->odeFAC;

  /* initialize */
  {
    int_T i;
    real_T *f = Capstone_Model_M->intgData.fac;
    for (i = 0; i < (int_T)(sizeof(Capstone_Model_M->odeFAC)/sizeof(real_T)); i
         ++) {
      f[i] = 1.5e-8;
    }
  }

  Capstone_Model_M->intgData.DFDX = Capstone_Model_M->odeDFDX;
  Capstone_Model_M->intgData.W = Capstone_Model_M->odeW;
  Capstone_Model_M->intgData.pivots = Capstone_Model_M->odePIVOTS;
  Capstone_Model_M->intgData.xtmp = Capstone_Model_M->odeXTMP;
  Capstone_Model_M->intgData.ztmp = Capstone_Model_M->odeZTMP;
  Capstone_Model_M->intgData.M = Capstone_Model_M->odeMASSMATRIX_M;
  Capstone_Model_M->intgData.isFirstStep = true;
  rtsiSetSolverExtrapolationOrder(&Capstone_Model_M->solverInfo, 4);
  rtsiSetSolverNumberNewtonIterations(&Capstone_Model_M->solverInfo, 1);
  Capstone_Model_M->contStates = ((X_Capstone_Model_T *) &Capstone_Model_X);
  Capstone_Model_M->massMatrixType = ((ssMatrixType)1);
  Capstone_Model_M->massMatrixNzMax = (2);
  Capstone_Model_M->massMatrixIr = (Capstone_Model_MassMatrix.ir);
  Capstone_Model_M->massMatrixJc = (Capstone_Model_MassMatrix.jc);
  Capstone_Model_M->massMatrixPr = (Capstone_Model_MassMatrix.pr);
  rtsiSetSolverMassMatrixType(&Capstone_Model_M->solverInfo, (ssMatrixType)1);
  rtsiSetSolverMassMatrixNzMax(&Capstone_Model_M->solverInfo, 2);
  rtsiSetSolverData(&Capstone_Model_M->solverInfo, (void *)
                    &Capstone_Model_M->intgData);
  rtsiSetIsMinorTimeStepWithModeChange(&Capstone_Model_M->solverInfo, false);
  rtsiSetSolverName(&Capstone_Model_M->solverInfo,"ode14x");
  rtmSetTPtr(Capstone_Model_M, &Capstone_Model_M->Timing.tArray[0]);
  rtmSetTFinal(Capstone_Model_M, 10.0);
  Capstone_Model_M->Timing.stepSize0 = 0.2;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    Capstone_Model_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Capstone_Model_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Capstone_Model_M->rtwLogInfo, (NULL));
    rtliSetLogT(Capstone_Model_M->rtwLogInfo, "tout");
    rtliSetLogX(Capstone_Model_M->rtwLogInfo, "");
    rtliSetLogXFinal(Capstone_Model_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Capstone_Model_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Capstone_Model_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(Capstone_Model_M->rtwLogInfo, 0);
    rtliSetLogDecimation(Capstone_Model_M->rtwLogInfo, 1);
    rtliSetLogY(Capstone_Model_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Capstone_Model_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Capstone_Model_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &Capstone_Model_B), 0,
                sizeof(B_Capstone_Model_T));

  /* states (continuous) */
  {
    (void) memset((void *)&Capstone_Model_X, 0,
                  sizeof(X_Capstone_Model_T));
  }

  /* global mass matrix */
  {
    int_T *ir = Capstone_Model_MassMatrix.ir;
    int_T *jc = Capstone_Model_MassMatrix.jc;
    real_T *pr = Capstone_Model_MassMatrix.pr;
    (void) memset((void *)ir, 0,
                  2*sizeof(int_T));
    (void) memset((void *)jc, 0,
                  (6+1)*sizeof(int_T));
    (void) memset((void *)pr, 0,
                  2*sizeof(real_T));
  }

  /* states (dwork) */
  (void) memset((void *)&Capstone_Model_DW, 0,
                sizeof(DW_Capstone_Model_T));

  /* Root-level init GlobalMassMatrixPr offset */
  {
    Capstone_Model_DW.STATE_1_MASS_MATRIX_PR = 0;/* '<S5>/STATE_1' */
  }

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(Capstone_Model_M->rtwLogInfo, 0.0,
    rtmGetTFinal(Capstone_Model_M), Capstone_Model_M->Timing.stepSize0,
    (&rtmGetErrorStatus(Capstone_Model_M)));

  {
    NeModelParameters modelParameters;
    NeslSimulationData *tmp;
    NeslSimulator *simulator;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    real_T tmp_0;
    int32_T tmp_1;
    boolean_T zcDisabled;

    /* Start for SimscapeExecutionBlock: '<S5>/STATE_1' */
    simulator = nesl_lease_simulator("Capstone_Model/Solver Configuration_1", 0,
      0);
    Capstone_Model_DW.STATE_1_Simulator = (void *)simulator;
    zcDisabled = pointer_is_null(Capstone_Model_DW.STATE_1_Simulator);
    if (zcDisabled) {
      Capstone_Model_a7fe4013_1_gateway();
      simulator = nesl_lease_simulator("Capstone_Model/Solver Configuration_1",
        0, 0);
      Capstone_Model_DW.STATE_1_Simulator = (void *)simulator;
    }

    tmp = nesl_create_simulation_data();
    Capstone_Model_DW.STATE_1_SimData = (void *)tmp;
    diagnosticManager = rtw_create_diagnostics();
    Capstone_Model_DW.STATE_1_DiagMgr = (void *)diagnosticManager;
    modelParameters.mSolverType = NE_SOLVER_TYPE_DAE;
    modelParameters.mSolverAbsTol = 0.001;
    modelParameters.mSolverRelTol = 0.001;
    modelParameters.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    modelParameters.mStartTime = 0.0;
    modelParameters.mLoadInitialState = false;
    modelParameters.mUseSimState = false;
    modelParameters.mLinTrimCompile = false;
    modelParameters.mLoggingMode = SSC_LOGGING_NONE;
    modelParameters.mRTWModifiedTimeStamp = 6.01573543E+8;
    tmp_0 = 0.001;
    modelParameters.mSolverTolerance = tmp_0;
    tmp_0 = 0.2;
    modelParameters.mFixedStepSize = tmp_0;
    zcDisabled = false;
    modelParameters.mVariableStepSolver = zcDisabled;
    zcDisabled = false;
    modelParameters.mIsUsingODEN = zcDisabled;
    modelParameters.mZcDisabled = true;
    simulator = (NeslSimulator *)Capstone_Model_DW.STATE_1_Simulator;
    diagnosticManager = (NeuDiagnosticManager *)
      Capstone_Model_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_1 = nesl_initialize_simulator(simulator, &modelParameters,
      diagnosticManager);
    if (tmp_1 != 0) {
      zcDisabled = error_buffer_is_empty(rtmGetErrorStatus(Capstone_Model_M));
      if (zcDisabled) {
        char *msg;
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(Capstone_Model_M, msg);
      }
    }

    /* End of Start for SimscapeExecutionBlock: '<S5>/STATE_1' */
  }

  {
    int32_T i;
    boolean_T tmp;
    boolean_T tmp_0;

    /* InitializeConditions for Delay: '<Root>/Delay' */
    for (i = 0; i < 5; i++) {
      Capstone_Model_DW.Delay_DSTATE[i] =
        Capstone_Model_P.Delay_InitialCondition;
    }

    /* End of InitializeConditions for Delay: '<Root>/Delay' */

    /* InitializeConditions for SimscapeExecutionBlock: '<S5>/STATE_1' */
    tmp = false;
    tmp_0 = false;
    if (tmp_0 || tmp) {
      i = strcmp(rtsiGetSolverName(&Capstone_Model_M->solverInfo), "daessc");
      tmp = (i == 0);
      i = strcmp(rtsiGetSolverName(&Capstone_Model_M->solverInfo), "ode14x");
      tmp = (i == 0) | tmp;
      i = strcmp(rtsiGetSolverName(&Capstone_Model_M->solverInfo), "ode15s");
      tmp = (i == 0) | tmp;
      i = strcmp(rtsiGetSolverName(&Capstone_Model_M->solverInfo), "ode1be");
      tmp = (i == 0) | tmp;
      i = strcmp(rtsiGetSolverName(&Capstone_Model_M->solverInfo), "ode23t");
      tmp = (i == 0) | tmp;
      i = strcmp(rtsiGetSolverName(&Capstone_Model_M->solverInfo), "odeN");
      tmp = (i == 0) | tmp;
      if (!tmp) {
        rtmSetErrorStatus(Capstone_Model_M,
                          "Detected inconsistent solvers in the model reference hierarchy. Model built with ode14x requires one of {daessc, ode14x, ode15s, ode1be, ode23t, odeN} solvers to run. Use one of the required solvers in the top model.");
      }
    }

    /* End of InitializeConditions for SimscapeExecutionBlock: '<S5>/STATE_1' */

    /* Root-level InitSystemMatrices */
    {
      static int_T modelMassMatrixIr[2] = { 0, 1 };

      static int_T modelMassMatrixJc[7] = { 0, 1, 2, 2, 2, 2, 2 };

      static real_T modelMassMatrixPr[2] = { 1.0, 1.0 };

      (void) memcpy(Capstone_Model_MassMatrix.ir, modelMassMatrixIr,
                    2*sizeof(int_T));
      (void) memcpy(Capstone_Model_MassMatrix.jc, modelMassMatrixJc,
                    7*sizeof(int_T));
      (void) memcpy(Capstone_Model_MassMatrix.pr, modelMassMatrixPr,
                    2*sizeof(real_T));
    }
  }
}

/* Model terminate function */
void Capstone_Model_terminate(void)
{
  NeslSimulationData *simulationData;
  NeuDiagnosticManager *diagnosticManager;

  /* Terminate for SimscapeExecutionBlock: '<S5>/STATE_1' */
  diagnosticManager = (NeuDiagnosticManager *)Capstone_Model_DW.STATE_1_DiagMgr;
  neu_destroy_diagnostic_manager(diagnosticManager);
  simulationData = (NeslSimulationData *)Capstone_Model_DW.STATE_1_SimData;
  nesl_destroy_simulation_data(simulationData);
  nesl_erase_simulator("Capstone_Model/Solver Configuration_1");
  nesl_destroy_registry();
}
