/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_assert.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_assert(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t12, NeDsMethodOutput *t13)
{
  PmIntVector out;
  real_T D_idx_0;
  real_T D_idx_1;
  real_T D_idx_2;
  real_T D_idx_3;
  real_T D_idx_4;
  real_T D_idx_5;
  real_T D_idx_6;
  real_T D_idx_7;
  real_T T_idx_0;
  real_T U_idx_0;
  real_T X_idx_0;
  real_T X_idx_2;
  real_T X_idx_5;
  real_T t11;
  int32_T CI_idx_0;
  int32_T CI_idx_1;
  int32_T CI_idx_2;
  int32_T CI_idx_3;
  int32_T t4_idx_13;
  int32_T t4_idx_18;
  int32_T t4_idx_29;
  int32_T t4_idx_34;
  int32_T t4_idx_41;
  boolean_T t2;
  boolean_T t3;
  T_idx_0 = t12->mT.mX[0];
  U_idx_0 = t12->mU.mX[0];
  X_idx_0 = t12->mX.mX[0];
  X_idx_2 = t12->mX.mX[2];
  X_idx_5 = t12->mX.mX[5];
  D_idx_0 = t12->mD.mX[0];
  D_idx_1 = t12->mD.mX[1];
  D_idx_2 = t12->mD.mX[2];
  D_idx_3 = t12->mD.mX[3];
  D_idx_4 = t12->mD.mX[4];
  D_idx_5 = t12->mD.mX[5];
  D_idx_6 = t12->mD.mX[6];
  D_idx_7 = t12->mD.mX[7];
  CI_idx_0 = t12->mCI.mX[0];
  CI_idx_1 = t12->mCI.mX[1];
  CI_idx_2 = t12->mCI.mX[2];
  CI_idx_3 = t12->mCI.mX[3];
  out = t13->mASSERT;
  t11 = T_idx_0 - D_idx_2;
  if (t11 <= D_idx_0 * 0.33333333333333331) {
  } else {
    D_idx_1 = t11 <= D_idx_0 * 0.66666666666666663 ? (t11 - D_idx_0 *
      0.33333333333333331) * (t11 - D_idx_0 * 0.33333333333333331) * D_idx_3 *
      0.5 + D_idx_1 : (D_idx_0 * D_idx_3 * D_idx_0 * 0.055555555555555552 + (t11
      - D_idx_0 * 0.66666666666666663) * D_idx_3 * D_idx_0 * 0.33333333333333331)
      + D_idx_1;
  }

  D_idx_2 = D_idx_1 > 0.01 ? 0.01 : D_idx_1;
  t11 = D_idx_2 > 0.0 ? D_idx_2 : 0.0;
  T_idx_0 -= D_idx_6;
  if (T_idx_0 <= D_idx_4 * 0.33333333333333331) {
  } else {
    D_idx_5 = T_idx_0 <= D_idx_4 * 0.66666666666666663 ? (T_idx_0 - D_idx_4 *
      0.33333333333333331) * (T_idx_0 - D_idx_4 * 0.33333333333333331) * D_idx_7
      * 0.5 + D_idx_5 : (D_idx_4 * D_idx_7 * D_idx_4 * 0.055555555555555552 +
                         (T_idx_0 - D_idx_4 * 0.66666666666666663) * D_idx_7 *
                         D_idx_4 * 0.33333333333333331) + D_idx_5;
  }

  D_idx_2 = D_idx_5 > 0.01 ? 0.01 : D_idx_5;
  T_idx_0 = D_idx_2 > 0.0 ? D_idx_2 : 0.0;
  D_idx_0 = -X_idx_5 + X_idx_2;
  D_idx_5 = 1.0 - t11 / 0.01;
  D_idx_2 = 1.0 - T_idx_0 / 0.01;
  D_idx_1 = ((X_idx_2 + X_idx_5) + 2.0265) / 2.0 * 0.0010000000000000009;
  D_idx_3 = (X_idx_2 + 2.0265) / 2.0 * 0.0010000000000000009;
  if (T_idx_0 <= 0.0) {
    t2 = true;
  } else {
    t2 = (T_idx_0 > 0.02);
  }

  if (t11 <= 0.0) {
    t3 = true;
  } else {
    t3 = (t11 > 0.02);
  }

  t4_idx_13 = (int32_T)(((fabs(D_idx_2) >= -1.0) && (fabs(D_idx_2) <= 1.0)) ||
                        t2);
  t4_idx_18 = (int32_T)(((fabs(D_idx_5) >= -1.0) && (fabs(D_idx_5) <= 1.0)) ||
                        t3);
  t4_idx_29 = (int32_T)((!(-X_idx_2 * -X_idx_2 + D_idx_3 * D_idx_3 >= 0.0)) ||
                        (pmf_sqrt(pmf_sqrt(-X_idx_2 * -X_idx_2 + D_idx_3 *
    D_idx_3)) != 0.0));
  t4_idx_34 = (int32_T)((!(X_idx_5 * X_idx_5 + 5.9994706640625018E-13 >= 0.0)) ||
                        (pmf_sqrt(pmf_sqrt(X_idx_5 * X_idx_5 +
    5.9994706640625018E-13)) != 0.0));
  t4_idx_41 = (int32_T)((!(D_idx_0 * D_idx_0 + D_idx_1 * D_idx_1 >= 0.0)) ||
                        (pmf_sqrt(pmf_sqrt(D_idx_0 * D_idx_0 + D_idx_1 * D_idx_1))
    != 0.0));
  out.mX[0] = (int32_T)(X_idx_0 * 0.001 >= 0.0);
  out.mX[1] = 1;
  out.mX[2] = 1;
  out.mX[3] = 1;
  out.mX[4] = (int32_T)((CI_idx_1 != 0) || (!(-U_idx_0 >= 0.5)) || (0.01 - t11 ==
    0.0) || ((0.01 - t11) / 0.01 * ((0.01 - t11) / 0.01) * 0.010000000000000002
             != 0.0));
  out.mX[5] = 1;
  out.mX[6] = (int32_T)((CI_idx_0 != 0) || (!(-U_idx_0 < 0.5)) || (t11 == 0.0) ||
                        (t11 / 0.01 * (t11 / 0.01) * 0.010000000000000002 != 0.0)
                        || ((CI_idx_1 == 0) && (-U_idx_0 >= 0.5)));
  out.mX[7] = 1;
  out.mX[8] = 1;
  out.mX[9] = 1;
  out.mX[10] = (int32_T)((CI_idx_3 != 0) || (!(-U_idx_0 >= 0.5)) || (0.01 -
    T_idx_0 == 0.0) || ((0.01 - T_idx_0) / 0.01 * ((0.01 - T_idx_0) / 0.01) *
                        0.010000000000000002 != 0.0));
  out.mX[11] = 1;
  out.mX[12] = (int32_T)((CI_idx_2 != 0) || (!(-U_idx_0 < 0.5)) || (T_idx_0 ==
    0.0) || (T_idx_0 / 0.01 * (T_idx_0 / 0.01) * 0.010000000000000002 != 0.0) ||
    ((CI_idx_3 == 0) && (-U_idx_0 >= 0.5)));
  out.mX[13] = t4_idx_13;
  out.mX[14] = 1;
  out.mX[15] = 1;
  out.mX[16] = 1;
  out.mX[17] = 1;
  out.mX[18] = t4_idx_18;
  out.mX[19] = 1;
  out.mX[20] = 1;
  out.mX[21] = 1;
  out.mX[22] = 1;
  out.mX[23] = 1;
  out.mX[24] = 1;
  out.mX[25] = 1;
  out.mX[26] = 1;
  out.mX[27] = 1;
  out.mX[28] = (int32_T)(-X_idx_2 * -X_idx_2 + D_idx_3 * D_idx_3 >= 0.0);
  out.mX[29] = t4_idx_29;
  out.mX[30] = 1;
  out.mX[31] = 1;
  out.mX[32] = 1;
  out.mX[33] = (int32_T)(X_idx_5 * X_idx_5 + 5.9994706640625018E-13 >= 0.0);
  out.mX[34] = t4_idx_34;
  out.mX[35] = 1;
  out.mX[36] = 1;
  out.mX[37] = 1;
  out.mX[38] = 1;
  out.mX[39] = 1;
  out.mX[40] = (int32_T)(D_idx_0 * D_idx_0 + D_idx_1 * D_idx_1 >= 0.0);
  out.mX[41] = t4_idx_41;
  (void)sys;
  (void)t13;
  return 0;
}
