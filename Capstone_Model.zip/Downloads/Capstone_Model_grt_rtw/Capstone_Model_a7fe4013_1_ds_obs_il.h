/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */
/* Capstone_Model_a7fe4013_1_ds_obs_il.h - header for method Capstone_Model_a7fe4013_1_ds_obs_il */
#ifdef __cplusplus

extern "C"
{

#endif

#ifndef CAPSTONE_MODEL_A7FE4013_1_DS_OBS_IL_H
#define CAPSTONE_MODEL_A7FE4013_1_DS_OBS_IL_H 1

  int32_T Capstone_Model_a7fe4013_1_ds_obs_il(const NeDynamicSystem *sys, const
    NeDynamicSystemInput *Q, NeDsMethodOutput *M);

#endif                       /* #ifndef CAPSTONE_MODEL_A7FE4013_1_DS_OBS_IL_H */

#ifdef __cplusplus

}

#endif
