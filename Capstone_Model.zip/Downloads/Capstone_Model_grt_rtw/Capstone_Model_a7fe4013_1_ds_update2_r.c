/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_update2_r.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_update2_r(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t25, NeDsMethodOutput *t26)
{
  PmRealVector out;
  real_T D_idx_0;
  real_T D_idx_1;
  real_T D_idx_2;
  real_T D_idx_3;
  real_T D_idx_4;
  real_T D_idx_5;
  real_T D_idx_6;
  real_T D_idx_7;
  real_T T_idx_0;
  real_T U_idx_0;
  real_T intrm_sf_mf_21;
  real_T t12;
  real_T t2;
  real_T t3;
  real_T t4;
  real_T t6;
  int32_T CI_idx_4;
  int32_T CI_idx_5;
  int32_T CI_idx_6;
  int32_T CI_idx_7;
  T_idx_0 = t25->mT.mX[0];
  U_idx_0 = t25->mU.mX[0];
  D_idx_0 = t25->mD.mX[0];
  D_idx_1 = t25->mD.mX[1];
  D_idx_2 = t25->mD.mX[2];
  D_idx_3 = t25->mD.mX[3];
  D_idx_4 = t25->mD.mX[4];
  D_idx_5 = t25->mD.mX[5];
  D_idx_6 = t25->mD.mX[6];
  D_idx_7 = t25->mD.mX[7];
  CI_idx_4 = t25->mCI.mX[4];
  CI_idx_5 = t25->mCI.mX[5];
  CI_idx_6 = t25->mCI.mX[6];
  CI_idx_7 = t25->mCI.mX[7];
  out = t26->mUPDATE2_R;
  t6 = T_idx_0 - D_idx_2;
  if (t6 <= D_idx_0 * 0.33333333333333331) {
    t2 = D_idx_1;
  } else {
    t2 = t6 <= D_idx_0 * 0.66666666666666663 ? (t6 - D_idx_0 *
      0.33333333333333331) * (t6 - D_idx_0 * 0.33333333333333331) * D_idx_3 *
      0.5 + D_idx_1 : (D_idx_0 * D_idx_3 * D_idx_0 * 0.055555555555555552 + (t6
      - D_idx_0 * 0.66666666666666663) * D_idx_3 * D_idx_0 * 0.33333333333333331)
      + D_idx_1;
  }

  t3 = t2 > 0.01 ? 0.01 : t2;
  t6 = t3 > 0.0 ? t3 : 0.0;
  intrm_sf_mf_21 = T_idx_0 - D_idx_6;
  if (intrm_sf_mf_21 <= D_idx_4 * 0.33333333333333331) {
    t4 = D_idx_5;
  } else {
    t4 = intrm_sf_mf_21 <= D_idx_4 * 0.66666666666666663 ? (intrm_sf_mf_21 -
      D_idx_4 * 0.33333333333333331) * (intrm_sf_mf_21 - D_idx_4 *
      0.33333333333333331) * D_idx_7 * 0.5 + D_idx_5 : (D_idx_4 * D_idx_7 *
      D_idx_4 * 0.055555555555555552 + (intrm_sf_mf_21 - D_idx_4 *
      0.66666666666666663) * D_idx_7 * D_idx_4 * 0.33333333333333331) + D_idx_5;
  }

  t12 = t4 > 0.01 ? 0.01 : t4;
  intrm_sf_mf_21 = t12 > 0.0 ? t12 : 0.0;
  if ((CI_idx_5 == 0) && (-U_idx_0 > 0.0)) {
    t2 = (0.01 - t6) / 0.01 * 0.1;
  } else if ((CI_idx_4 == 0) && (-U_idx_0 < 0.0)) {
    t2 = t6 / 0.01 * 0.1;
  } else {
    t2 = D_idx_0;
  }

  if ((CI_idx_5 == 0) && (-U_idx_0 > 0.0)) {
    t3 = t6;
  } else {
    t3 = (CI_idx_4 == 0) && (-U_idx_0 < 0.0) ? t6 : D_idx_1;
  }

  if ((CI_idx_5 == 0) && (-U_idx_0 > 0.0)) {
    t4 = T_idx_0;
  } else {
    t4 = (CI_idx_4 == 0) && (-U_idx_0 < 0.0) ? T_idx_0 : D_idx_2;
  }

  if ((CI_idx_5 == 0) && (-U_idx_0 > 0.0)) {
    if (0.01 - t6 == 0.0) {
      t12 = 0.0;
    } else {
      D_idx_0 = (0.01 - t6) / 0.01 * ((0.01 - t6) / 0.01) * 0.010000000000000002;
      t12 = (0.01 - t6) / (D_idx_0 == 0.0 ? 1.0E-16 : D_idx_0) * 6.0;
    }
  } else if ((CI_idx_4 == 0) && (-U_idx_0 < 0.0)) {
    if (t6 == 0.0) {
      t12 = 0.0;
    } else {
      D_idx_0 = t6 / 0.01 * (t6 / 0.01) * 0.010000000000000002;
      t12 = t6 / (D_idx_0 == 0.0 ? 1.0E-16 : D_idx_0) * -6.0;
    }
  } else {
    t12 = D_idx_3;
  }

  if ((CI_idx_7 == 0) && (-U_idx_0 > 0.0)) {
    t6 = (0.01 - intrm_sf_mf_21) / 0.01 * 0.1;
  } else if ((CI_idx_6 == 0) && (-U_idx_0 < 0.0)) {
    t6 = intrm_sf_mf_21 / 0.01 * 0.1;
  } else {
    t6 = D_idx_4;
  }

  if ((CI_idx_7 == 0) && (-U_idx_0 > 0.0)) {
    D_idx_1 = intrm_sf_mf_21;
  } else {
    D_idx_1 = (CI_idx_6 == 0) && (-U_idx_0 < 0.0) ? intrm_sf_mf_21 : D_idx_5;
  }

  if ((CI_idx_7 == 0) && (-U_idx_0 > 0.0)) {
  } else {
    T_idx_0 = (CI_idx_6 == 0) && (-U_idx_0 < 0.0) ? T_idx_0 : D_idx_6;
  }

  if ((CI_idx_7 == 0) && (-U_idx_0 > 0.0)) {
    if (0.01 - intrm_sf_mf_21 == 0.0) {
      D_idx_7 = 0.0;
    } else {
      D_idx_0 = (0.01 - intrm_sf_mf_21) / 0.01 * ((0.01 - intrm_sf_mf_21) / 0.01)
        * 0.010000000000000002;
      D_idx_7 = (0.01 - intrm_sf_mf_21) / (D_idx_0 == 0.0 ? 1.0E-16 : D_idx_0) *
        6.0;
    }
  } else if ((CI_idx_6 == 0) && (-U_idx_0 < 0.0)) {
    if (intrm_sf_mf_21 == 0.0) {
      D_idx_7 = 0.0;
    } else {
      D_idx_0 = intrm_sf_mf_21 / 0.01 * (intrm_sf_mf_21 / 0.01) *
        0.010000000000000002;
      D_idx_7 = intrm_sf_mf_21 / (D_idx_0 == 0.0 ? 1.0E-16 : D_idx_0) * -6.0;
    }
  }

  out.mX[0] = t2;
  out.mX[1] = t3;
  out.mX[2] = t4;
  out.mX[3] = t12;
  out.mX[4] = t6;
  out.mX[5] = D_idx_1;
  out.mX[6] = T_idx_0;
  out.mX[7] = D_idx_7;
  (void)sys;
  (void)t26;
  return 0;
}
