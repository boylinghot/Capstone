/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_dxf.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_dxf(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t33, NeDsMethodOutput *t34)
{
  PmRealVector out;
  real_T D_idx_0;
  real_T D_idx_1;
  real_T D_idx_2;
  real_T D_idx_3;
  real_T D_idx_4;
  real_T D_idx_5;
  real_T D_idx_6;
  real_T D_idx_7;
  real_T T_idx_0;
  real_T X_idx_1;
  real_T X_idx_2;
  real_T X_idx_4;
  real_T X_idx_5;
  real_T t10;
  real_T t11;
  real_T t13;
  real_T t7;
  real_T zc_int12;
  int32_T M_idx_2;
  int32_T M_idx_3;
  int32_T M_idx_4;
  int32_T M_idx_5;
  M_idx_2 = t33->mM.mX[2];
  M_idx_3 = t33->mM.mX[3];
  M_idx_4 = t33->mM.mX[4];
  M_idx_5 = t33->mM.mX[5];
  T_idx_0 = t33->mT.mX[0];
  X_idx_1 = t33->mX.mX[1];
  X_idx_2 = t33->mX.mX[2];
  X_idx_4 = t33->mX.mX[4];
  X_idx_5 = t33->mX.mX[5];
  D_idx_0 = t33->mD.mX[0];
  D_idx_1 = t33->mD.mX[1];
  D_idx_2 = t33->mD.mX[2];
  D_idx_3 = t33->mD.mX[3];
  D_idx_4 = t33->mD.mX[4];
  D_idx_5 = t33->mD.mX[5];
  D_idx_6 = t33->mD.mX[6];
  D_idx_7 = t33->mD.mX[7];
  out = t34->mDXF;
  t11 = T_idx_0 - D_idx_2;
  if (t11 <= D_idx_0 * 0.33333333333333331) {
  } else {
    D_idx_1 = t11 <= D_idx_0 * 0.66666666666666663 ? (t11 - D_idx_0 *
      0.33333333333333331) * (t11 - D_idx_0 * 0.33333333333333331) * D_idx_3 *
      0.5 + D_idx_1 : (D_idx_0 * D_idx_3 * D_idx_0 * 0.055555555555555552 + (t11
      - D_idx_0 * 0.66666666666666663) * D_idx_3 * D_idx_0 * 0.33333333333333331)
      + D_idx_1;
  }

  t7 = D_idx_1 > 0.01 ? 0.01 : D_idx_1;
  D_idx_1 = T_idx_0 - D_idx_6;
  if (D_idx_1 <= D_idx_4 * 0.33333333333333331) {
  } else {
    D_idx_5 = D_idx_1 <= D_idx_4 * 0.66666666666666663 ? (D_idx_1 - D_idx_4 *
      0.33333333333333331) * (D_idx_1 - D_idx_4 * 0.33333333333333331) * D_idx_7
      * 0.5 + D_idx_5 : (D_idx_4 * D_idx_7 * D_idx_4 * 0.055555555555555552 +
                         (D_idx_1 - D_idx_4 * 0.66666666666666663) * D_idx_7 *
                         D_idx_4 * 0.33333333333333331) + D_idx_5;
  }

  D_idx_2 = D_idx_5 > 0.01 ? 0.01 : D_idx_5;
  D_idx_1 = -X_idx_5 + X_idx_2;
  t13 = 1.0 - (t7 > 0.0 ? t7 : 0.0) / 0.01;
  t7 = ((X_idx_2 + X_idx_5) + 2.0265) / 2.0 * 0.0010000000000000009;
  t10 = (X_idx_2 + 2.0265) / 2.0 * 0.0010000000000000009;
  if (M_idx_5 != 0) {
    D_idx_5 = 0.0;
  } else {
    D_idx_5 = pmf_acos(fabs(1.0 - (D_idx_2 > 0.0 ? D_idx_2 : 0.0) / 0.01));
  }

  if (M_idx_5 != 0) {
    zc_int12 = 1.0E-12;
  } else {
    D_idx_7 = sin(D_idx_5 * 2.0);
    zc_int12 = (D_idx_5 / 2.0 - D_idx_7 / 4.0) * 0.0001 + 1.0E-12;
  }

  if (M_idx_2 != 0) {
    D_idx_5 = 0.0;
  } else {
    D_idx_5 = pmf_acos(fabs(t13));
  }

  if (M_idx_2 != 0) {
    t13 = 1.0E-12;
  } else {
    D_idx_0 = sin(D_idx_5 * 2.0);
    t13 = (D_idx_5 / 2.0 - D_idx_0 / 4.0) * 0.0001 + 1.0E-12;
  }

  if (M_idx_3 != 0) {
    D_idx_6 = (X_idx_1 - 0.1) * 2.0E+9;
  } else if (M_idx_4 != 0) {
    D_idx_6 = X_idx_1 * -2.0E+9;
  } else {
    D_idx_6 = 0.0;
  }

  if (M_idx_3 != 0) {
    D_idx_7 = X_idx_4 * 2.0E+9;
  } else if (M_idx_4 != 0) {
    D_idx_7 = -(X_idx_4 * 0.002) * 1.0E+12;
  } else {
    D_idx_7 = 0.0;
  }

  D_idx_0 = pmf_sqrt(-X_idx_2 * -X_idx_2 + t10 * t10) * pmf_sqrt(pmf_sqrt
    (-X_idx_2 * -X_idx_2 + t10 * t10));
  D_idx_4 = pmf_sqrt(pmf_sqrt(-X_idx_2 * -X_idx_2 + t10 * t10)) * pmf_sqrt
    (pmf_sqrt(-X_idx_2 * -X_idx_2 + t10 * t10));
  D_idx_2 = pmf_sqrt(pmf_sqrt(-X_idx_2 * -X_idx_2 + t10 * t10));
  t13 = -(((X_idx_2 * 2.0 + 0.00050000000000000044 * t10 * 2.0) * (-(-X_idx_2 *
             t13 * 0.031529631254723287) / (D_idx_4 == 0.0 ? 1.0E-16 : D_idx_4))
           * (1.0 / (D_idx_0 == 0.0 ? 1.0E-16 : D_idx_0)) * 0.25 + -t13 *
           0.031529631254723287 / (D_idx_2 == 0.0 ? 1.0E-16 : D_idx_2)) *
          3.1622776601683795E+8);
  t10 = pmf_sqrt(D_idx_1 * D_idx_1 + t7 * t7) * pmf_sqrt(pmf_sqrt(D_idx_1 *
    D_idx_1 + t7 * t7));
  D_idx_4 = -(D_idx_1 * zc_int12 * 0.031529631254723287);
  D_idx_2 = pmf_sqrt(pmf_sqrt(D_idx_1 * D_idx_1 + t7 * t7)) * pmf_sqrt(pmf_sqrt
    (D_idx_1 * D_idx_1 + t7 * t7));
  D_idx_0 = pmf_sqrt(pmf_sqrt(D_idx_1 * D_idx_1 + t7 * t7));
  t11 = pmf_sqrt(X_idx_5 * X_idx_5 + 5.9994706640625018E-13) * pmf_sqrt(pmf_sqrt
    (X_idx_5 * X_idx_5 + 5.9994706640625018E-13));
  D_idx_3 = pmf_sqrt(pmf_sqrt(X_idx_5 * X_idx_5 + 5.9994706640625018E-13)) *
    pmf_sqrt(pmf_sqrt(X_idx_5 * X_idx_5 + 5.9994706640625018E-13));
  T_idx_0 = pmf_sqrt(pmf_sqrt(X_idx_5 * X_idx_5 + 5.9994706640625018E-13));
  out.mX[0] = D_idx_7 / 50.0;
  out.mX[1] = t13;
  out.mX[2] = -(((D_idx_1 * 2.0 + 0.00050000000000000044 * t7 * 2.0) * (D_idx_4 /
    (D_idx_2 == 0.0 ? 1.0E-16 : D_idx_2)) * (1.0 / (t10 == 0.0 ? 1.0E-16 : t10))
                 * 0.25 + zc_int12 * 0.031529631254723287 / (D_idx_0 == 0.0 ?
    1.0E-16 : D_idx_0)) * 3.1622776601683795E+8);
  out.mX[3] = D_idx_6 / 50.0;
  out.mX[4] = -((-(X_idx_5 * 1.5238962756959047E-5) / (D_idx_3 == 0.0 ? 1.0E-16 :
    D_idx_3) * (1.0 / (t11 == 0.0 ? 1.0E-16 : t11)) * X_idx_5 * 0.5 +
                 1.5238962756959047E-5 / (T_idx_0 == 0.0 ? 1.0E-16 : T_idx_0)) *
                3.1622776601683795E+8);
  out.mX[5] = -(((-D_idx_1 * 2.0 + 0.00050000000000000044 * t7 * 2.0) * (D_idx_4
    / (D_idx_2 == 0.0 ? 1.0E-16 : D_idx_2)) * (1.0 / (t10 == 0.0 ? 1.0E-16 : t10))
                 * 0.25 + -zc_int12 * 0.031529631254723287 / (D_idx_0 == 0.0 ?
    1.0E-16 : D_idx_0)) * 3.1622776601683795E+8);
  (void)sys;
  (void)t34;
  return 0;
}
