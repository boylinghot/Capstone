/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_obs_il.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_obs_il(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t1, NeDsMethodOutput *t2)
{
  PmBoolVector out;
  (void)t1;
  out = t2->mOBS_IL;
  out.mX[0] = true;
  out.mX[1] = true;
  out.mX[2] = false;
  out.mX[3] = true;
  out.mX[4] = true;
  out.mX[5] = false;
  out.mX[6] = false;
  out.mX[7] = false;
  out.mX[8] = false;
  out.mX[9] = false;
  out.mX[10] = false;
  out.mX[11] = false;
  out.mX[12] = false;
  out.mX[13] = true;
  out.mX[14] = true;
  out.mX[15] = true;
  out.mX[16] = true;
  out.mX[17] = true;
  out.mX[18] = true;
  out.mX[19] = true;
  out.mX[20] = true;
  out.mX[21] = true;
  out.mX[22] = true;
  out.mX[23] = true;
  out.mX[24] = true;
  out.mX[25] = false;
  out.mX[26] = true;
  out.mX[27] = true;
  out.mX[28] = true;
  out.mX[29] = true;
  out.mX[30] = true;
  out.mX[31] = true;
  out.mX[32] = true;
  out.mX[33] = true;
  out.mX[34] = true;
  out.mX[35] = false;
  out.mX[36] = true;
  out.mX[37] = false;
  out.mX[38] = true;
  out.mX[39] = true;
  out.mX[40] = false;
  out.mX[41] = false;
  out.mX[42] = true;
  out.mX[43] = true;
  out.mX[44] = true;
  out.mX[45] = true;
  out.mX[46] = true;
  out.mX[47] = false;
  out.mX[48] = true;
  out.mX[49] = true;
  out.mX[50] = false;
  out.mX[51] = false;
  out.mX[52] = false;
  out.mX[53] = false;
  out.mX[54] = false;
  out.mX[55] = false;
  out.mX[56] = false;
  out.mX[57] = false;
  out.mX[58] = false;
  (void)sys;
  (void)t2;
  return 0;
}
