/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */
/* Capstone_Model_a7fe4013_1_ds.h - header for module Capstone_Model_a7fe4013_1_ds */
#ifdef __cplusplus

extern "C"
{

#endif

#ifndef CAPSTONE_MODEL_A7FE4013_1_DS_H
#define CAPSTONE_MODEL_A7FE4013_1_DS_H 1

  extern NeDynamicSystem *Capstone_Model_a7fe4013_1_dae_ds(PmAllocator
    *allocator );

#endif                              /* #ifndef CAPSTONE_MODEL_A7FE4013_1_DS_H */

#ifdef __cplusplus

}

#endif
