/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_lock2_r.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_lock2_r(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t1, NeDsMethodOutput *t2)
{
  PmBoolVector out;
  real_T U_idx_0;
  int32_T CI_idx_4;
  int32_T CI_idx_5;
  int32_T CI_idx_6;
  int32_T CI_idx_7;
  boolean_T indicator2;
  boolean_T indicator3;
  U_idx_0 = t1->mU.mX[0];
  CI_idx_4 = t1->mCI.mX[4];
  CI_idx_5 = t1->mCI.mX[5];
  CI_idx_6 = t1->mCI.mX[6];
  CI_idx_7 = t1->mCI.mX[7];
  out = t2->mLOCK2_R;
  if ((CI_idx_5 == 0) && (-U_idx_0 > 0.0)) {
    indicator2 = true;
  } else {
    indicator2 = ((CI_idx_4 == 0) && (-U_idx_0 < 0.0));
  }

  if ((CI_idx_7 == 0) && (-U_idx_0 > 0.0)) {
    indicator3 = true;
  } else {
    indicator3 = ((CI_idx_6 == 0) && (-U_idx_0 < 0.0));
  }

  out.mX[0] = indicator2;
  out.mX[1] = indicator2;
  out.mX[2] = indicator2;
  out.mX[3] = indicator2;
  out.mX[4] = indicator3;
  out.mX[5] = indicator3;
  out.mX[6] = indicator3;
  out.mX[7] = indicator3;
  (void)sys;
  (void)t2;
  return 0;
}
