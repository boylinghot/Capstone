/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */
/* Capstone_Model_a7fe4013_1_ds_f.h - header for method Capstone_Model_a7fe4013_1_ds_f */
#ifdef __cplusplus

extern "C"
{

#endif

#ifndef CAPSTONE_MODEL_A7FE4013_1_DS_F_H
#define CAPSTONE_MODEL_A7FE4013_1_DS_F_H 1

  int32_T Capstone_Model_a7fe4013_1_ds_f(const NeDynamicSystem *sys, const
    NeDynamicSystemInput *Q, NeDsMethodOutput *M);

#endif                            /* #ifndef CAPSTONE_MODEL_A7FE4013_1_DS_F_H */

#ifdef __cplusplus

}

#endif
