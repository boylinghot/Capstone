/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_ddf.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_ddf(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t63, NeDsMethodOutput *t64)
{
  PmRealVector out;
  real_T D_idx_0;
  real_T D_idx_1;
  real_T D_idx_2;
  real_T D_idx_3;
  real_T D_idx_4;
  real_T D_idx_5;
  real_T D_idx_6;
  real_T D_idx_7;
  real_T T_idx_0;
  real_T X_idx_2;
  real_T X_idx_5;
  real_T intermediate_der100;
  real_T intermediate_der101;
  real_T intermediate_der102;
  real_T intermediate_der128;
  real_T intermediate_der132;
  real_T intermediate_der18;
  real_T intermediate_der42;
  real_T t1;
  real_T t19;
  real_T t20;
  real_T t30;
  real_T t39;
  real_T t48;
  real_T t49;
  real_T t57;
  int32_T M_idx_2;
  int32_T M_idx_5;
  M_idx_2 = t63->mM.mX[2];
  M_idx_5 = t63->mM.mX[5];
  T_idx_0 = t63->mT.mX[0];
  X_idx_2 = t63->mX.mX[2];
  X_idx_5 = t63->mX.mX[5];
  D_idx_0 = t63->mD.mX[0];
  D_idx_1 = t63->mD.mX[1];
  D_idx_2 = t63->mD.mX[2];
  D_idx_3 = t63->mD.mX[3];
  D_idx_4 = t63->mD.mX[4];
  D_idx_5 = t63->mD.mX[5];
  D_idx_6 = t63->mD.mX[6];
  D_idx_7 = t63->mD.mX[7];
  out = t64->mDDF;
  t48 = T_idx_0 - D_idx_2;
  intermediate_der18 = (t48 - D_idx_0 * 0.33333333333333331) * (t48 - D_idx_0 *
    0.33333333333333331) * D_idx_3 * 0.5 + D_idx_1;
  intermediate_der128 = (D_idx_0 * D_idx_3 * D_idx_0 * 0.055555555555555552 +
    (t48 - D_idx_0 * 0.66666666666666663) * D_idx_3 * D_idx_0 *
    0.33333333333333331) + D_idx_1;
  if (t48 <= D_idx_0 * 0.33333333333333331) {
    D_idx_2 = D_idx_1;
  } else {
    D_idx_2 = t48 <= D_idx_0 * 0.66666666666666663 ? intermediate_der18 :
      intermediate_der128;
  }

  t19 = D_idx_2 > 0.01 ? 0.01 : D_idx_2;
  t19 = t19 > 0.0 ? t19 : 0.0;
  intermediate_der101 = T_idx_0 - D_idx_6;
  intermediate_der100 = (intermediate_der101 - D_idx_4 * 0.33333333333333331) *
    (intermediate_der101 - D_idx_4 * 0.33333333333333331) * D_idx_7 * 0.5 +
    D_idx_5;
  intermediate_der102 = (D_idx_4 * D_idx_7 * D_idx_4 * 0.055555555555555552 +
    (intermediate_der101 - D_idx_4 * 0.66666666666666663) * D_idx_7 * D_idx_4 *
    0.33333333333333331) + D_idx_5;
  if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
    t1 = D_idx_5;
  } else {
    t1 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
      intermediate_der100 : intermediate_der102;
  }

  t20 = t1 > 0.01 ? 0.01 : t1;
  t20 = t20 > 0.0 ? t20 : 0.0;
  t1 = -X_idx_5 + X_idx_2;
  intermediate_der132 = 1.0 - t19 / 0.01;
  t19 = 1.0 - t20 / 0.01;
  t20 = ((X_idx_2 + X_idx_5) + 2.0265) / 2.0 * 0.0010000000000000009;
  t49 = (X_idx_2 + 2.0265) / 2.0 * 0.0010000000000000009;
  if (M_idx_5 != 0) {
    t39 = 0.0;
  } else {
    t39 = pmf_acos(fabs(t19));
  }

  if (M_idx_2 != 0) {
    t30 = 0.0;
  } else {
    t30 = pmf_acos(fabs(intermediate_der132));
  }

  if (t48 <= D_idx_0 * 0.33333333333333331) {
    T_idx_0 = D_idx_1;
  } else {
    T_idx_0 = t48 <= D_idx_0 * 0.66666666666666663 ? intermediate_der18 :
      intermediate_der128;
  }

  if ((T_idx_0 > 0.01 ? 0.01 : T_idx_0) <= 0.0) {
    intermediate_der42 = 0.0;
  } else {
    if (t48 <= D_idx_0 * 0.33333333333333331) {
      D_idx_2 = D_idx_1;
    } else {
      D_idx_2 = t48 <= D_idx_0 * 0.66666666666666663 ? intermediate_der18 :
        intermediate_der128;
    }

    if (D_idx_2 >= 0.01) {
      intermediate_der42 = 0.0;
    } else {
      intermediate_der42 = 1.0;
    }
  }

  if (t48 <= D_idx_0 * 0.33333333333333331) {
    D_idx_2 = D_idx_1;
  } else {
    D_idx_2 = t48 <= D_idx_0 * 0.66666666666666663 ? intermediate_der18 :
      intermediate_der128;
  }

  if ((D_idx_2 > 0.01 ? 0.01 : D_idx_2) <= 0.0) {
    T_idx_0 = 0.0;
  } else {
    if (t48 <= D_idx_0 * 0.33333333333333331) {
      D_idx_2 = D_idx_1;
    } else {
      D_idx_2 = t48 <= D_idx_0 * 0.66666666666666663 ? intermediate_der18 :
        intermediate_der128;
    }

    if (D_idx_2 >= 0.01) {
      T_idx_0 = 0.0;
    } else if (t48 <= D_idx_0 * 0.33333333333333331) {
      T_idx_0 = 0.0;
    } else {
      T_idx_0 = t48 <= D_idx_0 * 0.66666666666666663 ? (-(t48 - D_idx_0 *
        0.33333333333333331) - (t48 - D_idx_0 * 0.33333333333333331)) * D_idx_3 *
        0.5 : -(D_idx_0 * D_idx_3) * 0.33333333333333331;
    }
  }

  if (t48 <= D_idx_0 * 0.33333333333333331) {
    D_idx_2 = D_idx_1;
  } else {
    D_idx_2 = t48 <= D_idx_0 * 0.66666666666666663 ? intermediate_der18 :
      intermediate_der128;
  }

  if ((D_idx_2 > 0.01 ? 0.01 : D_idx_2) <= 0.0) {
    t57 = 0.0;
  } else {
    if (t48 <= D_idx_0 * 0.33333333333333331) {
      D_idx_2 = D_idx_1;
    } else {
      D_idx_2 = t48 <= D_idx_0 * 0.66666666666666663 ? intermediate_der18 :
        intermediate_der128;
    }

    if (D_idx_2 >= 0.01) {
      t57 = 0.0;
    } else if (t48 <= D_idx_0 * 0.33333333333333331) {
      t57 = 0.0;
    } else {
      t57 = t48 <= D_idx_0 * 0.66666666666666663 ? ((t48 - D_idx_0 *
        0.33333333333333331) * -0.33333333333333331 + (t48 - D_idx_0 *
        0.33333333333333331) * -0.33333333333333331) * D_idx_3 * 0.5 : ((D_idx_0
        * 0.1111111111111111 + D_idx_0 * 0.1111111111111111) * D_idx_3 * 0.5 +
        D_idx_0 * D_idx_3 * -0.22222222222222221) + (t48 - D_idx_0 *
        0.66666666666666663) * D_idx_3 * 0.33333333333333331;
    }
  }

  if (t48 <= D_idx_0 * 0.33333333333333331) {
    D_idx_2 = D_idx_1;
  } else {
    D_idx_2 = t48 <= D_idx_0 * 0.66666666666666663 ? intermediate_der18 :
      intermediate_der128;
  }

  if ((D_idx_2 > 0.01 ? 0.01 : D_idx_2) <= 0.0) {
    X_idx_5 = 0.0;
  } else {
    if (t48 <= D_idx_0 * 0.33333333333333331) {
      D_idx_2 = D_idx_1;
    } else {
      D_idx_2 = t48 <= D_idx_0 * 0.66666666666666663 ? intermediate_der18 :
        intermediate_der128;
    }

    if (D_idx_2 >= 0.01) {
      X_idx_5 = 0.0;
    } else if (t48 <= D_idx_0 * 0.33333333333333331) {
      X_idx_5 = 0.0;
    } else {
      X_idx_5 = t48 <= D_idx_0 * 0.66666666666666663 ? (t48 - D_idx_0 *
        0.33333333333333331) * (t48 - D_idx_0 * 0.33333333333333331) * 0.5 :
        D_idx_0 * D_idx_0 * 0.055555555555555552 + (t48 - D_idx_0 *
        0.66666666666666663) * D_idx_0 * 0.33333333333333331;
    }
  }

  intermediate_der18 = t57;
  intermediate_der128 = T_idx_0;
  D_idx_3 = intermediate_der42;
  if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
    T_idx_0 = D_idx_5;
  } else {
    T_idx_0 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
      intermediate_der100 : intermediate_der102;
  }

  if ((T_idx_0 > 0.01 ? 0.01 : T_idx_0) <= 0.0) {
    intermediate_der42 = 0.0;
  } else {
    if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
      D_idx_2 = D_idx_5;
    } else {
      D_idx_2 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
        intermediate_der100 : intermediate_der102;
    }

    if (D_idx_2 >= 0.01) {
      intermediate_der42 = 0.0;
    } else {
      intermediate_der42 = 1.0;
    }
  }

  if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
    T_idx_0 = D_idx_5;
  } else {
    T_idx_0 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
      intermediate_der100 : intermediate_der102;
  }

  if ((T_idx_0 > 0.01 ? 0.01 : T_idx_0) <= 0.0) {
    D_idx_6 = 0.0;
  } else {
    if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
      D_idx_2 = D_idx_5;
    } else {
      D_idx_2 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
        intermediate_der100 : intermediate_der102;
    }

    if (D_idx_2 >= 0.01) {
      D_idx_6 = 0.0;
    } else if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
      D_idx_6 = 0.0;
    } else {
      D_idx_6 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
        ((intermediate_der101 - D_idx_4 * 0.33333333333333331) *
         -0.33333333333333331 + (intermediate_der101 - D_idx_4 *
          0.33333333333333331) * -0.33333333333333331) * D_idx_7 * 0.5 :
        ((D_idx_4 * 0.1111111111111111 + D_idx_4 * 0.1111111111111111) * D_idx_7
         * 0.5 + D_idx_4 * D_idx_7 * -0.22222222222222221) +
        (intermediate_der101 - D_idx_4 * 0.66666666666666663) * D_idx_7 *
        0.33333333333333331;
    }
  }

  if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
    D_idx_2 = D_idx_5;
  } else {
    D_idx_2 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
      intermediate_der100 : intermediate_der102;
  }

  if ((D_idx_2 > 0.01 ? 0.01 : D_idx_2) <= 0.0) {
    T_idx_0 = 0.0;
  } else {
    if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
      T_idx_0 = D_idx_5;
    } else {
      T_idx_0 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
        intermediate_der100 : intermediate_der102;
    }

    if (T_idx_0 >= 0.01) {
      T_idx_0 = 0.0;
    } else if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
      T_idx_0 = 0.0;
    } else {
      T_idx_0 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
        (-(intermediate_der101 - D_idx_4 * 0.33333333333333331) -
         (intermediate_der101 - D_idx_4 * 0.33333333333333331)) * D_idx_7 * 0.5 :
        -(D_idx_4 * D_idx_7) * 0.33333333333333331;
    }
  }

  if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
    D_idx_2 = D_idx_5;
  } else {
    D_idx_2 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
      intermediate_der100 : intermediate_der102;
  }

  if ((D_idx_2 > 0.01 ? 0.01 : D_idx_2) <= 0.0) {
    t57 = 0.0;
  } else {
    if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
    } else {
      D_idx_5 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
        intermediate_der100 : intermediate_der102;
    }

    if (D_idx_5 >= 0.01) {
      t57 = 0.0;
    } else if (intermediate_der101 <= D_idx_4 * 0.33333333333333331) {
      t57 = 0.0;
    } else {
      t57 = intermediate_der101 <= D_idx_4 * 0.66666666666666663 ?
        (intermediate_der101 - D_idx_4 * 0.33333333333333331) *
        (intermediate_der101 - D_idx_4 * 0.33333333333333331) * 0.5 : D_idx_4 *
        D_idx_4 * 0.055555555555555552 + (intermediate_der101 - D_idx_4 *
        0.66666666666666663) * D_idx_4 * 0.33333333333333331;
    }
  }

  intermediate_der102 = D_idx_6;
  D_idx_6 = -(X_idx_5 / 0.01);
  t48 = -(intermediate_der18 / 0.01);
  intermediate_der18 = -(intermediate_der128 / 0.01);
  intermediate_der128 = -(D_idx_3 / 0.01);
  D_idx_3 = -(t57 / 0.01);
  intermediate_der101 = -(T_idx_0 / 0.01);
  if (M_idx_5 != 0) {
    T_idx_0 = 0.0;
  } else {
    X_idx_5 = pmf_sqrt(1.0 - fabs(t19) * fabs(t19));
    if (t19 != t19) {
      t57 = t19;
    } else if (t19 > 0.0) {
      t57 = 1.0;
    } else {
      t57 = t19 < 0.0 ? -1.0 : 0.0;
    }

    T_idx_0 = -(1.0 / (X_idx_5 == 0.0 ? 1.0E-16 : X_idx_5)) * t57 * D_idx_3;
  }

  if (M_idx_5 != 0) {
    D_idx_3 = 0.0;
  } else {
    X_idx_5 = pmf_sqrt(1.0 - fabs(t19) * fabs(t19));
    if (t19 != t19) {
      t57 = t19;
    } else if (t19 > 0.0) {
      t57 = 1.0;
    } else {
      t57 = t19 < 0.0 ? -1.0 : 0.0;
    }

    D_idx_3 = -(1.0 / (X_idx_5 == 0.0 ? 1.0E-16 : X_idx_5)) * t57 *
      intermediate_der101;
  }

  if (M_idx_5 != 0) {
    intermediate_der101 = 0.0;
  } else {
    X_idx_5 = pmf_sqrt(1.0 - fabs(t19) * fabs(t19));
    if (t19 != t19) {
      t57 = t19;
    } else if (t19 > 0.0) {
      t57 = 1.0;
    } else {
      t57 = t19 < 0.0 ? -1.0 : 0.0;
    }

    intermediate_der101 = -(1.0 / (X_idx_5 == 0.0 ? 1.0E-16 : X_idx_5)) * t57 *
      -(intermediate_der102 / 0.01);
  }

  if (M_idx_5 != 0) {
    intermediate_der100 = 0.0;
  } else {
    X_idx_5 = pmf_sqrt(1.0 - fabs(t19) * fabs(t19));
    if (t19 != t19) {
      t57 = t19;
    } else if (t19 > 0.0) {
      t57 = 1.0;
    } else {
      t57 = t19 < 0.0 ? -1.0 : 0.0;
    }

    intermediate_der100 = -(1.0 / (X_idx_5 == 0.0 ? 1.0E-16 : X_idx_5)) * t57 *
      -(intermediate_der42 / 0.01);
  }

  if (M_idx_5 != 0) {
    t19 = 0.0;
  } else {
    X_idx_5 = cos(t39 * 2.0) * intermediate_der100 * 2.0;
    t19 = (intermediate_der100 / 2.0 - X_idx_5 / 4.0) * 0.0001;
  }

  if (M_idx_5 != 0) {
    intermediate_der100 = 0.0;
  } else {
    X_idx_5 = cos(t39 * 2.0) * intermediate_der101 * 2.0;
    intermediate_der100 = (intermediate_der101 / 2.0 - X_idx_5 / 4.0) * 0.0001;
  }

  if (M_idx_5 != 0) {
    intermediate_der101 = 0.0;
  } else {
    X_idx_5 = cos(t39 * 2.0) * D_idx_3 * 2.0;
    intermediate_der101 = (D_idx_3 / 2.0 - X_idx_5 / 4.0) * 0.0001;
  }

  if (M_idx_5 != 0) {
    intermediate_der102 = 0.0;
  } else {
    X_idx_5 = cos(t39 * 2.0) * T_idx_0 * 2.0;
    intermediate_der102 = (T_idx_0 / 2.0 - X_idx_5 / 4.0) * 0.0001;
  }

  if (M_idx_2 != 0) {
    t39 = 0.0;
  } else {
    D_idx_3 = pmf_sqrt(1.0 - fabs(intermediate_der132) * fabs
                       (intermediate_der132));
    if (intermediate_der132 != intermediate_der132) {
      X_idx_5 = intermediate_der132;
    } else if (intermediate_der132 > 0.0) {
      X_idx_5 = 1.0;
    } else {
      X_idx_5 = intermediate_der132 < 0.0 ? -1.0 : 0.0;
    }

    t39 = -(1.0 / (D_idx_3 == 0.0 ? 1.0E-16 : D_idx_3)) * X_idx_5 * D_idx_6;
  }

  if (M_idx_2 != 0) {
    T_idx_0 = 0.0;
  } else {
    D_idx_6 = pmf_sqrt(1.0 - fabs(intermediate_der132) * fabs
                       (intermediate_der132));
    if (intermediate_der132 != intermediate_der132) {
      D_idx_3 = intermediate_der132;
    } else if (intermediate_der132 > 0.0) {
      D_idx_3 = 1.0;
    } else {
      D_idx_3 = intermediate_der132 < 0.0 ? -1.0 : 0.0;
    }

    T_idx_0 = -(1.0 / (D_idx_6 == 0.0 ? 1.0E-16 : D_idx_6)) * D_idx_3 * t48;
  }

  if (M_idx_2 != 0) {
    t48 = 0.0;
  } else {
    D_idx_6 = pmf_sqrt(1.0 - fabs(intermediate_der132) * fabs
                       (intermediate_der132));
    if (intermediate_der132 != intermediate_der132) {
      D_idx_3 = intermediate_der132;
    } else if (intermediate_der132 > 0.0) {
      D_idx_3 = 1.0;
    } else {
      D_idx_3 = intermediate_der132 < 0.0 ? -1.0 : 0.0;
    }

    t48 = -(1.0 / (D_idx_6 == 0.0 ? 1.0E-16 : D_idx_6)) * D_idx_3 *
      intermediate_der18;
  }

  if (M_idx_2 != 0) {
    intermediate_der18 = 0.0;
  } else {
    D_idx_6 = pmf_sqrt(1.0 - fabs(intermediate_der132) * fabs
                       (intermediate_der132));
    if (intermediate_der132 != intermediate_der132) {
      D_idx_3 = intermediate_der132;
    } else if (intermediate_der132 > 0.0) {
      D_idx_3 = 1.0;
    } else {
      D_idx_3 = intermediate_der132 < 0.0 ? -1.0 : 0.0;
    }

    intermediate_der18 = -(1.0 / (D_idx_6 == 0.0 ? 1.0E-16 : D_idx_6)) * D_idx_3
      * intermediate_der128;
  }

  if (M_idx_2 != 0) {
    intermediate_der128 = 0.0;
  } else {
    D_idx_6 = cos(t30 * 2.0) * intermediate_der18 * 2.0;
    intermediate_der128 = (intermediate_der18 / 2.0 - D_idx_6 / 4.0) * 0.0001;
  }

  if (M_idx_2 != 0) {
    intermediate_der18 = 0.0;
  } else {
    D_idx_6 = cos(t30 * 2.0) * t48 * 2.0;
    intermediate_der18 = (t48 / 2.0 - D_idx_6 / 4.0) * 0.0001;
  }

  if (M_idx_2 != 0) {
    t48 = 0.0;
  } else {
    D_idx_6 = cos(t30 * 2.0) * T_idx_0 * 2.0;
    t48 = (T_idx_0 / 2.0 - D_idx_6 / 4.0) * 0.0001;
  }

  if (M_idx_2 != 0) {
    intermediate_der132 = 0.0;
  } else {
    T_idx_0 = cos(t30 * 2.0) * t39 * 2.0;
    intermediate_der132 = (t39 / 2.0 - T_idx_0 / 4.0) * 0.0001;
  }

  t39 = -X_idx_2 * t48 * 0.031529631254723287;
  t48 = pmf_sqrt(pmf_sqrt(-X_idx_2 * -X_idx_2 + t49 * t49));
  X_idx_5 = -(t39 / (t48 == 0.0 ? 1.0E-16 : t48) * 3.1622776601683795E+8);
  D_idx_6 = -(-X_idx_2 * intermediate_der128 * 0.031529631254723287 / (t48 ==
    0.0 ? 1.0E-16 : t48) * 3.1622776601683795E+8);
  T_idx_0 = -(-X_idx_2 * intermediate_der18 * 0.031529631254723287 / (t48 == 0.0
    ? 1.0E-16 : t48) * 3.1622776601683795E+8);
  D_idx_2 = -(-X_idx_2 * intermediate_der132 * 0.031529631254723287 / (t48 ==
    0.0 ? 1.0E-16 : t48) * 3.1622776601683795E+8);
  t48 = pmf_sqrt(pmf_sqrt(t1 * t1 + t20 * t20));
  out.mX[0] = X_idx_5;
  out.mX[1] = D_idx_6;
  out.mX[2] = T_idx_0;
  out.mX[3] = D_idx_2;
  out.mX[4] = -(t1 * intermediate_der100 * 0.031529631254723287 / (t48 == 0.0 ?
    1.0E-16 : t48) * 3.1622776601683795E+8);
  out.mX[5] = -(t1 * t19 * 0.031529631254723287 / (t48 == 0.0 ? 1.0E-16 : t48) *
                3.1622776601683795E+8);
  out.mX[6] = -(t1 * intermediate_der101 * 0.031529631254723287 / (t48 == 0.0 ?
    1.0E-16 : t48) * 3.1622776601683795E+8);
  out.mX[7] = -(t1 * intermediate_der102 * 0.031529631254723287 / (t48 == 0.0 ?
    1.0E-16 : t48) * 3.1622776601683795E+8);
  (void)sys;
  (void)t64;
  return 0;
}
