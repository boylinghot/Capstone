/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_f.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_f(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t15, NeDsMethodOutput *t16)
{
  PmRealVector out;
  real_T D_idx_0;
  real_T D_idx_1;
  real_T D_idx_2;
  real_T D_idx_3;
  real_T D_idx_4;
  real_T D_idx_5;
  real_T D_idx_6;
  real_T D_idx_7;
  real_T T_idx_0;
  real_T X_idx_1;
  real_T X_idx_2;
  real_T X_idx_4;
  real_T X_idx_5;
  real_T t14;
  real_T t3;
  int32_T M_idx_2;
  int32_T M_idx_3;
  int32_T M_idx_4;
  int32_T M_idx_5;
  M_idx_2 = t15->mM.mX[2];
  M_idx_3 = t15->mM.mX[3];
  M_idx_4 = t15->mM.mX[4];
  M_idx_5 = t15->mM.mX[5];
  T_idx_0 = t15->mT.mX[0];
  X_idx_1 = t15->mX.mX[1];
  X_idx_2 = t15->mX.mX[2];
  X_idx_4 = t15->mX.mX[4];
  X_idx_5 = t15->mX.mX[5];
  D_idx_0 = t15->mD.mX[0];
  D_idx_1 = t15->mD.mX[1];
  D_idx_2 = t15->mD.mX[2];
  D_idx_3 = t15->mD.mX[3];
  D_idx_4 = t15->mD.mX[4];
  D_idx_5 = t15->mD.mX[5];
  D_idx_6 = t15->mD.mX[6];
  D_idx_7 = t15->mD.mX[7];
  out = t16->mF;
  t14 = T_idx_0 - D_idx_2;
  if (t14 <= D_idx_0 * 0.33333333333333331) {
  } else {
    D_idx_1 = t14 <= D_idx_0 * 0.66666666666666663 ? (t14 - D_idx_0 *
      0.33333333333333331) * (t14 - D_idx_0 * 0.33333333333333331) * D_idx_3 *
      0.5 + D_idx_1 : (D_idx_0 * D_idx_3 * D_idx_0 * 0.055555555555555552 + (t14
      - D_idx_0 * 0.66666666666666663) * D_idx_3 * D_idx_0 * 0.33333333333333331)
      + D_idx_1;
  }

  t3 = D_idx_1 > 0.01 ? 0.01 : D_idx_1;
  D_idx_1 = T_idx_0 - D_idx_6;
  if (D_idx_1 <= D_idx_4 * 0.33333333333333331) {
  } else {
    D_idx_5 = D_idx_1 <= D_idx_4 * 0.66666666666666663 ? (D_idx_1 - D_idx_4 *
      0.33333333333333331) * (D_idx_1 - D_idx_4 * 0.33333333333333331) * D_idx_7
      * 0.5 + D_idx_5 : (D_idx_4 * D_idx_7 * D_idx_4 * 0.055555555555555552 +
                         (D_idx_1 - D_idx_4 * 0.66666666666666663) * D_idx_7 *
                         D_idx_4 * 0.33333333333333331) + D_idx_5;
  }

  T_idx_0 = D_idx_5 > 0.01 ? 0.01 : D_idx_5;
  D_idx_1 = -X_idx_5 + X_idx_2;
  D_idx_4 = 1.0 - (t3 > 0.0 ? t3 : 0.0) / 0.01;
  t3 = ((X_idx_2 + X_idx_5) + 2.0265) / 2.0 * 0.0010000000000000009;
  D_idx_0 = (X_idx_2 + 2.0265) / 2.0 * 0.0010000000000000009;
  if (M_idx_3 != 0) {
    D_idx_5 = (X_idx_1 - 0.1) * X_idx_4 * 2.0E+9;
  } else if (M_idx_4 != 0) {
    D_idx_5 = -(X_idx_4 * 0.002) * X_idx_1 * 1.0E+12;
  } else {
    D_idx_5 = 0.0;
  }

  if (M_idx_5 != 0) {
    T_idx_0 = 0.0;
  } else {
    T_idx_0 = pmf_acos(fabs(1.0 - (T_idx_0 > 0.0 ? T_idx_0 : 0.0) / 0.01));
  }

  if (M_idx_5 != 0) {
    D_idx_3 = 1.0E-12;
  } else {
    D_idx_2 = sin(T_idx_0 * 2.0);
    D_idx_3 = (T_idx_0 / 2.0 - D_idx_2 / 4.0) * 0.0001 + 1.0E-12;
  }

  if (M_idx_2 != 0) {
    T_idx_0 = 0.0;
  } else {
    T_idx_0 = pmf_acos(fabs(D_idx_4));
  }

  if (M_idx_2 != 0) {
    D_idx_4 = 1.0E-12;
  } else {
    D_idx_2 = sin(T_idx_0 * 2.0);
    D_idx_4 = (T_idx_0 / 2.0 - D_idx_2 / 4.0) * 0.0001 + 1.0E-12;
  }

  T_idx_0 = -X_idx_2 * D_idx_4 * 0.031529631254723287;
  D_idx_4 = pmf_sqrt(pmf_sqrt(-X_idx_2 * -X_idx_2 + D_idx_0 * D_idx_0));
  t14 = pmf_sqrt(pmf_sqrt(X_idx_5 * X_idx_5 + 5.9994706640625018E-13));
  D_idx_2 = -(X_idx_5 * 1.5238962756959047E-5 / (t14 == 0.0 ? 1.0E-16 : t14) *
              3.1622776601683795E+8);
  t14 = pmf_sqrt(pmf_sqrt(D_idx_1 * D_idx_1 + t3 * t3));
  out.mX[0] = -0.0;
  out.mX[1] = -0.0;
  out.mX[2] = -(T_idx_0 / (D_idx_4 == 0.0 ? 1.0E-16 : D_idx_4) *
                3.1622776601683795E+8);
  out.mX[3] = D_idx_2;
  out.mX[4] = D_idx_5 / 50.0;
  out.mX[5] = -(D_idx_1 * D_idx_3 * 0.031529631254723287 / (t14 == 0.0 ? 1.0E-16
    : t14) * 3.1622776601683795E+8);
  (void)sys;
  (void)t16;
  return 0;
}
