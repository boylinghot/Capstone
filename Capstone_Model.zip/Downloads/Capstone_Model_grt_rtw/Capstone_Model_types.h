/*
 * Capstone_Model_types.h
 *
 * Code generation for model "Capstone_Model".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Fri Mar 24 10:46:16 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Capstone_Model_types_h_
#define RTW_HEADER_Capstone_Model_types_h_

/* Parameters (default storage) */
typedef struct P_Capstone_Model_T_ P_Capstone_Model_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Capstone_Model_T RT_MODEL_Capstone_Model_T;

#endif                                 /* RTW_HEADER_Capstone_Model_types_h_ */
