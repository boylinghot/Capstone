/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Capstone_Model/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_sys_struct.h"
#include "Capstone_Model_a7fe4013_1_ds_log.h"
#include "Capstone_Model_a7fe4013_1_ds.h"
#include "Capstone_Model_a7fe4013_1_ds_externals.h"
#include "Capstone_Model_a7fe4013_1_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Capstone_Model_a7fe4013_1_ds_log(const NeDynamicSystem *sys, const
  NeDynamicSystemInput *t2, NeDsMethodOutput *t3)
{
  PmRealVector out;
  real_T D_idx_0;
  real_T D_idx_1;
  real_T D_idx_2;
  real_T D_idx_3;
  real_T D_idx_4;
  real_T D_idx_5;
  real_T D_idx_6;
  real_T D_idx_7;
  real_T Fill_Valve_flow_rate;
  real_T Hydraulic_Cylinder_1_R_v;
  real_T T_idx_0;
  real_T U_idx_0;
  real_T X_idx_0;
  real_T X_idx_1;
  real_T X_idx_2;
  real_T X_idx_3;
  real_T X_idx_4;
  real_T X_idx_5;
  real_T t1;
  real_T zc_int1;
  real_T zc_int4;
  int32_T M_idx_10;
  int32_T M_idx_11;
  int32_T M_idx_12;
  int32_T M_idx_13;
  int32_T M_idx_6;
  int32_T M_idx_7;
  int32_T M_idx_8;
  int32_T M_idx_9;
  M_idx_6 = t2->mM.mX[6];
  M_idx_7 = t2->mM.mX[7];
  M_idx_8 = t2->mM.mX[8];
  M_idx_9 = t2->mM.mX[9];
  M_idx_10 = t2->mM.mX[10];
  M_idx_11 = t2->mM.mX[11];
  M_idx_12 = t2->mM.mX[12];
  M_idx_13 = t2->mM.mX[13];
  T_idx_0 = t2->mT.mX[0];
  U_idx_0 = t2->mU.mX[0];
  X_idx_0 = t2->mX.mX[0];
  X_idx_1 = t2->mX.mX[1];
  X_idx_2 = t2->mX.mX[2];
  X_idx_3 = t2->mX.mX[3];
  X_idx_4 = t2->mX.mX[4];
  X_idx_5 = t2->mX.mX[5];
  D_idx_0 = t2->mD.mX[0];
  D_idx_1 = t2->mD.mX[1];
  D_idx_2 = t2->mD.mX[2];
  D_idx_3 = t2->mD.mX[3];
  D_idx_4 = t2->mD.mX[4];
  D_idx_5 = t2->mD.mX[5];
  D_idx_6 = t2->mD.mX[6];
  D_idx_7 = t2->mD.mX[7];
  out = t3->mLOG;
  Fill_Valve_flow_rate = T_idx_0 - D_idx_2;
  zc_int1 = (Fill_Valve_flow_rate - D_idx_0 * 0.33333333333333331) *
    (Fill_Valve_flow_rate - D_idx_0 * 0.33333333333333331) * D_idx_3 * 0.5 +
    D_idx_1;
  zc_int4 = (D_idx_0 * D_idx_3 * D_idx_0 * 0.055555555555555552 +
             (Fill_Valve_flow_rate - D_idx_0 * 0.66666666666666663) * D_idx_3 *
             D_idx_0 * 0.33333333333333331) + D_idx_1;
  Fill_Valve_flow_rate = X_idx_3 + X_idx_4;
  Hydraulic_Cylinder_1_R_v = X_idx_4 * 0.002;
  t1 = T_idx_0 - D_idx_6;
  if (M_idx_6 != 0) {
    T_idx_0 = 0.0;
  } else if (M_idx_7 != 0) {
    T_idx_0 = 0.01;
  } else if (M_idx_8 != 0) {
    T_idx_0 = D_idx_1;
  } else {
    T_idx_0 = M_idx_9 != 0 ? zc_int1 : zc_int4;
  }

  if (M_idx_10 != 0) {
    zc_int4 = 0.0;
  } else if (M_idx_11 != 0) {
    zc_int4 = 0.01;
  } else if (M_idx_12 != 0) {
    zc_int4 = D_idx_5;
  } else {
    zc_int4 = M_idx_13 != 0 ? (t1 - D_idx_4 * 0.33333333333333331) * (t1 -
      D_idx_4 * 0.33333333333333331) * D_idx_7 * 0.5 + D_idx_5 : (D_idx_4 *
      D_idx_7 * D_idx_4 * 0.055555555555555552 + (t1 - D_idx_4 *
      0.66666666666666663) * D_idx_7 * D_idx_4 * 0.33333333333333331) + D_idx_5;
  }

  out.mX[0] = X_idx_2 * 99999.999999999985;
  out.mX[1] = T_idx_0;
  out.mX[2] = Fill_Valve_flow_rate * 1.0E-6;
  out.mX[3] = -X_idx_2 * 99999.999999999985;
  out.mX[4] = -U_idx_0;
  out.mX[5] = T_idx_0;
  out.mX[6] = D_idx_3;
  out.mX[7] = -U_idx_0;
  out.mX[8] = T_idx_0;
  out.mX[9] = D_idx_2;
  out.mX[10] = D_idx_0;
  out.mX[11] = D_idx_1;
  out.mX[12] = X_idx_5 * 99999.999999999985;
  out.mX[13] = X_idx_0 * 0.001;
  out.mX[14] = -X_idx_4 * 1.0E-6;
  out.mX[15] = X_idx_3 * 1.0E-6;
  out.mX[16] = X_idx_5 * 99999.999999999985;
  out.mX[17] = X_idx_0 * 0.001;
  out.mX[18] = X_idx_2 * 99999.999999999985;
  out.mX[19] = X_idx_1;
  out.mX[20] = Hydraulic_Cylinder_1_R_v;
  out.mX[21] = X_idx_4 * 1.0E-6;
  out.mX[22] = -U_idx_0;
  out.mX[23] = X_idx_1;
  out.mX[24] = X_idx_2 * 99999.999999999985;
  out.mX[25] = X_idx_4 * 0.002;
  out.mX[26] = Fill_Valve_flow_rate * 1.0E-6;
  out.mX[27] = Hydraulic_Cylinder_1_R_v;
  out.mX[28] = -U_idx_0;
  out.mX[29] = Hydraulic_Cylinder_1_R_v;
  out.mX[30] = -U_idx_0;
  out.mX[31] = Hydraulic_Cylinder_1_R_v;
  out.mX[32] = U_idx_0;
  out.mX[33] = -U_idx_0;
  out.mX[34] = -Hydraulic_Cylinder_1_R_v;
  out.mX[35] = X_idx_2 * 99999.999999999985;
  out.mX[36] = X_idx_5 * 99999.999999999985;
  out.mX[37] = zc_int4;
  out.mX[38] = X_idx_3 * 1.0E-6;
  out.mX[39] = (-X_idx_5 + X_idx_2) * 99999.999999999985;
  out.mX[40] = -U_idx_0;
  out.mX[41] = zc_int4;
  out.mX[42] = D_idx_7;
  out.mX[43] = -U_idx_0;
  out.mX[44] = zc_int4;
  out.mX[45] = D_idx_6;
  out.mX[46] = D_idx_4;
  out.mX[47] = D_idx_5;
  out.mX[48] = U_idx_0;
  (void)sys;
  (void)t3;
  return 0;
}
